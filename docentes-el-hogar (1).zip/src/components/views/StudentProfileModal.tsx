import React from 'react';
import { X, Printer, Edit, BarChart3, Clock, User, Calendar, BookOpen, AlertCircle, Paperclip, Download } from 'lucide-react';
import { AppData, Student } from '../../types';
import {
  calculateStudentAverage,
  calculateStudentAttendancePercentage,
  getInitials,
  formatDate,
  isStudentInClass
} from '../../utils/storage';
import { downloadAttachedFile } from '../../utils/fileHelpers';

interface StudentProfileModalProps {
  student: Student;
  data: AppData;
  onClose: () => void;
  onEdit: (student: Student) => void;
  onPrintReport: (student: Student) => void;
}

export const StudentProfileModal: React.FC<StudentProfileModalProps> = ({
  student,
  data,
  onClose,
  onEdit,
  onPrintReport
}) => {
  const enrolledClasses = data.classes.filter(c => isStudentInClass(student, c));
  const classIds = new Set(enrolledClasses.map(c => c.id));
  const allStudentGrades = data.grades.filter(g => classIds.has(g.classId) || g.classId === student.classId);

  // Overall average across all classes of their grade
  const classAverages = enrolledClasses.map(c => calculateStudentAverage(student.id, c.id, data.grades, data.activities));
  const avg = classAverages.length > 0
    ? Math.round(classAverages.reduce((a, b) => a + b, 0) / classAverages.length)
    : calculateStudentAverage(student.id, student.classId, data.grades, data.activities);

  // Overall attendance across all classes of their grade
  const classAtts = enrolledClasses.map(c => calculateStudentAttendancePercentage(student.id, c.id, data.attendance));
  const att = classAtts.length > 0
    ? Math.round(classAtts.reduce((a, b) => a + b, 0) / classAtts.length)
    : calculateStudentAttendancePercentage(student.id, student.classId, data.attendance);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
      <div className="relative flex max-h-[90vh] w-full max-w-2xl flex-col rounded-3xl border border-[#dfe6df] bg-white shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#dfe6df] px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#2f8b3c]/15 text-sm font-extrabold text-[#236a2d]">
              {getInitials(student.name)}
            </div>
            <div>
              <h3 className="text-base font-black text-[#26302b]">{student.name}</h3>
              <p className="text-xs text-[#6d766f]">
                {student.grade ? `Grado: ${student.grade}` : 'Sin grado'} · Sec. {student.section || 'A'} · {enrolledClasses.length} {enrolledClasses.length === 1 ? 'materia' : 'materias'} · ID: {student.code || 'No asignado'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-[#6d766f] transition hover:bg-[#eef2ee]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Body content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Top 3 Metric Cards */}
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-2xl border border-[#dfe6df] bg-[#f7f8f6] p-4 text-center">
              <span className="text-[11px] font-bold text-[#6d766f]">Promedio</span>
              <div className="mt-1 text-2xl font-black text-[#236a2d]">{avg}%</div>
              <span className="text-[10px] text-[#6d766f]">{avg >= 70 ? 'Aprobatorio' : 'En refuerzo'}</span>
            </div>

            <div className="rounded-2xl border border-[#dfe6df] bg-[#f7f8f6] p-4 text-center">
              <span className="text-[11px] font-bold text-[#6d766f]">Asistencia</span>
              <div className="mt-1 text-2xl font-black text-[#26302b]">{att}%</div>
              <span className="text-[10px] text-[#2f8b3c] font-semibold">Registro acumulado</span>
            </div>

            <div className="rounded-2xl border border-[#dfe6df] bg-[#f7f8f6] p-4 text-center">
              <span className="text-[11px] font-bold text-[#6d766f]">Estado</span>
              <div className="mt-1 text-base font-black text-[#26302b]">{student.status}</div>
              <span className="text-[10px] text-[#6d766f]">
                {student.grade} - {student.section}
              </span>
            </div>
          </div>

          {/* Student details */}
          <div className="rounded-2xl border border-[#dfe6df] bg-white p-4 space-y-2 text-xs">
            <div className="grid grid-cols-2 gap-2 text-[#546057]">
              <div>
                <span className="font-bold text-[#26302b]">Fecha de nacimiento: </span>
                <span>{formatDate(student.birth) || 'No especificada'}</span>
              </div>
              <div>
                <span className="font-bold text-[#26302b]">Contacto / Tutor: </span>
                <span>{student.contact || 'No especificado'}</span>
              </div>
            </div>
            {student.notes && (
              <div className="mt-3 rounded-xl bg-[#f7f8f6] p-3 text-xs text-[#546057] border border-[#dfe6df]/80">
                <strong className="block text-[#26302b] mb-0.5">Observaciones pedagógicas:</strong>
                {student.notes}
              </div>
            )}
          </div>

          {/* Enrolled Classes for this Grade */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-black uppercase tracking-wider text-[#26302b]">
                Clases y materias vinculadas ({enrolledClasses.length})
              </h4>
              <span className="text-[11px] font-bold text-[#2f8b3c]">
                Asignado por grado escolar ({student.grade || 'General'})
              </span>
            </div>

            {enrolledClasses.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-[#cad4cb] bg-[#fcfdfc] p-4 text-center text-xs text-[#6d766f]">
                No hay clases creadas para el grado {student.grade || 'este grado'} todavía. Al crear una clase para este grado, el alumno se vinculará automáticamente.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {enrolledClasses.map(cls => {
                  const teacher = data.users.find(u => u.id === cls.teacherId);
                  const clsAvg = calculateStudentAverage(student.id, cls.id, data.grades);
                  const clsAtt = calculateStudentAttendancePercentage(student.id, cls.id, data.attendance);

                  return (
                    <div
                      key={cls.id}
                      className="rounded-2xl border border-[#dfe6df] bg-white p-3 shadow-2xs hover:border-[#2f8b3c]/40 transition"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <BookOpen className="h-3.5 w-3.5 text-[#2f8b3c] shrink-0" />
                            <strong className="truncate text-xs font-black text-[#26302b]">
                              {cls.name}
                            </strong>
                          </div>
                          <span className="mt-0.5 block truncate text-[11px] text-[#6d766f]">
                            Docente: {teacher?.name || 'Titular asignado'}
                          </span>
                        </div>
                        <span className="rounded-lg bg-[#eaf6ec] px-2 py-0.5 text-[10px] font-black text-[#236a2d] shrink-0">
                          {clsAvg}%
                        </span>
                      </div>

                      <div className="mt-2 flex items-center justify-between border-t border-[#f0f4f0] pt-2 text-[10px] text-[#6d766f]">
                        <span>Asistencia: <strong className="text-[#26302b]">{clsAtt}%</strong></span>
                        <span className="rounded bg-[#f7f8f6] px-1.5 py-0.5 font-bold text-[#546057]">
                          Sec. {cls.section || student.section || 'A'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Grades Breakdown */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-black uppercase tracking-wider text-[#26302b]">
                Desglose de Calificaciones
              </h4>
              <span className="text-[11px] text-[#6d766f]">{allStudentGrades.length} evaluaciones registradas</span>
            </div>

            {allStudentGrades.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-[#cad4cb] bg-[#fcfdfc] p-6 text-center text-xs text-[#6d766f]">
                No hay evaluaciones registradas para las clases de este alumno.
              </div>
            ) : (
              <div className="divide-y divide-[#dfe6df] rounded-2xl border border-[#dfe6df] bg-white overflow-hidden text-xs">
                {allStudentGrades.map(g => {
                  const evalClass = data.classes.find(c => c.id === g.classId);
                  const raw = Number(g.scores?.[student.id] ?? 0);
                  const normalized = g.scale === 10 ? raw * 10 : raw;
                  return (
                    <div key={g.id} className="flex items-center justify-between p-3">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <strong className="text-xs text-[#26302b]">{g.title}</strong>
                          {evalClass && (
                            <span className="rounded-md bg-[#f0f4f0] px-1.5 py-0.5 text-[10px] font-bold text-[#2f8b3c]">
                              {evalClass.name}
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-[#6d766f]">
                          {g.type} · Ponderación: {g.value}%
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-sm font-black text-[#236a2d]">
                          {raw} / {g.scale}
                        </span>
                        <div className="text-[10px] text-[#6d766f]">equivale a {Math.round(normalized)}%</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Graded Activities Breakdown */}
          {(() => {
            const gradedActs = data.activities.filter(a => {
              return (classIds.has(a.classId) || a.classId === student.classId) && a.scores?.[student.id] !== undefined;
            });
            if (gradedActs.length === 0) return null;

            return (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-black uppercase tracking-wider text-[#26302b]">
                    Actividades Escolares Calificadas
                  </h4>
                  <span className="text-[11px] text-[#6d766f]">{gradedActs.length} actividades</span>
                </div>
                <div className="divide-y divide-[#dfe6df] rounded-2xl border border-[#dfe6df] bg-white overflow-hidden text-xs">
                  {gradedActs.map(act => {
                    const actClass = data.classes.find(c => c.id === act.classId);
                    const score = act.scores?.[student.id];
                    const percent = act.value > 0 && score !== undefined ? Math.round((score / act.value) * 100) : 0;
                    const gradeInfo = act.studentGrades?.[student.id];

                    return (
                      <div key={act.id} className="p-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-1.5">
                              <strong className="text-xs text-[#26302b]">{act.title}</strong>
                              {actClass && (
                                <span className="rounded-md bg-[#f0f4f0] px-1.5 py-0.5 text-[10px] font-bold text-[#2f8b3c]">
                                  {actClass.name}
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-[#6d766f]">
                              Valor: {act.value} pts · Vencimiento: {formatDate(act.deadline)}
                            </span>
                          </div>
                          <div className="text-right">
                            <span className="text-sm font-black text-[#236a2d]">
                              {score} / {act.value} pts
                            </span>
                            <div className="text-[10px] font-bold text-[#6d766f]">{percent}%</div>
                          </div>
                        </div>
                        {gradeInfo?.feedback && (
                          <p className="mt-1 text-[11px] text-[#536057] italic bg-[#f7f8f6] p-1.5 rounded-lg border border-[#dfe6df]/60">
                            Observación: "{gradeInfo.feedback}"
                          </p>
                        )}
                        {gradeInfo?.attachments && gradeInfo.attachments.length > 0 && (
                          <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                            <span className="text-[10px] font-bold text-[#236a2d] flex items-center gap-1">
                              <Paperclip className="h-3 w-3" />
                              Archivos entregados ({gradeInfo.attachments.length}):
                            </span>
                            {gradeInfo.attachments.map(att => (
                              <button
                                key={att.id}
                                type="button"
                                onClick={() => downloadAttachedFile(att, `Entrega_${student.name}_${act.title}`)}
                                className="inline-flex items-center gap-1 rounded-md bg-[#f7f8f6] px-1.5 py-0.5 text-[10px] font-semibold text-[#26302b] border border-[#dfe6df] hover:border-[#2f8b3c] hover:text-[#236a2d] transition"
                                title={`Descargar ${att.name}`}
                              >
                                <span className="max-w-[120px] truncate">{att.name}</span>
                                <Download className="h-2.5 w-2.5 text-[#2f8b3c]" />
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })()}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-[#dfe6df] bg-[#f7f8f6] px-6 py-3.5">
          <button
            onClick={() => onEdit(student)}
            className="flex items-center gap-1.5 rounded-xl border border-[#dfe6df] bg-white px-3.5 py-2 text-xs font-bold text-[#26302b] hover:bg-[#eef2ee]"
          >
            <Edit className="h-3.5 w-3.5" />
            <span>Editar alumno</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="rounded-xl px-4 py-2 text-xs font-bold text-[#6d766f] hover:bg-[#eef2ee]"
            >
              Cerrar
            </button>
            <button
              onClick={() => onPrintReport(student)}
              className="flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-[#9f1d24]"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>Imprimir reporte</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
