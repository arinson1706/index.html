import React, { useState, useMemo } from 'react';
import { Users, Plus, Upload, Search, Filter, Eye, Edit, Trash2, Key, ShieldCheck, Phone, UserCheck, GraduationCap, BookOpen } from 'lucide-react';
import { AppData, Student, User } from '../../types';
import {
  calculateStudentAverage,
  calculateStudentAttendancePercentage,
  getInitials,
  isStudentInClass,
  matchGrade
} from '../../utils/storage';
import { getAllowedStudents, getAllowedClasses } from '../../utils/rbac';

interface StudentsViewProps {
  data: AppData;
  currentUser?: User;
  initialClassFilter?: string;
  onAddStudent: () => void;
  onOpenBulkImport: () => void;
  onViewStudentProfile: (student: Student) => void;
  onEditStudent: (student: Student) => void;
  onDeleteStudent: (id: string) => void;
  onManageAccess?: (student: Student) => void;
}

export const StudentsView: React.FC<StudentsViewProps> = ({
  data,
  currentUser,
  initialClassFilter = '',
  onAddStudent,
  onOpenBulkImport,
  onViewStudentProfile,
  onEditStudent,
  onDeleteStudent,
  onManageAccess
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGradeFilter, setSelectedGradeFilter] = useState<string>('all');
  const [selectedClassId, setSelectedClassId] = useState(initialClassFilter);

  const allowedClasses = getAllowedClasses(data.classes, currentUser, data.students);
  const baseStudents = getAllowedStudents(data.students, data.classes, currentUser);

  const getClassName = (id: string) => data.classes.find(c => c.id === id)?.name || 'Sin clase';

  // Get list of all distinct grades
  const allGrades = useMemo(() => {
    const set = new Set<string>();
    baseStudents.forEach(s => {
      if (s.grade) set.add(s.grade);
    });
    return Array.from(set).sort();
  }, [baseStudents]);

  const filteredStudents = baseStudents.filter(s => {
    const q = searchTerm.toLowerCase();
    const matchesSearch =
      s.name.toLowerCase().includes(q) ||
      (s.code || '').toLowerCase().includes(q) ||
      (s.guardianName || '').toLowerCase().includes(q);
    const matchesGrade = selectedGradeFilter === 'all' || matchGrade(s.grade, selectedGradeFilter);
    const targetClass = selectedClassId ? data.classes.find(c => c.id === selectedClassId) : null;
    const matchesClass = !selectedClassId || (targetClass ? isStudentInClass(s, targetClass) : s.classId === selectedClassId);
    return matchesSearch && matchesGrade && matchesClass;
  });

  // Group filtered students by grade
  const studentsGroupedByGrade = useMemo(() => {
    const groups: Record<string, Student[]> = {};
    filteredStudents.forEach(s => {
      const g = s.grade || 'Sin Grado Asignado';
      if (!groups[g]) groups[g] = [];
      groups[g].push(s);
    });
    return groups;
  }, [filteredStudents]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col justify-between gap-4 rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs sm:flex-row sm:items-center">
        <div>
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#c6292e]">
            Directorio Académico
          </span>
          <h2 className="mt-1 text-2xl font-black text-[#26302b] sm:text-3xl">Alumnos por grado</h2>
          <p className="mt-1 text-xs text-[#6d766f]">
            Estudiantes organizados por grado, encargados de familia y credenciales de acceso.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={onOpenBulkImport}
            className="flex items-center gap-1.5 rounded-xl border border-[#dfe6df] bg-[#eef2ee] px-3.5 py-2.5 text-xs font-bold text-[#435047] transition hover:bg-[#dfe6df]"
          >
            <Upload className="h-4 w-4" />
            <span>Carga masiva CSV</span>
          </button>
          <button
            onClick={onAddStudent}
            className="flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2.5 text-xs font-bold text-white shadow-sm transition hover:bg-[#9f1d24]"
          >
            <Plus className="h-4 w-4" />
            <span>Agregar alumno</span>
          </button>
        </div>
      </div>

      {/* Grade Quick Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2">
        <button
          onClick={() => setSelectedGradeFilter('all')}
          className={`rounded-xl px-3.5 py-1.5 text-xs font-black transition ${
            selectedGradeFilter === 'all'
              ? 'bg-[#c6292e] text-white shadow-xs'
              : 'border border-[#dfe6df] bg-white text-[#5d685f] hover:bg-[#f7f8f6]'
          }`}
        >
          Todos los grados ({baseStudents.length})
        </button>
        {allGrades.map(grade => {
          const count = baseStudents.filter(s => s.grade === grade).length;
          return (
            <button
              key={grade}
              onClick={() => setSelectedGradeFilter(grade)}
              className={`rounded-xl px-3.5 py-1.5 text-xs font-black transition ${
                selectedGradeFilter === grade
                  ? 'bg-[#2f8b3c] text-white shadow-xs'
                  : 'border border-[#dfe6df] bg-white text-[#5d685f] hover:bg-[#f7f8f6]'
              }`}
            >
              {grade} ({count})
            </button>
          );
        })}
      </div>

      {/* Toolbar */}
      <div className="flex flex-col gap-3 rounded-2xl border border-[#dfe6df] bg-white p-3 shadow-xs sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-[#6d766f]" />
          <input
            type="text"
            placeholder="Buscar por nombre, código o nombre de encargado..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] py-2 pl-9 pr-4 text-xs outline-none transition focus:border-[#2f8b3c] focus:bg-white"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-[#6d766f]" />
          <select
            value={selectedClassId}
            onChange={e => setSelectedClassId(e.target.value)}
            className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-2 text-xs font-bold text-[#435047] outline-none focus:border-[#2f8b3c]"
          >
            <option value="">Todas las clases ({allowedClasses.length})</option>
            {allowedClasses.map(c => (
              <option key={c.id} value={c.id}>
                {c.name} {c.grade ? `(${c.grade})` : ''}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Students List Grouped by Grade */}
      {filteredStudents.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-[#cad4cb] bg-white p-12 text-center shadow-xs">
          <Users className="mx-auto h-12 w-12 text-[#cad4cb] mb-3" />
          <strong className="block text-sm font-extrabold text-[#26302b]">No hay alumnos encontrados</strong>
          <p className="mt-1 text-xs text-[#6d766f]">
            {searchTerm || selectedClassId || selectedGradeFilter !== 'all'
              ? 'Ajusta tus filtros de búsqueda o grado.'
              : 'Comienza agregando alumnos a los grados correspondientes.'}
          </p>
          <div className="mt-4 flex justify-center gap-2">
            <button
              onClick={onAddStudent}
              className="rounded-xl bg-[#c6292e] px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-[#9f1d24]"
            >
              Agregar alumno
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(studentsGroupedByGrade).map(([gradeName, studentsInGrade]) => (
            <div key={gradeName} className="space-y-3">
              {/* Grade Section Badge Header */}
              <div className="flex items-center justify-between rounded-2xl border border-[#dfe6df] bg-gradient-to-r from-white to-[#f7f8f6] p-3.5 shadow-2xs">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#2f8b3c]/15 text-[#236a2d]">
                    <GraduationCap className="h-4 w-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-[#26302b]">{gradeName}</h3>
                    <span className="text-[11px] text-[#6d766f]">
                      {studentsInGrade.length} {studentsInGrade.length === 1 ? 'estudiante matriculado' : 'estudiantes matriculados'}
                    </span>
                  </div>
                </div>

                <span className="rounded-lg bg-[#eaf6ec] px-2.5 py-1 text-[11px] font-black text-[#236a2d]">
                  Grado Oficial
                </span>
              </div>

              {/* Table for this Grade */}
              <div className="overflow-hidden rounded-3xl border border-[#dfe6df] bg-white shadow-xs">
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse text-left text-xs">
                    <thead>
                      <tr className="border-b border-[#dfe6df] bg-[#f7f8f6] text-[11px] font-bold uppercase tracking-wider text-[#6d766f]">
                        <th className="py-3.5 px-4">Alumno</th>
                        <th className="py-3.5 px-4">Código / ID</th>
                        <th className="py-3.5 px-4">Encargado de Familia</th>
                        <th className="py-3.5 px-4">Acceso a plataforma</th>
                        <th className="py-3.5 px-4">Promedio</th>
                        <th className="py-3.5 px-4">Asistencia</th>
                        <th className="py-3.5 px-4">Estado</th>
                        <th className="py-3.5 px-4 text-right">Acciones</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#dfe6df]">
                      {studentsInGrade.map(s => {
                        const avg = calculateStudentAverage(s.id, s.classId, data.grades);
                        const att = calculateStudentAttendancePercentage(s.id, s.classId, data.attendance);
                        const studentUser = data.users.find(
                          u => u.id === s.userId || (u.role === 'student' && u.name.toLowerCase() === s.name.toLowerCase())
                        );

                        return (
                          <tr key={s.id} className="transition hover:bg-[#fbfcfb]">
                            <td className="py-3.5 px-4">
                              <div className="flex items-center gap-3">
                                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#2f8b3c]/15 text-xs font-bold text-[#236a2d]">
                                  {getInitials(s.name)}
                                </div>
                                <div>
                                  <strong className="block text-xs font-extrabold text-[#26302b]">{s.name}</strong>
                                  <span className="block text-[11px] text-[#6d766f]">
                                    {s.grade ? `Grado: ${s.grade}` : getClassName(s.classId)} · Sec. {s.section || 'A'}
                                  </span>
                                  {/* List of enrolled classes for this student */}
                                  <div className="mt-1 flex flex-wrap items-center gap-1">
                                    {data.classes.filter(c => isStudentInClass(s, c)).map(c => (
                                      <span
                                        key={c.id}
                                        title={c.name}
                                        className="inline-flex items-center gap-1 rounded-md bg-[#eaf6ec] px-1.5 py-0.5 text-[10px] font-bold text-[#236a2d] border border-[#2f8b3c]/20"
                                      >
                                        <BookOpen className="h-2.5 w-2.5" />
                                        <span>{c.name}</span>
                                      </span>
                                    ))}
                                    {data.classes.filter(c => isStudentInClass(s, c)).length === 0 && (
                                      <span className="text-[10px] text-[#8e9890] italic">
                                        Sin clases creadas aún para este grado
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </td>

                            <td className="py-3.5 px-4 font-mono text-[11px] text-[#546057]">{s.code || '—'}</td>

                            <td className="py-3.5 px-4">
                              {s.guardianName ? (
                                <div>
                                  <div className="font-bold text-[#26302b]">{s.guardianName}</div>
                                  {s.guardianPhone && (
                                    <div className="flex items-center gap-1 text-[11px] text-[#546057]">
                                      <Phone className="h-2.5 w-2.5 text-[#2f8b3c]" />
                                      <span>{s.guardianPhone}</span>
                                    </div>
                                  )}
                                </div>
                              ) : (
                                <span className="text-[11px] text-[#cad4cb] italic">Sin encargado registrado</span>
                              )}
                            </td>

                            <td className="py-3.5 px-4">
                              {studentUser ? (
                                <div className="flex items-center gap-1.5">
                                  <span className="rounded-full bg-[#eaf6ec] px-2.5 py-0.5 font-mono text-[11px] font-bold text-[#236a2d]">
                                    @{studentUser.username}
                                  </span>
                                  {onManageAccess && (
                                    <button
                                      type="button"
                                      onClick={() => onManageAccess(s)}
                                      className="rounded p-1 text-[#2f8b3c] hover:bg-[#eef2ee]"
                                      title={`Ver/editar clave de ${s.name}`}
                                    >
                                      <Key className="h-3.5 w-3.5" />
                                    </button>
                                  )}
                                </div>
                              ) : (
                                onManageAccess && (
                                  <button
                                    type="button"
                                    onClick={() => onManageAccess(s)}
                                    className="flex items-center gap-1 rounded-lg border border-[#2f8b3c]/30 bg-[#f7f8f6] px-2 py-1 text-[11px] font-bold text-[#236a2d] transition hover:bg-[#eaf6ec]"
                                    title={`Dar acceso de usuario a ${s.name}`}
                                  >
                                    <Key className="h-3 w-3" />
                                    <span>Dar acceso</span>
                                  </button>
                                )
                              )}
                            </td>

                            <td className="py-3.5 px-4 font-black text-[#236a2d]">{avg}%</td>
                            <td className="py-3.5 px-4 font-bold text-[#26302b]">{att}%</td>

                            <td className="py-3.5 px-4">
                              <span
                                className={`rounded-full px-2.5 py-0.5 text-[10px] font-extrabold ${
                                  s.status === 'Activo' ? 'bg-[#eaf6ec] text-[#236a2d]' : 'bg-[#eef2ee] text-[#6d766f]'
                                }`}
                              >
                                {s.status}
                              </span>
                            </td>

                            <td className="py-3.5 px-4 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  onClick={() => onViewStudentProfile(s)}
                                  className="flex items-center gap-1 rounded-lg bg-[#eaf6ec] px-2.5 py-1 text-xs font-bold text-[#236a2d] transition hover:bg-[#2f8b3c] hover:text-white"
                                  title="Ver perfil completo"
                                >
                                  <Eye className="h-3.5 w-3.5" />
                                  <span>Perfil</span>
                                </button>
                                <button
                                  onClick={() => onEditStudent(s)}
                                  className="rounded-lg p-1.5 text-[#5d685f] hover:bg-[#eef2ee]"
                                  title="Editar datos"
                                >
                                  <Edit className="h-3.5 w-3.5" />
                                </button>
                                <button
                                  onClick={() => onDeleteStudent(s.id)}
                                  className="rounded-lg p-1.5 text-[#c6292e] hover:bg-[#fde7e7]"
                                  title="Eliminar alumno"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
