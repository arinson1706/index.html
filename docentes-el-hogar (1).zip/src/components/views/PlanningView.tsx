import React, { useState, useMemo } from 'react';
import { PenTool, Plus, Search, Copy, Edit, Trash2, Eye, BookOpen, GraduationCap, Calendar, FileText } from 'lucide-react';
import { AppData, LessonPlan, User, ClassRoom } from '../../types';
import { formatDate } from '../../utils/storage';
import { getAllowedClasses } from '../../utils/rbac';

interface PlanningViewProps {
  data: AppData;
  currentUser?: User | null;
  onAddPlan: () => void;
  onEditPlan: (plan: LessonPlan) => void;
  onDuplicatePlan: (id: string) => void;
  onDeletePlan: (id: string) => void;
  onViewPlanDetail: (plan: LessonPlan) => void;
}

export const PlanningView: React.FC<PlanningViewProps> = ({
  data,
  currentUser,
  onAddPlan,
  onEditPlan,
  onDuplicatePlan,
  onDeletePlan,
  onViewPlanDetail
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGrade, setSelectedGrade] = useState<string>('all');
  const [selectedClassId, setSelectedClassId] = useState<string>('all');
  const [onlyTemplates, setOnlyTemplates] = useState(false);

  const isStudent = currentUser?.role === 'student';

  const allowedClasses = useMemo(() => {
    return getAllowedClasses(data.classes, currentUser, data.students);
  }, [data.classes, currentUser, data.students]);

  // Extract distinct grades from existing plans and classes for institutional coordination
  const distinctGrades = useMemo(() => {
    const set = new Set<string>();
    data.plans.forEach(p => {
      if (p.grade) set.add(p.grade);
    });
    allowedClasses.forEach(c => {
      if (c.grade) set.add(c.grade);
    });
    return Array.from(set).sort();
  }, [data.plans, allowedClasses]);

  const filteredPlans = data.plans.filter(p => {
    const q = searchTerm.toLowerCase();
    const matchesSearch =
      p.title.toLowerCase().includes(q) ||
      (p.subject || '').toLowerCase().includes(q) ||
      (p.topic || '').toLowerCase().includes(q) ||
      (p.grade || '').toLowerCase().includes(q);
    const matchesTemplate = !onlyTemplates || p.template;
    const matchesGrade = selectedGrade === 'all' || p.grade === selectedGrade;
    const matchesClass = selectedClassId === 'all' || p.classId === selectedClassId;

    return matchesSearch && matchesTemplate && matchesGrade && matchesClass;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col justify-between gap-4 rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs sm:flex-row sm:items-center">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#c6292e]">
              Escuela Hogar de Amor y Esperanza
            </span>
            <span className="rounded-full bg-[#eaf6ec] px-2.5 py-0.5 text-[10px] font-extrabold text-[#236a2d]">
              Formato Oficial
            </span>
          </div>
          <h2 className="mt-1 text-2xl font-black text-[#26302b] sm:text-3xl">
            Planificación de Clases
          </h2>
          <p className="mt-1 text-xs text-[#6d766f]">
            Registro curricular institucional por clase y fecha con estructura didáctica oficial: Espacio Curricular, Expectativas, Contenidos, Metodología y Evaluación.
          </p>
        </div>

        {!isStudent && (
          <button
            onClick={onAddPlan}
            className="flex items-center justify-center gap-2 rounded-xl bg-[#c6292e] px-5 py-2.5 text-xs font-black text-white shadow-sm transition hover:bg-[#9f1d24]"
          >
            <Plus className="h-4 w-4" />
            <span>Nueva planificación</span>
          </button>
        )}
      </div>

      {/* Grade Selector Tabs for Coordination */}
      <div className="flex flex-wrap items-center gap-2">
        <button
          onClick={() => {
            setSelectedGrade('all');
          }}
          className={`rounded-xl px-3 py-1.5 text-xs font-extrabold transition ${
            selectedGrade === 'all'
              ? 'bg-[#26302b] text-white shadow-xs'
              : 'bg-white text-[#5d685f] border border-[#dfe6df] hover:bg-[#f7f8f6]'
          }`}
        >
          Todos los grados ({data.plans.length})
        </button>
        {distinctGrades.map(grade => {
          const countInGrade = data.plans.filter(p => p.grade === grade).length;
          return (
            <button
              key={grade}
              onClick={() => setSelectedGrade(grade)}
              className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-extrabold transition ${
                selectedGrade === grade
                  ? 'bg-[#2f8b3c] text-white shadow-xs'
                  : 'bg-white text-[#5d685f] border border-[#dfe6df] hover:bg-[#f7f8f6]'
              }`}
            >
              <GraduationCap className="h-3.5 w-3.5" />
              <span>{grade}</span>
              <span className={`text-[10px] rounded-full px-1.5 py-0.2 ${selectedGrade === grade ? 'bg-white/20' : 'bg-[#eef2ee]'}`}>
                {countInGrade}
              </span>
            </button>
          );
        })}
      </div>

      {/* Toolbar: Search & Class Filter */}
      <div className="flex flex-col gap-3 rounded-2xl border border-[#dfe6df] bg-white p-3.5 shadow-xs sm:flex-row sm:items-center">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-[#6d766f]" />
          <input
            type="text"
            placeholder="Buscar por tema, espacio curricular, grado o título..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] py-2 pl-9 pr-4 text-xs outline-none transition focus:border-[#2f8b3c] focus:bg-white"
          />
        </div>

        {/* Filter by specific Class */}
        <div className="flex items-center gap-2">
          <BookOpen className="h-4 w-4 text-[#2f8b3c] shrink-0" />
          <select
            value={selectedClassId}
            onChange={e => setSelectedClassId(e.target.value)}
            className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-2 text-xs font-bold text-[#26302b] outline-none transition focus:border-[#2f8b3c] focus:bg-white"
          >
            <option value="all">Todas las clases</option>
            {allowedClasses.map(c => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.grade} - {c.subject})
              </option>
            ))}
          </select>
        </div>

        {/* Templates Only */}
        <button
          onClick={() => setOnlyTemplates(!onlyTemplates)}
          className={`flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold transition shrink-0 ${
            onlyTemplates
              ? 'border border-[#f5c400] bg-[#fff7cc] text-[#735f00]'
              : 'border border-[#dfe6df] bg-[#f7f8f6] text-[#5d685f] hover:bg-white'
          }`}
        >
          <span>Solo plantillas ({data.plans.filter(p => p.template).length})</span>
        </button>
      </div>

      {/* Plans List */}
      {filteredPlans.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-[#cad4cb] bg-white p-12 text-center shadow-xs">
          <FileText className="mx-auto h-12 w-12 text-[#cad4cb] mb-3" />
          <h3 className="text-sm font-extrabold text-[#26302b]">No hay planificaciones registradas</h3>
          <p className="mt-1 text-xs text-[#6d766f]">
            {searchTerm || onlyTemplates || selectedGrade !== 'all' || selectedClassId !== 'all'
              ? 'Intenta con otro filtro de búsqueda, grado o clase.'
              : 'Crea tu primera planificación de clase con el formato oficial.'}
          </p>
          {!isStudent && (
            <button
              onClick={onAddPlan}
              className="mt-4 inline-flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-[#9f1d24]"
            >
              <Plus className="h-4 w-4" />
              <span>Crear planificación</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredPlans.map(plan => {
            const classObj = data.classes.find(c => c.id === plan.classId);

            return (
              <div
                key={plan.id}
                className="flex flex-col justify-between rounded-3xl border border-[#dfe6df] bg-white p-5 shadow-xs transition hover:shadow-md"
              >
                <div>
                  {/* Card Header badges */}
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="rounded-full bg-[#eaf6ec] px-2.5 py-0.5 text-[10px] font-extrabold text-[#236a2d]">
                        {plan.grade || 'General'}
                      </span>
                      {classObj && (
                        <span className="rounded-full bg-[#eef2ee] px-2 py-0.5 text-[10px] font-bold text-[#3d4740] border border-[#dfe6df]">
                          Clase: {classObj.name}
                        </span>
                      )}
                      {plan.template && (
                        <span className="rounded-full bg-[#fff7cc] px-2 py-0.5 text-[10px] font-extrabold text-[#735f00]">
                          Plantilla
                        </span>
                      )}
                    </div>

                    <span className="flex items-center gap-1 text-[11px] font-bold text-[#6d766f]">
                      <Calendar className="h-3 w-3 text-[#c6292e]" />
                      <span>{formatDate(plan.date)}</span>
                    </span>
                  </div>

                  {/* Title & Curricular space */}
                  <h3 className="mt-3 text-base font-extrabold text-[#26302b] line-clamp-2">
                    {plan.title}
                  </h3>
                  <div className="mt-1 flex items-center gap-1 text-xs font-bold text-[#2f8b3c]">
                    <BookOpen className="h-3.5 w-3.5" />
                    <span>{plan.subject || 'Espacio Curricular no especificado'}</span>
                  </div>

                  {/* Tema */}
                  {plan.topic && (
                    <div className="mt-2.5 rounded-xl border border-[#dfe6df] bg-[#f8faf8] p-2.5 text-xs text-[#536057]">
                      <span className="font-bold text-[#b30000] block mb-0.5 text-[11px]">
                        Tema:
                      </span>
                      <span className="font-semibold text-black line-clamp-2">{plan.topic}</span>
                    </div>
                  )}

                  {/* Expectativas preview */}
                  {(plan.expectations || plan.objective) && (
                    <p className="mt-2.5 line-clamp-2 text-xs text-[#6d766f]">
                      <strong className="text-[#26302b]">Expectativas:</strong>{' '}
                      {plan.expectations || plan.objective}
                    </p>
                  )}
                </div>

                {/* Card Action footer */}
                <div className="mt-5 border-t border-[#dfe6df] pt-3.5">
                  <div className="flex items-center justify-between text-xs">
                    <button
                      onClick={() => onViewPlanDetail(plan)}
                      className="flex items-center gap-1.5 font-black text-[#2f8b3c] hover:underline"
                      title="Ver formato oficial completo"
                    >
                      <Eye className="h-4 w-4" />
                      <span>Ver formato oficial</span>
                    </button>

                    {!isStudent && (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => onDuplicatePlan(plan.id)}
                          className="rounded-lg p-1.5 text-[#536057] hover:bg-[#eef2ee]"
                          title="Duplicar planificación"
                        >
                          <Copy className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => onEditPlan(plan)}
                          className="rounded-lg p-1.5 text-[#286e33] hover:bg-[#eaf6ec]"
                          title="Editar planificación"
                        >
                          <Edit className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => onDeletePlan(plan.id)}
                          className="rounded-lg p-1.5 text-[#c6292e] hover:bg-[#fde7e7]"
                          title="Eliminar planificación"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
