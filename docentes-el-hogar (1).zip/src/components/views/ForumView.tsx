import React, { useState, useMemo } from 'react';
import {
  MessagesSquare,
  Plus,
  Search,
  MessageSquare,
  CheckSquare,
  Pin,
  Clock,
  UserCheck,
  Send,
  Trash2,
  Edit,
  ThumbsUp,
  Award,
  Paperclip,
  Download,
  AlertCircle,
  Lock,
  Unlock,
  ChevronLeft,
  Share2,
  FileText,
  Cloud,
  Loader2,
  Info,
  Calendar,
  Sparkles,
  Users
} from 'lucide-react';
import {
  AppData,
  ForumTopic,
  ForumComment,
  ClassRoom,
  Activity,
  User,
  AttachedFile,
  ParcialId,
  PeriodsConfig
} from '../../types';
import { formatDate, formatFileSize, getInitials, getActivePeriod } from '../../utils/storage';
import { getAllowedClasses } from '../../utils/rbac';
import { downloadAttachedFile } from '../../utils/fileHelpers';
import { uploadFileToStorage } from '../../services/firebase';

interface ForumViewProps {
  data: AppData;
  currentUser: User;
  periodsConfig?: PeriodsConfig;
  initialTopicId?: string;
  initialClassId?: string;
  onOpenCreateTopic: (classId?: string, activityId?: string) => void;
  onEditTopic: (topic: ForumTopic) => void;
  onDeleteTopic: (topicId: string) => void;
  onToggleTopicStatus: (topicId: string) => void;
  onToggleTopicPin: (topicId: string) => void;
  onAddComment: (commentData: Omit<ForumComment, 'id' | 'createdAt'>) => void;
  onDeleteComment: (commentId: string) => void;
  onToggleLikeComment: (commentId: string) => void;
  onToggleHighlightComment: (commentId: string) => void;
  onNavigateToActivity?: (activityId: string) => void;
}

export const ForumView: React.FC<ForumViewProps> = ({
  data,
  currentUser,
  periodsConfig,
  initialTopicId,
  initialClassId,
  onOpenCreateTopic,
  onEditTopic,
  onDeleteTopic,
  onToggleTopicStatus,
  onToggleTopicPin,
  onAddComment,
  onDeleteComment,
  onToggleLikeComment,
  onToggleHighlightComment,
  onNavigateToActivity
}) => {
  const isEducator = currentUser.role === 'admin' || currentUser.role === 'teacher';
  const allowedClasses = useMemo(() => {
    return getAllowedClasses(data.classes, currentUser, data.students);
  }, [data.classes, currentUser, data.students]);

  // Selected topic for thread view
  const [selectedTopicId, setSelectedTopicId] = useState<string | null>(initialTopicId || null);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClassId, setSelectedClassId] = useState<string>(initialClassId || 'all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Comment input state
  const [newCommentText, setNewCommentText] = useState('');
  const [replyingToCommentId, setReplyingToCommentId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [commentAttachments, setCommentAttachments] = useState<AttachedFile[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadPercent, setUploadPercent] = useState<number | null>(null);

  // Fallback safe arrays
  const topics = useMemo(() => data.forumTopics || [], [data.forumTopics]);
  const comments = useMemo(() => data.forumComments || [], [data.forumComments]);

  // If initialTopicId changes externally
  React.useEffect(() => {
    if (initialTopicId) {
      setSelectedTopicId(initialTopicId);
    }
  }, [initialTopicId]);

  // Student specific class filtering
  const student = useMemo(() => {
    if (currentUser.role !== 'student') return null;
    return (
      data.students.find(
        s =>
          s.userId === currentUser.id ||
          s.id === currentUser.id ||
          s.name.toLowerCase() === currentUser.name.toLowerCase()
      ) || null
    );
  }, [currentUser, data.students]);

  const studentClassIds = useMemo(() => {
    if (!student) return new Set<string>();
    return new Set<string>([student.classId, ...(student.enrolledClassIds || [])]);
  }, [student]);

  // Accessible topics according to user role
  const visibleTopics = useMemo(() => {
    return topics.filter(t => {
      // Role visibility: students can view topics of their classes or 'all'
      if (currentUser.role === 'student') {
        if (t.classId !== 'all' && !studentClassIds.has(t.classId)) {
          return false;
        }
      }
      return true;
    });
  }, [topics, currentUser.role, studentClassIds]);

  // Filtered topics list
  const filteredTopics = useMemo(() => {
    return visibleTopics.filter(t => {
      // Class filter
      if (selectedClassId !== 'all' && t.classId !== selectedClassId) {
        return false;
      }
      // Category filter
      if (categoryFilter !== 'all') {
        if (categoryFilter === 'has_activity' && !t.activityId) return false;
        if (categoryFilter !== 'has_activity' && t.category !== categoryFilter) return false;
      }
      // Status filter
      if (statusFilter !== 'all' && t.status !== statusFilter) {
        return false;
      }
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = t.title.toLowerCase().includes(q);
        const matchesDesc = t.description.toLowerCase().includes(q);
        const matchesAuthor = t.authorName.toLowerCase().includes(q);
        // Also check if any comment in this topic contains search query
        const topicComments = comments.filter(c => c.topicId === t.id);
        const matchesComment = topicComments.some(
          c => c.content.toLowerCase().includes(q) || c.authorName.toLowerCase().includes(q)
        );
        return matchesTitle || matchesDesc || matchesAuthor || matchesComment;
      }
      return true;
    }).sort((a, b) => {
      // Pinned topics first
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }, [visibleTopics, selectedClassId, categoryFilter, statusFilter, searchQuery, comments]);

  // Selected topic details
  const activeTopic = useMemo(() => {
    if (!selectedTopicId) return null;
    return topics.find(t => t.id === selectedTopicId) || null;
  }, [topics, selectedTopicId]);

  // Linked activity if any
  const linkedActivity = useMemo(() => {
    if (!activeTopic?.activityId) return null;
    return data.activities.find(a => a.id === activeTopic.activityId) || null;
  }, [activeTopic, data.activities]);

  // Comments for the active topic
  const activeTopicComments = useMemo(() => {
    if (!selectedTopicId) return [];
    return comments
      .filter(c => c.topicId === selectedTopicId)
      .sort((a, b) => {
        // Highlighted first, then chronological
        if (a.highlighted && !b.highlighted) return -1;
        if (!a.highlighted && b.highlighted) return 1;
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      });
  }, [comments, selectedTopicId]);

  // Map of root comments vs replies
  const rootComments = useMemo(() => {
    return activeTopicComments.filter(c => !c.parentId);
  }, [activeTopicComments]);

  const getRepliesForComment = (parentId: string) => {
    return activeTopicComments.filter(c => c.parentId === parentId);
  };

  // Upload attachment for new comment
  const handleUploadCommentFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsUploading(true);
      setUploadPercent(10);
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
      const storagePath = `forum_opinions/${Date.now()}_${safeName}`;

      let downloadUrl = '';
      try {
        const res = await uploadFileToStorage(file, storagePath, pct => {
          setUploadPercent(pct);
        });
        downloadUrl = res.downloadUrl;
      } catch (err) {
        console.warn('File upload fallback:', err);
      }

      const newAtt: AttachedFile = {
        id: `att-comment-${Date.now()}`,
        name: file.name,
        size: file.size,
        type: file.type.startsWith('image/')
          ? 'image'
          : file.type.includes('pdf')
          ? 'pdf'
          : 'document',
        mime: file.type,
        storageUrl: downloadUrl || undefined,
        storagePath: storagePath,
        uploadedAt: new Date().toISOString()
      };

      setCommentAttachments(prev => [...prev, newAtt]);
      setIsUploading(false);
      setUploadPercent(null);
    } catch (err) {
      console.error('Error uploading opinion file:', err);
      setIsUploading(false);
      setUploadPercent(null);
    }
  };

  // Submit comment
  const handlePostComment = (e?: React.FormEvent, parentId?: string) => {
    if (e) e.preventDefault();
    const text = parentId ? replyText : newCommentText;
    if (!text.trim() || !activeTopic) return;

    onAddComment({
      topicId: activeTopic.id,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorRole: currentUser.role,
      authorAvatar: currentUser.avatar,
      studentGrade: student ? `${student.grade} "${student.section}"` : undefined,
      content: text.trim(),
      parentId: parentId || undefined,
      isTeacherFeedback: isEducator,
      attachments: parentId ? undefined : commentAttachments.length > 0 ? commentAttachments : undefined,
      likes: []
    });

    if (parentId) {
      setReplyingToCommentId(null);
      setReplyText('');
    } else {
      setNewCommentText('');
      setCommentAttachments([]);
    }
  };

  // Helper for class label
  const getClassLabel = (clsId: string) => {
    if (clsId === 'all') return 'Toda la institución';
    const c = data.classes.find(cls => cls.id === clsId);
    return c ? `${c.name} (${c.grade} "${c.section}")` : 'Clase específica';
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs">
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-[#236a2d]/10 text-[#236a2d]">
            <MessagesSquare className="h-7 w-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black tracking-tight text-[#141d16]">
                Foro Escolar y Debates
              </h1>
              <span className="rounded-full bg-[#eef5ee] px-2.5 py-0.5 text-xs font-bold text-[#236a2d]">
                {visibleTopics.length} {visibleTopics.length === 1 ? 'tema' : 'temas'}
              </span>
            </div>
            <p className="mt-0.5 text-xs text-[#526456]">
              Espacio colaborativo de la Escuela Hogar de Amor y Esperanza para opinar sobre temas y tareas.
              Las respuestas son visibles para todos los alumnos y docentes.
            </p>
          </div>
        </div>

        {/* Action Button: Teacher / Admin ONLY */}
        {isEducator ? (
          <button
            onClick={() => onOpenCreateTopic(selectedClassId !== 'all' ? selectedClassId : undefined)}
            className="flex items-center justify-center gap-2 rounded-2xl bg-[#236a2d] px-5 py-3 text-xs font-bold text-white shadow-sm hover:bg-[#1b5323] transition-colors shrink-0"
          >
            <Plus className="h-4 w-4" />
            <span>Nueva actividad en el foro</span>
          </button>
        ) : (
          <div className="flex items-center gap-2 rounded-2xl border border-[#dfe6df] bg-[#f9faf9] px-4 py-2.5 text-xs text-[#526456]">
            <Info className="h-4 w-4 text-[#236a2d] shrink-0" />
            <span>
              <strong>Modo Alumno:</strong> El maestro o dirección publica los temas; tú puedes opinar y leer las respuestas de todos.
            </span>
          </div>
        )}
      </div>

      {/* Main Content: Split between List View and Active Topic Thread */}
      {selectedTopicId && activeTopic ? (
        /* DETAIL / THREAD VIEW */
        <div className="space-y-6 animate-fade-in">
          {/* Back button & quick navigation */}
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSelectedTopicId(null)}
              className="flex items-center gap-1.5 rounded-2xl border border-[#dfe6df] bg-white px-4 py-2 text-xs font-bold text-[#526456] hover:bg-[#f4f7f4] hover:text-[#141d16] transition-colors shadow-xs"
            >
              <ChevronLeft className="h-4 w-4" />
              <span>Volver a la lista de temas</span>
            </button>

            {/* Educator Controls */}
            {isEducator && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onToggleTopicPin(activeTopic.id)}
                  className={`flex items-center gap-1 rounded-2xl border px-3 py-1.5 text-xs font-semibold transition-colors ${
                    activeTopic.pinned
                      ? 'border-amber-300 bg-amber-50 text-amber-800'
                      : 'border-[#dfe6df] bg-white text-[#526456] hover:bg-[#f4f7f4]'
                  }`}
                  title={activeTopic.pinned ? 'Desfijar de la parte superior' : 'Fijar tema'}
                >
                  <Pin className="h-3.5 w-3.5" />
                  <span>{activeTopic.pinned ? 'Fijado' : 'Fijar'}</span>
                </button>

                <button
                  onClick={() => onToggleTopicStatus(activeTopic.id)}
                  className={`flex items-center gap-1 rounded-2xl border px-3 py-1.5 text-xs font-semibold transition-colors ${
                    activeTopic.status === 'open'
                      ? 'border-emerald-300 bg-emerald-50 text-emerald-800'
                      : 'border-red-300 bg-red-50 text-red-800'
                  }`}
                  title={activeTopic.status === 'open' ? 'Cerrar foro para nuevas respuestas' : 'Reabrir foro'}
                >
                  {activeTopic.status === 'open' ? (
                    <>
                      <Unlock className="h-3.5 w-3.5" />
                      <span>Abierto</span>
                    </>
                  ) : (
                    <>
                      <Lock className="h-3.5 w-3.5" />
                      <span>Cerrado</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => onEditTopic(activeTopic)}
                  className="flex items-center gap-1 rounded-2xl border border-[#dfe6df] bg-white px-3 py-1.5 text-xs font-semibold text-[#526456] hover:bg-[#f4f7f4] transition-colors"
                >
                  <Edit className="h-3.5 w-3.5" />
                  <span>Editar</span>
                </button>

                <button
                  onClick={() => {
                    if (confirm('¿Estás seguro de eliminar este tema del foro y todas sus respuestas?')) {
                      onDeleteTopic(activeTopic.id);
                      setSelectedTopicId(null);
                    }
                  }}
                  className="flex items-center gap-1 rounded-2xl border border-red-200 bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-600 hover:bg-red-100 transition-colors"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  <span>Eliminar</span>
                </button>
              </div>
            )}
          </div>

          {/* Topic Master Card */}
          <div className="rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs space-y-5">
            {/* Header info */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#dfe6df] pb-4">
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-xl bg-[#236a2d]/10 px-2.5 py-1 text-xs font-bold text-[#236a2d]">
                  {activeTopic.category === 'tarea'
                    ? '📝 Tarea en discusión'
                    : activeTopic.category === 'debate'
                    ? '💬 Debate de opinión'
                    : activeTopic.category === 'pregunta'
                    ? '💡 Pregunta detonadora'
                    : activeTopic.category === 'lectura'
                    ? '📖 Discusión de lectura'
                    : '📢 Foro institucional'}
                </span>

                <span className="rounded-xl border border-[#dfe6df] bg-[#f4f7f4] px-2.5 py-1 text-xs font-medium text-[#526456]">
                  {getClassLabel(activeTopic.classId)}
                </span>

                {activeTopic.parcial && (
                  <span className="rounded-xl border border-[#dfe6df] bg-white px-2.5 py-1 text-xs font-bold text-[#141d16]">
                    {activeTopic.parcial}° Parcial
                  </span>
                )}

                {activeTopic.status === 'closed' && (
                  <span className="flex items-center gap-1 rounded-xl bg-red-100 px-2.5 py-1 text-xs font-bold text-red-700">
                    <Lock className="h-3 w-3" />
                    Foro cerrado
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2 text-xs text-[#526456]">
                <Clock className="h-3.5 w-3.5" />
                <span>Creado el {formatDate(activeTopic.createdAt)}</span>
              </div>
            </div>

            {/* Title & Author */}
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-[#141d16] leading-tight">
                {activeTopic.title}
              </h2>
              <div className="mt-2 flex items-center gap-2.5">
                <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#236a2d] text-[11px] font-bold text-white">
                  {getInitials(activeTopic.authorName)}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-[#141d16]">
                    {activeTopic.authorName}
                  </span>
                  <span className="rounded-full bg-[#236a2d]/10 px-2 py-0.5 text-[10px] font-bold text-[#236a2d]">
                    {activeTopic.authorRole === 'admin' ? '🛡️ Dirección' : '🎓 Docente'}
                  </span>
                </div>
              </div>
            </div>

            {/* Linked Homework Card if present */}
            {linkedActivity && (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border border-emerald-200 bg-emerald-50/60 p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#236a2d] text-white">
                    <CheckSquare className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-[#236a2d] uppercase tracking-wider">
                        Tarea Vinculada
                      </span>
                      <span className="rounded-full bg-white px-2 py-0.5 text-[10px] font-bold text-[#141d16] border border-emerald-200">
                        {linkedActivity.value} puntos
                      </span>
                    </div>
                    <p className="text-sm font-bold text-[#141d16]">{linkedActivity.title}</p>
                    <p className="text-xs text-[#526456]">
                      Fecha de entrega: {linkedActivity.deadline || linkedActivity.date}
                    </p>
                  </div>
                </div>

                {onNavigateToActivity && (
                  <button
                    onClick={() => onNavigateToActivity(linkedActivity.id)}
                    className="flex items-center gap-1.5 rounded-xl border border-emerald-300 bg-white px-3.5 py-2 text-xs font-bold text-[#236a2d] hover:bg-emerald-50 transition-colors shadow-2xs self-start sm:self-auto"
                  >
                    <span>Ver detalle de la tarea</span>
                  </button>
                )}
              </div>
            )}

            {/* Description / Instructions */}
            <div className="rounded-2xl border border-[#dfe6df] bg-[#f9faf9] p-5">
              <h3 className="text-xs font-bold text-[#526456] uppercase tracking-wider mb-2">
                Consigna y planteamiento del debate:
              </h3>
              <p className="text-sm sm:text-base leading-relaxed text-[#141d16] whitespace-pre-wrap">
                {activeTopic.description}
              </p>
            </div>

            {/* Attached Resources */}
            {activeTopic.attachments && activeTopic.attachments.length > 0 && (
              <div className="space-y-2">
                <h4 className="flex items-center gap-1.5 text-xs font-bold text-[#526456] uppercase tracking-wider">
                  <Paperclip className="h-3.5 w-3.5 text-[#236a2d]" />
                  <span>Archivos y lecturas adjuntas ({activeTopic.attachments.length})</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {activeTopic.attachments.map(att => (
                    <div
                      key={att.id}
                      className="flex items-center justify-between gap-3 rounded-2xl border border-[#dfe6df] bg-white p-3 hover:border-[#236a2d] transition-colors"
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        <FileText className="h-5 w-5 text-[#236a2d] shrink-0" />
                        <div className="truncate">
                          <p className="text-xs font-bold text-[#141d16] truncate">{att.name}</p>
                          <p className="text-[11px] text-[#526456]">{formatFileSize(att.size)}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => downloadAttachedFile(att)}
                        className="flex items-center gap-1 rounded-xl bg-[#f4f7f4] px-2.5 py-1.5 text-xs font-bold text-[#236a2d] hover:bg-[#eef5ee] transition-colors shrink-0"
                      >
                        <Download className="h-3.5 w-3.5" />
                        <span>Descargar</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* OPINIONS & RESPONSES SECTION */}
          <div className="rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#dfe6df] pb-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#236a2d]/10 text-[#236a2d]">
                  <MessageSquare className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-[#141d16]">
                    Opiniones y respuestas de la comunidad
                  </h3>
                  <p className="text-xs text-[#526456]">
                    Todas las respuestas son públicas para los alumnos y maestros de la clase.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="rounded-full bg-[#f4f7f4] border border-[#dfe6df] px-3 py-1 text-xs font-bold text-[#141d16]">
                  {activeTopicComments.length} {activeTopicComments.length === 1 ? 'opinión' : 'opiniones'}
                </span>
              </div>
            </div>

            {/* New Opinion Input Form */}
            {activeTopic.status === 'open' ? (
              <form onSubmit={e => handlePostComment(e)} className="rounded-2xl border border-[#dfe6df] bg-[#f9faf9] p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#236a2d] text-xs font-bold text-white">
                      {getInitials(currentUser.name)}
                    </div>
                    <span className="text-xs font-bold text-[#141d16]">
                      Opinar como: {currentUser.name}
                    </span>
                    <span className="rounded-full bg-[#236a2d]/10 px-2 py-0.5 text-[10px] font-bold text-[#236a2d]">
                      {currentUser.role === 'student'
                        ? '✏️ Alumno'
                        : currentUser.role === 'teacher'
                        ? '🎓 Docente'
                        : '🛡️ Dirección'}
                    </span>
                  </div>
                  <span className="text-[11px] text-[#526456]">
                    Visible para todos los alumnos y docentes
                  </span>
                </div>

                <textarea
                  required
                  rows={3}
                  value={newCommentText}
                  onChange={e => setNewCommentText(e.target.value)}
                  placeholder={
                    currentUser.role === 'student'
                      ? 'Escribe tu opinión, respuesta o dudas sobre el tema/tarea... (Tus compañeros y maestros la leerán)'
                      : 'Escribe tu intervención docente, retroalimentación o pregunta de profundización...'
                  }
                  className="w-full rounded-2xl border border-[#dfe6df] bg-white p-3 text-sm font-medium text-[#141d16] focus:border-[#236a2d] focus:outline-hidden"
                />

                {/* Uploaded attachments preview */}
                {commentAttachments.length > 0 && (
                  <div className="space-y-1.5">
                    {commentAttachments.map(att => (
                      <div
                        key={att.id}
                        className="flex items-center justify-between rounded-xl border border-[#dfe6df] bg-white px-3 py-1 text-xs text-[#141d16]"
                      >
                        <div className="flex items-center gap-2 truncate">
                          <FileText className="h-3.5 w-3.5 text-[#236a2d]" />
                          <span className="font-medium truncate">{att.name}</span>
                          <span className="text-[#526456]">({formatFileSize(att.size)})</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setCommentAttachments(prev => prev.filter(a => a.id !== att.id))}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                  {/* Attach file to opinion */}
                  <label className="flex items-center gap-1.5 cursor-pointer rounded-xl border border-[#dfe6df] bg-white px-3 py-1.5 text-xs font-semibold text-[#526456] hover:bg-[#f4f7f4] transition-colors">
                    {isUploading ? (
                      <>
                        <Loader2 className="h-3.5 w-3.5 animate-spin text-[#236a2d]" />
                        <span>Subiendo ({uploadPercent || 0}%)...</span>
                      </>
                    ) : (
                      <>
                        <Paperclip className="h-3.5 w-3.5 text-[#236a2d]" />
                        <span>Adjuntar archivo o imagen</span>
                      </>
                    )}
                    <input
                      type="file"
                      disabled={isUploading}
                      onChange={handleUploadCommentFile}
                      className="hidden"
                      accept=".pdf,.png,.jpg,.jpeg,.doc,.docx,.txt"
                    />
                  </label>

                  <button
                    type="submit"
                    disabled={!newCommentText.trim() || isUploading}
                    className="flex items-center gap-2 rounded-xl bg-[#236a2d] px-5 py-2 text-xs font-bold text-white shadow-xs hover:bg-[#1b5323] disabled:opacity-50 transition-colors"
                  >
                    <Send className="h-3.5 w-3.5" />
                    <span>Publicar mi respuesta</span>
                  </button>
                </div>
              </form>
            ) : (
              <div className="flex items-center gap-3 rounded-2xl border border-amber-200 bg-amber-50/70 p-4 text-xs text-amber-800">
                <Lock className="h-5 w-5 text-amber-600 shrink-0" />
                <div>
                  <p className="font-bold">Este foro ha sido cerrado por el docente</p>
                  <p>Puedes leer todas las opiniones compartidas, pero no se aceptan nuevas intervenciones.</p>
                </div>
              </div>
            )}

            {/* Comments Feed */}
            {activeTopicComments.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-[#dfe6df] p-10 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#eef5ee] text-[#236a2d] mb-3">
                  <MessageSquare className="h-6 w-6" />
                </div>
                <h4 className="text-sm font-bold text-[#141d16]">Aún no hay opiniones publicadas</h4>
                <p className="mt-1 text-xs text-[#526456] max-w-md">
                  {currentUser.role === 'student'
                    ? '¡Sé el primero en compartir tu opinión o respuesta sobre esta actividad!'
                    : 'Los alumnos aún no han publicado sus opiniones. Puedes publicar una pregunta guía para motivar el debate.'}
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {rootComments.map(comment => {
                  const replies = getRepliesForComment(comment.id);
                  const isAuthor = comment.authorId === currentUser.id;
                  const isLikedByMe = (comment.likes || []).includes(currentUser.id);

                  return (
                    <div
                      key={comment.id}
                      className={`rounded-2xl border p-4.5 transition-all ${
                        comment.highlighted
                          ? 'border-amber-300 bg-amber-50/40 shadow-xs'
                          : comment.authorRole === 'teacher' || comment.authorRole === 'admin'
                          ? 'border-emerald-200 bg-[#f7faf7]'
                          : 'border-[#dfe6df] bg-white'
                      }`}
                    >
                      {/* Highlighted Banner */}
                      {comment.highlighted && (
                        <div className="mb-2.5 flex items-center gap-1.5 text-xs font-bold text-amber-800">
                          <Award className="h-4 w-4 text-amber-600" />
                          <span>Respuesta destacada por el docente</span>
                        </div>
                      )}

                      {/* Comment Header */}
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold text-white ${
                              comment.authorRole === 'admin'
                                ? 'bg-[#141d16]'
                                : comment.authorRole === 'teacher'
                                ? 'bg-[#236a2d]'
                                : 'bg-[#3b82f6]'
                            }`}
                          >
                            {getInitials(comment.authorName)}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-[#141d16]">
                                {comment.authorName}
                              </span>
                              <span
                                className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                                  comment.authorRole === 'admin'
                                    ? 'bg-[#141d16]/10 text-[#141d16]'
                                    : comment.authorRole === 'teacher'
                                    ? 'bg-[#236a2d]/10 text-[#236a2d]'
                                    : 'bg-blue-50 text-blue-700'
                                }`}
                              >
                                {comment.authorRole === 'admin'
                                  ? '🛡️ Dirección'
                                  : comment.authorRole === 'teacher'
                                  ? '🎓 Docente'
                                  : '✏️ Alumno'}
                              </span>
                              {comment.studentGrade && (
                                <span className="text-[11px] text-[#526456]">
                                  • {comment.studentGrade}
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-[#526456]">
                              {formatDate(comment.createdAt)}
                            </span>
                          </div>
                        </div>

                        {/* Educator Options */}
                        <div className="flex items-center gap-1">
                          {isEducator && (
                            <button
                              onClick={() => onToggleHighlightComment(comment.id)}
                              className={`flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-semibold transition-colors ${
                                comment.highlighted
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'text-[#526456] hover:bg-[#f4f7f4] hover:text-amber-700'
                              }`}
                              title={comment.highlighted ? 'Quitar destacado' : 'Destacar como respuesta ejemplar'}
                            >
                              <Award className="h-3.5 w-3.5" />
                              <span className="hidden sm:inline">
                                {comment.highlighted ? 'Destacada' : 'Destacar'}
                              </span>
                            </button>
                          )}

                          {(isEducator || isAuthor) && (
                            <button
                              onClick={() => {
                                if (confirm('¿Deseas eliminar este comentario del foro?')) {
                                  onDeleteComment(comment.id);
                                }
                              }}
                              className="rounded-lg p-1 text-[#526456] hover:bg-red-50 hover:text-red-600 transition-colors"
                              title="Eliminar comentario"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Comment Body */}
                      <div className="mt-3 text-sm text-[#141d16] leading-relaxed whitespace-pre-wrap pl-10">
                        {comment.content}
                      </div>

                      {/* Comment Attachments */}
                      {comment.attachments && comment.attachments.length > 0 && (
                        <div className="mt-3 pl-10 space-y-1.5">
                          {comment.attachments.map(att => (
                            <div
                              key={att.id}
                              className="inline-flex items-center gap-2 rounded-xl border border-[#dfe6df] bg-[#f9faf9] px-3 py-1.5 text-xs text-[#141d16] mr-2"
                            >
                              <FileText className="h-3.5 w-3.5 text-[#236a2d]" />
                              <span className="font-medium truncate max-w-xs">{att.name}</span>
                              <button
                                onClick={() => downloadAttachedFile(att)}
                                className="text-[#236a2d] hover:text-[#1b5323] p-0.5"
                                title="Descargar archivo"
                              >
                                <Download className="h-3 w-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Actions: Likes & Reply */}
                      <div className="mt-3 flex items-center gap-3 pl-10 pt-2 border-t border-[#dfe6df]/60 text-xs">
                        <button
                          onClick={() => onToggleLikeComment(comment.id)}
                          className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 font-semibold transition-colors ${
                            isLikedByMe
                              ? 'bg-[#236a2d]/10 text-[#236a2d]'
                              : 'text-[#526456] hover:bg-[#f4f7f4] hover:text-[#141d16]'
                          }`}
                        >
                          <ThumbsUp className={`h-3.5 w-3.5 ${isLikedByMe ? 'fill-[#236a2d]' : ''}`} />
                          <span>{(comment.likes || []).length}</span>
                          <span className="hidden sm:inline">Me gusta</span>
                        </button>

                        {activeTopic.status === 'open' && (
                          <button
                            onClick={() => {
                              if (replyingToCommentId === comment.id) {
                                setReplyingToCommentId(null);
                              } else {
                                setReplyingToCommentId(comment.id);
                                setReplyText('');
                              }
                            }}
                            className="flex items-center gap-1 text-[#526456] hover:text-[#236a2d] font-semibold px-2 py-1 rounded-lg hover:bg-[#f4f7f4] transition-colors"
                          >
                            <MessageSquare className="h-3.5 w-3.5" />
                            <span>Responder</span>
                          </button>
                        )}
                      </div>

                      {/* Nested Replies */}
                      {replies.length > 0 && (
                        <div className="mt-3 pl-10 space-y-2 border-l-2 border-[#dfe6df] ml-4">
                          {replies.map(reply => {
                            const isReplyAuthor = reply.authorId === currentUser.id;
                            const isReplyLiked = (reply.likes || []).includes(currentUser.id);

                            return (
                              <div
                                key={reply.id}
                                className={`rounded-xl border p-3 ${
                                  reply.authorRole === 'teacher' || reply.authorRole === 'admin'
                                    ? 'border-emerald-200 bg-[#f7faf7]'
                                    : 'border-[#dfe6df] bg-[#f9faf9]'
                                }`}
                              >
                                <div className="flex items-center justify-between gap-2">
                                  <div className="flex items-center gap-2">
                                    <div
                                      className={`flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold text-white ${
                                        reply.authorRole === 'admin'
                                          ? 'bg-[#141d16]'
                                          : reply.authorRole === 'teacher'
                                          ? 'bg-[#236a2d]'
                                          : 'bg-[#3b82f6]'
                                      }`}
                                    >
                                      {getInitials(reply.authorName)}
                                    </div>
                                    <span className="text-xs font-bold text-[#141d16]">
                                      {reply.authorName}
                                    </span>
                                    <span
                                      className={`rounded-full px-1.5 py-0.2 text-[9px] font-bold ${
                                        reply.authorRole === 'teacher' || reply.authorRole === 'admin'
                                          ? 'bg-[#236a2d]/10 text-[#236a2d]'
                                          : 'bg-blue-50 text-blue-700'
                                      }`}
                                    >
                                      {reply.authorRole === 'admin'
                                        ? '🛡️ Dirección'
                                        : reply.authorRole === 'teacher'
                                        ? '🎓 Docente'
                                        : '✏️ Alumno'}
                                    </span>
                                    <span className="text-[10px] text-[#526456]">
                                      {formatDate(reply.createdAt)}
                                    </span>
                                  </div>

                                  {(isEducator || isReplyAuthor) && (
                                    <button
                                      onClick={() => onDeleteComment(reply.id)}
                                      className="text-[#526456] hover:text-red-600 p-1"
                                      title="Eliminar respuesta"
                                    >
                                      <Trash2 className="h-3 w-3" />
                                    </button>
                                  )}
                                </div>

                                <p className="mt-1.5 text-xs text-[#141d16] leading-relaxed whitespace-pre-wrap pl-8">
                                  {reply.content}
                                </p>

                                <div className="mt-2 flex items-center gap-2 pl-8 text-[11px]">
                                  <button
                                    onClick={() => onToggleLikeComment(reply.id)}
                                    className={`flex items-center gap-1 font-semibold ${
                                      isReplyLiked ? 'text-[#236a2d]' : 'text-[#526456]'
                                    }`}
                                  >
                                    <ThumbsUp className={`h-3 w-3 ${isReplyLiked ? 'fill-[#236a2d]' : ''}`} />
                                    <span>{(reply.likes || []).length}</span>
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {/* Reply Input Box */}
                      {replyingToCommentId === comment.id && (
                        <div className="mt-3 pl-10 border-t border-[#dfe6df] pt-3 animate-fade-in">
                          <div className="flex items-center justify-between mb-1.5 text-xs text-[#526456]">
                            <span>Respondiendo a <strong>{comment.authorName}</strong></span>
                            <button
                              onClick={() => setReplyingToCommentId(null)}
                              className="text-xs text-red-500 hover:underline"
                            >
                              Cancelar
                            </button>
                          </div>
                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={replyText}
                              onChange={e => setReplyText(e.target.value)}
                              placeholder="Escribe tu respuesta a esta opinión..."
                              className="flex-1 rounded-xl border border-[#dfe6df] bg-white px-3 py-2 text-xs font-medium text-[#141d16] focus:border-[#236a2d] focus:outline-hidden"
                              onKeyDown={e => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                  e.preventDefault();
                                  handlePostComment(undefined, comment.id);
                                }
                              }}
                            />
                            <button
                              onClick={() => handlePostComment(undefined, comment.id)}
                              disabled={!replyText.trim()}
                              className="rounded-xl bg-[#236a2d] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#1b5323] disabled:opacity-50 transition-colors"
                            >
                              <Send className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      ) : (
        /* TOPICS LIST / FEED VIEW */
        <div className="space-y-6">
          {/* Filters Bar */}
          <div className="flex flex-col lg:flex-row gap-3 rounded-2xl border border-[#dfe6df] bg-white p-4 shadow-xs">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#526456]" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Buscar temas, consignas, tareas o intervenciones de alumnos..."
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f4f7f4] py-2 pl-9 pr-3 text-xs font-medium text-[#141d16] focus:border-[#236a2d] focus:bg-white focus:outline-hidden"
              />
            </div>

            {/* Class filter */}
            <select
              value={selectedClassId}
              onChange={e => setSelectedClassId(e.target.value)}
              className="rounded-xl border border-[#dfe6df] bg-[#f4f7f4] px-3 py-2 text-xs font-semibold text-[#141d16] focus:border-[#236a2d] focus:bg-white focus:outline-hidden"
            >
              <option value="all">🏫 Todas las clases</option>
              {allowedClasses.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.grade} "{c.section}")
                </option>
              ))}
            </select>

            {/* Category filter */}
            <select
              value={categoryFilter}
              onChange={e => setCategoryFilter(e.target.value)}
              className="rounded-xl border border-[#dfe6df] bg-[#f4f7f4] px-3 py-2 text-xs font-semibold text-[#141d16] focus:border-[#236a2d] focus:bg-white focus:outline-hidden"
            >
              <option value="all">📂 Todos los tipos</option>
              <option value="has_activity">📝 Vinculados a Tareas</option>
              <option value="debate">💬 Debates de opinión</option>
              <option value="pregunta">💡 Preguntas detonadoras</option>
              <option value="lectura">📖 Discusiones de lectura</option>
              <option value="proyecto">🔬 Avances de proyecto</option>
            </select>

            {/* Status filter */}
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="rounded-xl border border-[#dfe6df] bg-[#f4f7f4] px-3 py-2 text-xs font-semibold text-[#141d16] focus:border-[#236a2d] focus:bg-white focus:outline-hidden"
            >
              <option value="all">Estado: Todos</option>
              <option value="open">🟢 Abiertos para opiniones</option>
              <option value="closed">🔒 Cerrados</option>
            </select>
          </div>

          {/* Topics Grid */}
          {filteredTopics.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-3xl border border-dashed border-[#dfe6df] bg-white p-12 text-center shadow-xs">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#eef5ee] text-[#236a2d] mb-4">
                <MessagesSquare className="h-7 w-7" />
              </div>
              <h3 className="text-base font-bold text-[#141d16]">No se encontraron temas en el foro</h3>
              <p className="mt-1 text-xs text-[#526456] max-w-md">
                {searchQuery || selectedClassId !== 'all' || categoryFilter !== 'all'
                  ? 'Intenta ajustar los filtros de búsqueda para encontrar temas disponibles.'
                  : isEducator
                  ? 'Crea el primer tema de debate o vincula una tarea para que los alumnos comiencen a opinar.'
                  : 'Aún no hay temas de debate creados por tus docentes para tus clases.'}
              </p>

              {isEducator && (
                <button
                  onClick={() => onOpenCreateTopic(selectedClassId !== 'all' ? selectedClassId : undefined)}
                  className="mt-4 flex items-center gap-2 rounded-2xl bg-[#236a2d] px-5 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-[#1b5323] transition-colors"
                >
                  <Plus className="h-4 w-4" />
                  <span>Crear actividad en el foro</span>
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredTopics.map(topic => {
                const topicComments = comments.filter(c => c.topicId === topic.id);
                const hasTask = Boolean(topic.activityId);
                const task = hasTask ? data.activities.find(a => a.id === topic.activityId) : null;
                const highlightedCount = topicComments.filter(c => c.highlighted).length;

                return (
                  <div
                    key={topic.id}
                    onClick={() => setSelectedTopicId(topic.id)}
                    className="group relative flex flex-col justify-between rounded-3xl border border-[#dfe6df] bg-white p-5 shadow-xs hover:shadow-md hover:border-[#236a2d] transition-all cursor-pointer"
                  >
                    <div>
                      {/* Top Badges & Status */}
                      <div className="flex items-center justify-between gap-2 mb-3">
                        <div className="flex flex-wrap items-center gap-1.5">
                          {topic.pinned && (
                            <span className="flex items-center gap-1 rounded-lg bg-amber-100 px-2 py-0.5 text-[10px] font-bold text-amber-800">
                              <Pin className="h-3 w-3" />
                              Fijado
                            </span>
                          )}

                          <span className="rounded-lg bg-[#236a2d]/10 px-2 py-0.5 text-[10px] font-bold text-[#236a2d]">
                            {topic.category === 'tarea'
                              ? '📝 Tarea'
                              : topic.category === 'debate'
                              ? '💬 Debate'
                              : topic.category === 'pregunta'
                              ? '💡 Pregunta'
                              : topic.category === 'lectura'
                              ? '📖 Lectura'
                              : '📢 General'}
                          </span>

                          <span className="rounded-lg border border-[#dfe6df] bg-[#f4f7f4] px-2 py-0.5 text-[10px] font-medium text-[#526456]">
                            {getClassLabel(topic.classId)}
                          </span>
                        </div>

                        <div>
                          {topic.status === 'open' ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700">
                              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                              Abierto
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-red-600">
                              <Lock className="h-3 w-3" />
                              Cerrado
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Topic Title */}
                      <h3 className="text-base font-bold text-[#141d16] group-hover:text-[#236a2d] transition-colors line-clamp-2">
                        {topic.title}
                      </h3>

                      {/* Description preview */}
                      <p className="mt-2 text-xs text-[#526456] line-clamp-3 leading-relaxed">
                        {topic.description}
                      </p>

                      {/* Linked Activity Badge */}
                      {task && (
                        <div className="mt-3 flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50/50 px-2.5 py-1.5 text-xs text-[#236a2d]">
                          <CheckSquare className="h-3.5 w-3.5 shrink-0" />
                          <span className="font-semibold truncate">Tarea: {task.title}</span>
                          <span className="text-[10px] font-bold shrink-0">({task.value} pts)</span>
                        </div>
                      )}
                    </div>

                    {/* Card Footer */}
                    <div className="mt-4 pt-3 border-t border-[#dfe6df] flex items-center justify-between text-xs text-[#526456]">
                      <div className="flex items-center gap-2">
                        <div className="flex h-5 w-5 items-center justify-center rounded-full bg-[#236a2d] text-[9px] font-bold text-white">
                          {getInitials(topic.authorName)}
                        </div>
                        <span className="font-medium truncate max-w-[110px]">
                          {topic.authorName}
                        </span>
                      </div>

                      <div className="flex items-center gap-2.5 font-semibold text-[#141d16]">
                        {highlightedCount > 0 && (
                          <span className="flex items-center gap-0.5 text-amber-600 text-[11px]" title="Respuestas destacadas">
                            <Award className="h-3.5 w-3.5" />
                            <span>{highlightedCount}</span>
                          </span>
                        )}

                        <span className="flex items-center gap-1 text-xs">
                          <MessageSquare className="h-3.5 w-3.5 text-[#236a2d]" />
                          <span>{topicComments.length}</span>
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
