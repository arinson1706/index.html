import React, { useState } from 'react';
import {
  FileText,
  Plus,
  Search,
  Star,
  Download,
  Edit,
  Trash2,
  FileSpreadsheet,
  FileCode,
  Image,
  Video,
  File,
  ShieldCheck,
  Cloud
} from 'lucide-react';
import { AppData, Resource, User } from '../../types';
import { formatFileSize, formatDate } from '../../utils/storage';
import { getAllowedResources } from '../../utils/rbac';

interface ResourcesViewProps {
  data: AppData;
  currentUser?: User | null;
  onAddResource: () => void;
  onEditResource: (resource: Resource) => void;
  onDeleteResource: (id: string) => void;
  onDownloadResource: (id: string) => void;
  onToggleFavorite: (id: string) => void;
}

export const ResourcesView: React.FC<ResourcesViewProps> = ({
  data,
  currentUser,
  onAddResource,
  onEditResource,
  onDeleteResource,
  onDownloadResource,
  onToggleFavorite
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [onlyFavorites, setOnlyFavorites] = useState(false);
  const [typeFilter, setTypeFilter] = useState('');
  const [originFilter, setOriginFilter] = useState('');

  const isStudent = currentUser?.role === 'student';
  const isAdmin = currentUser?.role === 'admin';

  const userResources = getAllowedResources(
    data.resources,
    currentUser,
    data.students,
    data.classes
  );

  const getFileIcon = (type: string) => {
    switch (type?.toUpperCase()) {
      case 'PDF':
        return <FileText className="h-5 w-5 text-[#c6292e]" />;
      case 'XLSX':
        return <FileSpreadsheet className="h-5 w-5 text-[#2f8b3c]" />;
      case 'PPTX':
        return <FileCode className="h-5 w-5 text-[#f5c400]" />;
      case 'IMAGEN':
        return <Image className="h-5 w-5 text-[#236a2d]" />;
      case 'VIDEO':
        return <Video className="h-5 w-5 text-[#9f1d24]" />;
      default:
        return <File className="h-5 w-5 text-[#5d685f]" />;
    }
  };

  const filteredResources = userResources.filter(r => {
    const q = searchTerm.toLowerCase();
    const matchesSearch =
      r.name.toLowerCase().includes(q) ||
      (r.subject || '').toLowerCase().includes(q) ||
      (r.topic || '').toLowerCase().includes(q) ||
      (r.grade || '').toLowerCase().includes(q) ||
      (r.uploadedByName || '').toLowerCase().includes(q);
    const matchesFav = !onlyFavorites || r.favorite;
    const matchesType = !typeFilter || r.type === typeFilter;
    const isFromAdmin = r.uploadedByRole === 'admin' || r.classId === 'admin';
    const matchesOrigin =
      !originFilter ||
      (originFilter === 'admin' && isFromAdmin) ||
      (originFilter === 'teacher' && !isFromAdmin);

    return matchesSearch && matchesFav && matchesType && matchesOrigin;
  });

  const getClassName = (id: string) => {
    if (id === 'admin') return 'Institucional (Administración)';
    return data.classes.find(c => c.id === id)?.name || 'General / Todos';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col justify-between gap-4 rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs sm:flex-row sm:items-center">
        <div>
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#c6292e]">
            Biblioteca de Materiales
          </span>
          <h2 className="mt-1 text-2xl font-black text-[#26302b] sm:text-3xl">Recursos educativos</h2>
          <p className="mt-1 text-xs text-[#6d766f]">
            {isStudent
              ? 'Consulta y descarga los materiales institucionales y guías educativas compartidas.'
              : 'Sube, clasifica y comparte tus guías, presentaciones, fichas y evaluaciones.'}
          </p>
        </div>

        {!isStudent && (
          <button
            onClick={onAddResource}
            className="flex items-center justify-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2.5 text-xs font-bold text-white shadow-sm transition hover:bg-[#9f1d24]"
          >
            <Plus className="h-4 w-4" />
            <span>{isAdmin ? 'Subir recurso institucional' : 'Subir recurso'}</span>
          </button>
        )}
      </div>

      {/* Toolbar */}
      <div className="flex flex-col gap-3 rounded-2xl border border-[#dfe6df] bg-white p-3 shadow-xs sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-[#6d766f]" />
          <input
            type="text"
            placeholder="Buscar por nombre, materia, tema o unidad..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] py-2 pl-9 pr-4 text-xs outline-none transition focus:border-[#2f8b3c] focus:bg-white"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={originFilter}
            onChange={e => setOriginFilter(e.target.value)}
            className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-2 text-xs font-bold text-[#435047] outline-none focus:border-[#2f8b3c]"
          >
            <option value="">Todos los orígenes</option>
            <option value="admin">🏢 Subido por Administración</option>
            <option value="teacher">👨‍🏫 Subido por Docentes</option>
          </select>

          <button
            onClick={() => setOnlyFavorites(!onlyFavorites)}
            className={`flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold transition ${
              onlyFavorites
                ? 'border border-[#f5c400] bg-[#fff7cc] text-[#735f00]'
                : 'border border-[#dfe6df] bg-[#f7f8f6] text-[#5d685f] hover:bg-white'
            }`}
          >
            <Star className={`h-3.5 w-3.5 ${onlyFavorites ? 'fill-[#f5c400]' : ''}`} />
            <span>Favoritos ({data.resources.filter(r => r.favorite).length})</span>
          </button>

          <select
            value={typeFilter}
            onChange={e => setTypeFilter(e.target.value)}
            className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-2 text-xs font-bold text-[#435047] outline-none focus:border-[#2f8b3c]"
          >
            <option value="">Todos los tipos</option>
            <option value="PDF">PDF</option>
            <option value="DOCX">DOCX</option>
            <option value="PPTX">PPTX</option>
            <option value="XLSX">XLSX</option>
            <option value="Imagen">Imagen</option>
            <option value="Video">Video</option>
            <option value="Otro">Otro</option>
          </select>
        </div>
      </div>

      {/* Grid of resources */}
      {filteredResources.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-[#cad4cb] bg-white p-12 text-center shadow-xs">
          <FileText className="mx-auto h-12 w-12 text-[#cad4cb] mb-3" />
          <h3 className="text-sm font-extrabold text-[#26302b]">No hay recursos que coincidan</h3>
          <p className="mt-1 text-xs text-[#6d766f]">
            {searchTerm || onlyFavorites || typeFilter || originFilter
              ? 'Prueba modificando tus filtros o búsqueda.'
              : 'Los materiales educativos aparecerán listados aquí.'}
          </p>
          {!isStudent && (
            <button
              onClick={onAddResource}
              className="mt-4 inline-flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-[#9f1d24]"
            >
              <Plus className="h-4 w-4" />
              <span>Subir primer recurso</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredResources.map(r => {
            const isFromAdmin = r.uploadedByRole === 'admin' || r.classId === 'admin';

            return (
              <div
                key={r.id}
                className="flex flex-col justify-between rounded-3xl border border-[#dfe6df] bg-white p-5 shadow-xs transition hover:shadow-md"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-[#f7f8f6] border border-[#dfe6df]">
                        {getFileIcon(r.type)}
                      </div>
                      <div>
                        <span className="inline-block rounded-md bg-[#eef2ee] px-1.5 py-0.5 text-[10px] font-extrabold text-[#5d685f]">
                          {r.type}
                        </span>
                        <span className="ml-1.5 text-[11px] text-[#6d766f]">{formatFileSize(r.size)}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => onToggleFavorite(r.id)}
                      className="p-1 text-[#6d766f] transition hover:text-[#f5c400]"
                      title={r.favorite ? 'Quitar de favoritos' : 'Marcar favorito'}
                    >
                      <Star className={`h-4 w-4 ${r.favorite ? 'fill-[#f5c400] text-[#f5c400]' : ''}`} />
                    </button>
                  </div>

                  {/* Badges */}
                  <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                    {isFromAdmin ? (
                      <span className="inline-flex items-center gap-1 rounded-lg border border-[#c6292e]/20 bg-[#fde7e7] px-2 py-0.5 text-[10px] font-extrabold text-[#c6292e]">
                        <ShieldCheck className="h-3 w-3" />
                        <span>Subido por Administración</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 rounded-lg border border-[#dfe6df] bg-[#f7f8f6] px-2 py-0.5 text-[10px] font-bold text-[#546057]">
                        <span>Docente: {r.uploadedByName || 'Titular'}</span>
                      </span>
                    )}

                    {r.grade && r.grade !== 'Todos' && (
                      <span className="rounded-lg bg-[#eaf6ec] px-2 py-0.5 text-[10px] font-bold text-[#236a2d]">
                        Grado: {r.grade}
                      </span>
                    )}

                    {r.storageUrl && (
                      <span className="inline-flex items-center gap-1 rounded-lg border border-[#2f8b3c]/20 bg-[#eaf6ec] px-2 py-0.5 text-[10px] font-bold text-[#236a2d]" title="Alojado en Firebase Cloud Storage">
                        <Cloud className="h-3 w-3" />
                        <span>Cloud Storage</span>
                      </span>
                    )}
                  </div>

                  <div className="mt-3">
                    <strong className="block text-sm font-extrabold text-[#26302b] line-clamp-2 leading-snug">
                      {r.name}
                    </strong>
                    <div className="mt-1 text-xs text-[#6d766f]">
                      {r.subject && <span className="font-semibold text-[#2f8b3c]">{r.subject} · </span>}
                      <span>{getClassName(r.classId)}</span>
                    </div>
                    {r.topic && (
                      <div className="mt-1 text-[11px] text-[#546057] line-clamp-1">
                        Tema: {r.topic} {r.unit ? `(${r.unit})` : ''}
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-5 border-t border-[#dfe6df] pt-3 flex items-center justify-between">
                  <span className="text-[10px] text-[#6d766f]">{formatDate(r.date)}</span>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onDownloadResource(r.id)}
                      className="flex items-center gap-1 rounded-xl bg-[#2f8b3c] px-3.5 py-1.5 text-xs font-bold text-white shadow-xs transition hover:bg-[#236a2d]"
                      title="Descargar archivo"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>Descargar</span>
                    </button>

                    {!isStudent && (
                      <>
                        <button
                          onClick={() => onEditResource(r)}
                          className="rounded-lg p-1.5 text-[#5d685f] hover:bg-[#eef2ee]"
                          title="Editar recurso"
                        >
                          <Edit className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => onDeleteResource(r.id)}
                          className="rounded-lg p-1.5 text-[#c6292e] hover:bg-[#fde7e7]"
                          title="Eliminar recurso"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
