import React, { useState, useMemo } from 'react';
import {
  Users,
  LayoutGrid,
  BarChart3,
  CheckSquare,
  FileText,
  Plus,
  ArrowRight,
  Clock,
  Sparkles,
  Download,
  Star,
  GraduationCap,
  Building2,
  Calendar,
  MessagesSquare
} from 'lucide-react';
import { AppData, User, ActiveSection } from '../../types';
import {
  calculateGlobalAverage,
  calculateClassAverage,
  calculateStudentAverage,
  calculateStudentAttendancePercentage,
  isStudentInClass,
  formatDate,
  formatFileSize
} from '../../utils/storage';
import { getAllowedClasses, getAllowedResources } from '../../utils/rbac';

interface DashboardViewProps {
  data: AppData;
  currentUser: User;
  onNavigate: (section: ActiveSection) => void;
  onOpenAddStudent: () => void;
  onOpenAddClass: () => void;
  onOpenAddResource: () => void;
  onOpenAddActivity: () => void;
  onOpenAddPlan: () => void;
  onDownloadResource: (id: string) => void;
  onToggleFavoriteResource: (id: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  data,
  currentUser,
  onNavigate,
  onOpenAddStudent,
  onOpenAddClass,
  onOpenAddResource,
  onOpenAddActivity,
  onOpenAddPlan,
  onDownloadResource,
  onToggleFavoriteResource
}) => {
  const [selectedActivityGrade, setSelectedActivityGrade] = useState<string>('all');
  const [selectedResourceGrade, setSelectedResourceGrade] = useState<string>('all');

  // Student specific dashboard view
  if (currentUser.role === 'student') {
    const student = data.students.find(s => s.userId === currentUser.id) || data.students[0];
    const studentClasses = student ? data.classes.filter(c => isStudentInClass(student, c)) : [];
    const studentClassIds = new Set(studentClasses.map(c => c.id));
    
    // Average across all classes of their grade
    const classAverages = studentClasses.map(c => calculateStudentAverage(student.id, c.id, data.grades, data.activities));
    const avg = classAverages.length > 0
      ? Math.round(classAverages.reduce((a, b) => a + b, 0) / classAverages.length)
      : (student ? calculateStudentAverage(student.id, student.classId, data.grades, data.activities) : 0);

    // Attendance across all classes of their grade
    const attAverages = studentClasses.map(c => calculateStudentAttendancePercentage(student.id, c.id, data.attendance));
    const att = attAverages.length > 0
      ? Math.round(attAverages.reduce((a, b) => a + b, 0) / attAverages.length)
      : 100;

    const classActivities = data.activities.filter(a => studentClassIds.has(a.classId) || a.classId === student?.classId);
    // Student sees both their class resources and institutional resources uploaded by admin
    const studentResources = getAllowedResources(data.resources, currentUser, data.students, data.classes);

    return (
      <div className="space-y-6">
        <div className="flex flex-col justify-between gap-4 rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs sm:flex-row sm:items-center">
          <div>
            <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#c6292e]">Portal del Alumno</span>
            <h2 className="mt-1 text-2xl font-black text-[#26302b] sm:text-3xl">Hola, {currentUser.name} 👋</h2>
            <p className="mt-1 text-xs text-[#6d766f]">
              {studentClasses.length > 0 ? `Matriculado en ${studentClasses.length} ${studentClasses.length === 1 ? 'materia' : 'materias'}` : 'Bienvenido a tu espacio académico.'}
              {student?.grade && <span> · Grado: <strong>{student.grade}</strong></span>}
              {student?.section && <span> (Sec. {student.section})</span>}
            </p>
          </div>
          <button
            onClick={() => onNavigate('activities')}
            className="flex items-center justify-center gap-2 rounded-xl bg-[#2f8b3c] px-4 py-2.5 text-xs font-bold text-white shadow-xs transition hover:bg-[#236a2d]"
          >
            <CheckSquare className="h-4 w-4" />
            <span>Ver mis tareas</span>
          </button>
        </div>

        {/* Student metrics */}
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <div className="flex items-center justify-between rounded-2xl border border-[#dfe6df] bg-white p-5 shadow-xs">
            <div>
              <div className="text-xs font-bold text-[#6d766f]">Mi promedio</div>
              <div className="mt-1 text-2xl font-black text-[#26302b]">{avg}%</div>
              <div className="text-[10px] text-[#6d766f]">Rendimiento acumulado</div>
            </div>
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#eaf6ec] text-[#2f8b3c]">
              <BarChart3 className="h-5 w-5" />
            </div>
          </div>

          <div className="flex items-center justify-between rounded-2xl border border-[#dfe6df] bg-white p-5 shadow-xs">
            <div>
              <div className="text-xs font-bold text-[#6d766f]">Mi asistencia</div>
              <div className="mt-1 text-2xl font-black text-[#26302b]">{att}%</div>
              <div className="text-[10px] text-[#2f8b3c] font-semibold">Registro activo</div>
            </div>
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#fff7cc] text-[#735f00]">
              <Clock className="h-5 w-5" />
            </div>
          </div>

          <div className="flex items-center justify-between rounded-2xl border border-[#dfe6df] bg-white p-5 shadow-xs">
            <div>
              <div className="text-xs font-bold text-[#6d766f]">Tareas asignadas</div>
              <div className="mt-1 text-2xl font-black text-[#26302b]">{classActivities.length}</div>
              <div className="text-[10px] text-[#6d766f]">En mis clases</div>
            </div>
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#eef2ee] text-[#26302b]">
              <CheckSquare className="h-5 w-5" />
            </div>
          </div>

          <div className="flex items-center justify-between rounded-2xl border border-[#dfe6df] bg-white p-5 shadow-xs">
            <div>
              <div className="text-xs font-bold text-[#6d766f]">Recursos de estudio</div>
              <div className="mt-1 text-2xl font-black text-[#26302b]">{studentResources.length}</div>
              <div className="text-[10px] text-[#6d766f]">Disponibles para descarga</div>
            </div>
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#fde7e7] text-[#c6292e]">
              <FileText className="h-5 w-5" />
            </div>
          </div>
        </div>

        {/* Student Activities and Resources */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Student Activities */}
          <div className="rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs lg:col-span-7">
            <div className="flex items-center justify-between border-b border-[#dfe6df] pb-3 mb-4">
              <div>
                <h3 className="text-sm font-extrabold text-[#26302b]">Mis tareas y asignaciones</h3>
                <span className="text-[11px] text-[#6d766f]">Fechas de entrega programadas</span>
              </div>
              <button
                onClick={() => onNavigate('activities')}
                className="text-xs font-bold text-[#2f8b3c] hover:underline"
              >
                Ver todas →
              </button>
            </div>

            {classActivities.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-[#cad4cb] bg-[#fcfdfc] p-8 text-center text-xs text-[#6d766f]">
                No tienes tareas pendientes asignadas actualmente.
              </div>
            ) : (
              <div className="space-y-2.5">
                {classActivities.slice(0, 5).map(act => (
                  <div
                    key={act.id}
                    className="flex items-center justify-between rounded-2xl border border-[#dfe6df] bg-white p-3.5"
                  >
                    <div>
                      <strong className="block text-xs font-extrabold text-[#26302b]">{act.title}</strong>
                      <span className="text-[11px] text-[#6d766f]">
                        Valor: {act.value} pts · Vence: {formatDate(act.deadline)}
                      </span>
                    </div>
                    <span
                      className={`rounded-full px-2.5 py-0.5 text-[10px] font-black ${
                        act.status === 'Calificada'
                          ? 'bg-[#eaf6ec] text-[#236a2d]'
                          : act.status === 'Entregada'
                          ? 'bg-[#fff7cc] text-[#735f00]'
                          : 'bg-[#f7f8f6] text-[#26302b] border border-[#dfe6df]'
                      }`}
                    >
                      {act.status}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Student Resources */}
          <div className="rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs lg:col-span-5">
            <div className="flex items-center justify-between border-b border-[#dfe6df] pb-3 mb-4">
              <div>
                <h3 className="text-sm font-extrabold text-[#26302b]">Materiales de apoyo</h3>
                <span className="text-[11px] text-[#6d766f]">Guías y recursos descargables</span>
              </div>
              <button
                onClick={() => onNavigate('resources')}
                className="text-xs font-bold text-[#2f8b3c] hover:underline"
              >
                Ver biblioteca →
              </button>
            </div>

            {studentResources.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-[#cad4cb] bg-[#fcfdfc] p-6 text-center text-xs text-[#6d766f]">
                No hay recursos disponibles por ahora.
              </div>
            ) : (
              <div className="space-y-2.5">
                {studentResources.slice(0, 4).map(res => (
                  <div
                    key={res.id}
                    className="flex items-center justify-between rounded-2xl border border-[#dfe6df] bg-white p-3"
                  >
                    <div className="min-w-0 pr-2">
                      <strong className="block truncate text-xs font-bold text-[#26302b]">{res.name}</strong>
                      <span className="text-[10px] text-[#6d766f]">
                        {res.uploadedByRole === 'admin' ? '🏛️ Administración' : res.type} · {formatFileSize(res.size)}
                      </span>
                    </div>
                    <button
                      onClick={() => onDownloadResource(res.id)}
                      className="shrink-0 rounded-xl bg-[#eef2ee] px-2.5 py-1 text-xs font-bold text-[#26302b] hover:bg-[#dfe6df]"
                    >
                      Descargar
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Student Forum Quick Access */}
        {(() => {
          const studentTopics = (data.forumTopics || []).filter(
            t => t.classId === 'all' || studentClassIds.has(t.classId)
          );
          return (
            <div className="rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#dfe6df] pb-4 mb-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#236a2d]/10 text-[#236a2d]">
                    <MessagesSquare className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-extrabold text-[#26302b]">Foro escolar y debates de clase</h3>
                    <p className="text-[11px] text-[#6d766f]">
                      Opina sobre temas y tareas. Todos los compañeros y maestros pueden ver tus respuestas.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => onNavigate('forum')}
                  className="flex items-center gap-1.5 text-xs font-bold text-[#236a2d] hover:underline self-start sm:self-auto"
                >
                  <span>Ver todos los debates ({studentTopics.length})</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>

              {studentTopics.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-[#dfe6df] bg-[#fcfdfc] p-6 text-center text-xs text-[#6d766f]">
                  No hay debates abiertos actualmente. Tu maestro publicará actividades de debate aquí.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {studentTopics.slice(0, 3).map(top => {
                    const commentCount = (data.forumComments || []).filter(c => c.topicId === top.id).length;
                    return (
                      <div
                        key={top.id}
                        onClick={() => onNavigate('forum')}
                        className="flex flex-col justify-between rounded-2xl border border-[#dfe6df] bg-[#f9faf9] p-4 hover:border-[#236a2d] hover:bg-white transition cursor-pointer"
                      >
                        <div>
                          <div className="flex items-center justify-between gap-2 mb-1.5">
                            <span className="rounded-lg bg-[#236a2d]/10 px-2 py-0.5 text-[10px] font-bold text-[#236a2d]">
                              {top.category === 'tarea' ? '📝 Tarea' : '💬 Debate'}
                            </span>
                            <span className="text-[10px] text-[#6d766f]">
                              {formatDate(top.createdAt)}
                            </span>
                          </div>
                          <h4 className="text-xs font-bold text-[#26302b] line-clamp-2">
                            {top.title}
                          </h4>
                        </div>
                        <div className="mt-3 flex items-center justify-between text-[11px] text-[#6d766f] pt-2 border-t border-[#dfe6df]/60">
                          <span>Por: {top.authorName}</span>
                          <span className="font-bold text-[#236a2d]">{commentCount} opiniones</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })()}
      </div>
    );
  }

  // Teacher / Admin Dashboard Scope
  const allowedClasses = getAllowedClasses(data.classes, currentUser, data.students);
  const allowedClassIds = new Set(allowedClasses.map(c => c.id));

  const relevantActivities = useMemo(() => {
    if (currentUser.role === 'admin') return data.activities;
    return data.activities.filter(a => allowedClassIds.has(a.classId));
  }, [currentUser, data.activities, allowedClassIds]);

  const relevantStudents = useMemo(() => {
    if (currentUser.role === 'admin') return data.students;
    return data.students.filter(s => allowedClasses.some(c => isStudentInClass(s, c)));
  }, [currentUser, data.students, allowedClasses]);

  const globalAvg = calculateGlobalAverage(relevantStudents, data.grades, data.activities);
  const pendingCount = relevantActivities.filter(a => a.status !== 'Calificada').length;

  const getClassName = (id: string) => data.classes.find(c => c.id === id)?.name || 'Sin clase';
  const getClassGrade = (id: string) => data.classes.find(c => c.id === id)?.grade || 'General';

  // Extract distinct grades from allowed classes for activity filtering
  const distinctGrades = useMemo(() => {
    const set = new Set<string>();
    allowedClasses.forEach(c => {
      if (c.grade) set.add(c.grade);
    });
    return Array.from(set).sort();
  }, [allowedClasses]);

  // Upcoming activities sorted by deadline and filtered by Grade
  const filteredUpcomingActivities = useMemo(() => {
    let list = [...relevantActivities].filter(a => a.status !== 'Calificada');
    if (selectedActivityGrade !== 'all') {
      list = list.filter(a => {
        const c = data.classes.find(cls => cls.id === a.classId);
        return c?.grade === selectedActivityGrade;
      });
    }
    return list.sort((a, b) => a.deadline.localeCompare(b.deadline)).slice(0, 6);
  }, [relevantActivities, selectedActivityGrade, data.classes]);

  // Distinct resource categories/grades
  const resourceCategories = useMemo(() => {
    const set = new Set<string>();
    set.add('Administración');
    data.resources.forEach(r => {
      if (r.grade) set.add(r.grade);
      const c = data.classes.find(cls => cls.id === r.classId);
      if (c?.grade) set.add(c.grade);
    });
    return Array.from(set).sort();
  }, [data.resources, data.classes]);

  // Recent resources filtered by Grade or Administration
  const filteredRecentResources = useMemo(() => {
    let list = getAllowedResources(data.resources, currentUser, data.students, data.classes);
    if (selectedResourceGrade !== 'all') {
      if (selectedResourceGrade === 'Administración') {
        list = list.filter(r => r.uploadedByRole === 'admin' || r.classId === 'admin');
      } else {
        list = list.filter(r => {
          if (r.grade === selectedResourceGrade) return true;
          const c = data.classes.find(cls => cls.id === r.classId);
          return c?.grade === selectedResourceGrade;
        });
      }
    }
    return list.slice(0, 5);
  }, [data.resources, selectedResourceGrade, data.classes, currentUser, data.students]);

  return (
    <div className="space-y-6">
      {/* Hero Welcome banner */}
      <div className="flex flex-col justify-between gap-4 rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs sm:flex-row sm:items-center">
        <div>
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#c6292e]">
            {currentUser.role === 'admin' ? 'Administración Institucional' : 'Espacio de Trabajo Docente'}
          </span>
          <h2 className="mt-1 text-2xl font-black text-[#26302b] sm:text-3xl">
            Hola, {currentUser.name.split(' ')[0]} 👋
          </h2>
          <p className="mt-1 text-xs text-[#6d766f]">
            {currentUser.role === 'admin'
              ? 'Panel de control con gestión separada por grados, clases de docentes y recursos institucionales.'
              : `Gestionando ${allowedClasses.length} ${allowedClasses.length === 1 ? 'clase asignada' : 'clases asignadas'}.`}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={onOpenAddActivity}
            className="flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2.5 text-xs font-bold text-white shadow-sm transition hover:bg-[#9f1d24]"
          >
            <Plus className="h-4 w-4" />
            <span>Crear actividad</span>
          </button>
        </div>
      </div>

      {/* Top 4 Stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="flex items-center justify-between rounded-2xl border border-[#dfe6df] bg-white p-5 shadow-xs">
          <div>
            <div className="text-xs font-bold text-[#6d766f]">Clases activas</div>
            <div className="mt-1 text-2xl font-black text-[#26302b]">{allowedClasses.length}</div>
            <div className="text-[10px] text-[#6d766f]">
              {currentUser.role === 'admin' ? 'Total en la institución' : 'Asignadas a tu perfil'}
            </div>
          </div>
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#eaf6ec] text-[#2f8b3c]">
            <LayoutGrid className="h-5 w-5" />
          </div>
        </div>

        <div className="flex items-center justify-between rounded-2xl border border-[#dfe6df] bg-white p-5 shadow-xs">
          <div>
            <div className="text-xs font-bold text-[#6d766f]">Alumnos</div>
            <div className="mt-1 text-2xl font-black text-[#26302b]">{relevantStudents.length}</div>
            <div className="text-[10px] text-[#6d766f]">Matriculados</div>
          </div>
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#fff7cc] text-[#735f00]">
            <Users className="h-5 w-5" />
          </div>
        </div>

        <div className="flex items-center justify-between rounded-2xl border border-[#dfe6df] bg-white p-5 shadow-xs">
          <div>
            <div className="text-xs font-bold text-[#6d766f]">Promedio general</div>
            <div className="mt-1 text-2xl font-black text-[#26302b]">{globalAvg}%</div>
            <div className="text-[10px] text-[#2f8b3c] font-bold">Rendimiento escolar</div>
          </div>
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#eef2ee] text-[#26302b]">
            <BarChart3 className="h-5 w-5" />
          </div>
        </div>

        <div className="flex items-center justify-between rounded-2xl border border-[#dfe6df] bg-white p-5 shadow-xs">
          <div>
            <div className="text-xs font-bold text-[#6d766f]">Pendientes</div>
            <div className="mt-1 text-2xl font-black text-[#26302b]">{pendingCount}</div>
            <div className="text-[10px] text-[#c6292e] font-semibold">Por calificar</div>
          </div>
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#fde7e7] text-[#c6292e]">
            <CheckSquare className="h-5 w-5" />
          </div>
        </div>
      </div>

      {/* Quick Actions Panel */}
      <div className="rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs">
        <div className="flex items-center justify-between border-b border-[#dfe6df] pb-3 mb-4">
          <div>
            <h3 className="text-sm font-extrabold text-[#26302b]">Acciones rápidas</h3>
            <span className="text-[11px] text-[#6d766f]">Accesos directos para agilizar la gestión escolar.</span>
          </div>
          <span className="flex items-center gap-1 text-[11px] font-bold text-[#2f8b3c]">
            <Sparkles className="h-3.5 w-3.5" />
            Flujo de trabajo
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          <button
            onClick={onOpenAddStudent}
            className="flex flex-col items-start rounded-2xl border border-[#dfe6df] bg-white p-4 text-left transition hover:-translate-y-0.5 hover:border-[#2f8b3c] hover:shadow-xs"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#eaf6ec] text-[#2f8b3c]">
              <Users className="h-4 w-4" />
            </div>
            <strong className="mt-3 block text-xs font-bold text-[#26302b]">Agregar alumno</strong>
            <span className="text-[10px] text-[#6d766f]">Nuevo estudiante</span>
          </button>

          {currentUser.role === 'admin' && (
            <button
              onClick={onOpenAddClass}
              className="flex flex-col items-start rounded-2xl border border-[#dfe6df] bg-white p-4 text-left transition hover:-translate-y-0.5 hover:border-[#2f8b3c] hover:shadow-xs"
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#fff7cc] text-[#735f00]">
                <LayoutGrid className="h-4 w-4" />
              </div>
              <strong className="mt-3 block text-xs font-bold text-[#26302b]">Crear clase</strong>
              <span className="text-[10px] text-[#6d766f]">Asignar grado y docente</span>
            </button>
          )}

          <button
            onClick={onOpenAddResource}
            className="flex flex-col items-start rounded-2xl border border-[#dfe6df] bg-white p-4 text-left transition hover:-translate-y-0.5 hover:border-[#2f8b3c] hover:shadow-xs"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#eef2ee] text-[#26302b]">
              <FileText className="h-4 w-4" />
            </div>
            <strong className="mt-3 block text-xs font-bold text-[#26302b]">Subir recurso</strong>
            <span className="text-[10px] text-[#6d766f]">
              {currentUser.role === 'admin' ? 'Institucional / Admin' : 'Material didáctico'}
            </span>
          </button>

          <button
            onClick={() => onNavigate('grades')}
            className="flex flex-col items-start rounded-2xl border border-[#dfe6df] bg-white p-4 text-left transition hover:-translate-y-0.5 hover:border-[#2f8b3c] hover:shadow-xs"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#fde7e7] text-[#c6292e]">
              <BarChart3 className="h-4 w-4" />
            </div>
            <strong className="mt-3 block text-xs font-bold text-[#26302b]">Registrar notas</strong>
            <span className="text-[10px] text-[#6d766f]">Evaluaciones</span>
          </button>

          <button
            onClick={onOpenAddPlan}
            className="flex flex-col items-start rounded-2xl border border-[#dfe6df] bg-white p-4 text-left transition hover:-translate-y-0.5 hover:border-[#2f8b3c] hover:shadow-xs"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#eaf6ec] text-[#2f8b3c]">
              <Plus className="h-4 w-4" />
            </div>
            <strong className="mt-3 block text-xs font-bold text-[#26302b]">Planificación</strong>
            <span className="text-[10px] text-[#6d766f]">Coordinación académica</span>
          </button>

          <button
            onClick={() => onNavigate('forum')}
            className="flex flex-col items-start rounded-2xl border border-[#dfe6df] bg-white p-4 text-left transition hover:-translate-y-0.5 hover:border-[#236a2d] hover:shadow-xs"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-[#236a2d]/10 text-[#236a2d]">
              <MessagesSquare className="h-4 w-4" />
            </div>
            <strong className="mt-3 block text-xs font-bold text-[#26302b]">Foro escolar</strong>
            <span className="text-[10px] text-[#6d766f]">Debates de clase</span>
          </button>
        </div>
      </div>

      {/* TWO COLUMN: UPCOMING ACTIVITIES GROUPED BY GRADE + RECENT RESOURCES GROUPED BY GRADE */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* UPCOMING ACTIVITIES SEPARATED BY GRADE */}
        <div className="flex flex-col justify-between rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs lg:col-span-6">
          <div>
            <div className="flex items-center justify-between border-b border-[#dfe6df] pb-3 mb-3">
              <div>
                <h3 className="text-sm font-extrabold text-[#26302b]">Próximas actividades y entregas</h3>
                <span className="text-[11px] text-[#6d766f]">Separadas por grado para control docente</span>
              </div>
              <button
                onClick={() => onNavigate('activities')}
                className="flex items-center gap-1 text-xs font-bold text-[#2f8b3c] hover:underline"
              >
                <span>Ver todas</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>

            {/* Grade Switcher Tabs for Activities */}
            <div className="flex flex-wrap items-center gap-1.5 mb-3">
              <button
                onClick={() => setSelectedActivityGrade('all')}
                className={`rounded-lg px-2.5 py-1 text-[11px] font-extrabold transition ${
                  selectedActivityGrade === 'all'
                    ? 'bg-[#c6292e] text-white shadow-xs'
                    : 'bg-[#f7f8f6] text-[#5d685f] hover:bg-[#eef2ee]'
                }`}
              >
                Todos los grados
              </button>
              {distinctGrades.map(grade => (
                <button
                  key={grade}
                  onClick={() => setSelectedActivityGrade(grade)}
                  className={`rounded-lg px-2.5 py-1 text-[11px] font-extrabold transition ${
                    selectedActivityGrade === grade
                      ? 'bg-[#2f8b3c] text-white shadow-xs'
                      : 'bg-[#f7f8f6] text-[#5d685f] hover:bg-[#eef2ee]'
                  }`}
                >
                  {grade}
                </button>
              ))}
            </div>

            {filteredUpcomingActivities.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-[#cad4cb] bg-[#fcfdfc] p-8 text-center text-xs text-[#6d766f]">
                <CheckSquare className="h-8 w-8 text-[#b9d3bd] mb-2" />
                <strong className="text-[#3c4840]">Sin entregas pendientes en este grado</strong>
                <span>No hay actividades pendientes en el filtro seleccionado.</span>
                <button
                  onClick={onOpenAddActivity}
                  className="mt-3 rounded-xl bg-[#2f8b3c] px-3.5 py-1.5 text-xs font-bold text-white shadow-xs"
                >
                  Crear actividad
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                {filteredUpcomingActivities.map(a => {
                  const grade = getClassGrade(a.classId);
                  return (
                    <div
                      key={a.id}
                      className="flex items-center justify-between rounded-2xl border border-[#dfe6df] bg-white p-3.5 transition hover:bg-[#fbfcfb]"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#fff7cc] text-[#735f00]">
                          <Clock className="h-4 w-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 mb-0.5">
                            <span className="rounded bg-[#eaf6ec] px-1.5 py-0.5 text-[10px] font-extrabold text-[#236a2d]">
                              {grade}
                            </span>
                            <span className="text-[11px] text-[#6d766f]">· {getClassName(a.classId)}</span>
                          </div>
                          <strong className="block truncate text-xs font-extrabold text-[#26302b]">{a.title}</strong>
                          <span className="block truncate text-[10px] text-[#6d766f]">
                            Valor: {a.value} pts · Vence: {formatDate(a.deadline)}
                          </span>
                        </div>
                      </div>
                      <span
                        className={`shrink-0 rounded-full px-2.5 py-0.5 text-[10px] font-extrabold ${
                          a.status === 'Entregada' ? 'bg-[#fff7cc] text-[#735f00]' : 'bg-[#eef2ee] text-[#5d685f]'
                        }`}
                      >
                        {a.status}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="mt-4 flex items-center justify-between text-xs text-[#6d766f] border-t border-[#dfe6df] pt-3">
            <span>Total actividades registradas: {relevantActivities.length}</span>
            <button onClick={() => onNavigate('calendar')} className="font-bold text-[#2f8b3c] hover:underline">
              Ir al calendario escolar →
            </button>
          </div>
        </div>

        {/* RECENT RESOURCES SEPARATED BY GRADE / INSTITUTIONAL */}
        <div className="flex flex-col justify-between rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs lg:col-span-6">
          <div>
            <div className="flex items-center justify-between border-b border-[#dfe6df] pb-3 mb-3">
              <div>
                <h3 className="text-sm font-extrabold text-[#26302b]">Recursos recientes</h3>
                <span className="text-[11px] text-[#6d766f]">Separados por grado y origen institucional</span>
              </div>
              <button
                onClick={() => onNavigate('resources')}
                className="text-xs font-bold text-[#2f8b3c] hover:underline"
              >
                Ver todos →
              </button>
            </div>

            {/* Category / Grade Switcher Tabs for Resources */}
            <div className="flex flex-wrap items-center gap-1.5 mb-3">
              <button
                onClick={() => setSelectedResourceGrade('all')}
                className={`rounded-lg px-2.5 py-1 text-[11px] font-extrabold transition ${
                  selectedResourceGrade === 'all'
                    ? 'bg-[#c6292e] text-white shadow-xs'
                    : 'bg-[#f7f8f6] text-[#5d685f] hover:bg-[#eef2ee]'
                }`}
              >
                Todos
              </button>
              {resourceCategories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedResourceGrade(cat)}
                  className={`rounded-lg px-2.5 py-1 text-[11px] font-extrabold transition ${
                    selectedResourceGrade === cat
                      ? cat === 'Administración'
                        ? 'bg-[#c6292e] text-white shadow-xs'
                        : 'bg-[#2f8b3c] text-white shadow-xs'
                      : 'bg-[#f7f8f6] text-[#5d685f] hover:bg-[#eef2ee]'
                  }`}
                >
                  {cat === 'Administración' ? '🏛️ Administración' : cat}
                </button>
              ))}
            </div>

            {filteredRecentResources.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-[#cad4cb] bg-[#fcfdfc] p-6 text-center text-xs text-[#6d766f]">
                No hay recursos en esta categoría o grado.
              </div>
            ) : (
              <div className="space-y-2.5">
                {filteredRecentResources.map(r => {
                  const isInstitutional = r.uploadedByRole === 'admin' || r.classId === 'admin';
                  const resGrade = r.grade || (r.classId ? getClassGrade(r.classId) : null);

                  return (
                    <div
                      key={r.id}
                      className="flex items-center justify-between rounded-2xl border border-[#dfe6df] bg-white p-3.5 transition hover:bg-[#fbfcfb]"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${
                            isInstitutional
                              ? 'bg-[#fde7e7] text-[#c6292e]'
                              : 'bg-[#eaf6ec] text-[#2f8b3c]'
                          }`}
                        >
                          {isInstitutional ? <Building2 className="h-4 w-4" /> : <FileText className="h-4 w-4" />}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 mb-0.5">
                            {isInstitutional ? (
                              <span className="rounded bg-[#fde7e7] px-1.5 py-0.5 text-[9px] font-black text-[#c6292e]">
                                Subido por Administración
                              </span>
                            ) : resGrade ? (
                              <span className="rounded bg-[#eaf6ec] px-1.5 py-0.5 text-[9px] font-black text-[#236a2d]">
                                {resGrade}
                              </span>
                            ) : null}
                            <span className="text-[11px] text-[#6d766f]">
                              {r.type} · {formatFileSize(r.size)}
                            </span>
                          </div>
                          <strong className="block truncate text-xs font-extrabold text-[#26302b]">{r.name}</strong>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => onToggleFavoriteResource(r.id)}
                          className={`p-1.5 rounded-lg transition ${
                            r.favorite ? 'text-[#f5c400] hover:bg-[#fff7cc]' : 'text-[#6d766f] hover:bg-[#eef2ee]'
                          }`}
                          title={r.favorite ? 'Quitar de favoritos' : 'Marcar favorito'}
                        >
                          <Star className={`h-4 w-4 ${r.favorite ? 'fill-[#f5c400]' : ''}`} />
                        </button>
                        <button
                          onClick={() => onDownloadResource(r.id)}
                          className="flex items-center gap-1 rounded-xl bg-[#eef2ee] px-2.5 py-1 text-xs font-bold text-[#26302b] hover:bg-[#dfe6df]"
                          title="Descargar archivo"
                        >
                          <Download className="h-3.5 w-3.5" />
                          <span className="hidden sm:inline">Descargar</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="mt-4 flex items-center justify-between text-xs text-[#6d766f] border-t border-[#dfe6df] pt-3">
            <span>Total materiales en biblioteca: {data.resources.length}</span>
            <button onClick={() => onNavigate('resources')} className="font-bold text-[#2f8b3c] hover:underline">
              Ir a la biblioteca completa →
            </button>
          </div>
        </div>
      </div>

      {/* Class summary card */}
      <div className="rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs">
        <div className="flex items-center justify-between border-b border-[#dfe6df] pb-3 mb-4">
          <div>
            <h3 className="text-sm font-extrabold text-[#26302b]">
              {currentUser.role === 'admin' ? 'Supervisión de Clases por Grado' : 'Resumen de Mis Clases'}
            </h3>
            <span className="text-[11px] text-[#6d766f]">Estudiantes y promedios por grupo</span>
          </div>
          <button onClick={() => onNavigate('classes')} className="text-xs font-bold text-[#2f8b3c] hover:underline">
            Ver clases →
          </button>
        </div>

        {allowedClasses.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-[#cad4cb] bg-[#fcfdfc] p-6 text-center text-xs text-[#6d766f]">
            No hay clases registradas para este perfil.
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
            {allowedClasses.map(c => {
              const count = data.students.filter(s => isStudentInClass(s, c)).length;
              const cAvg = calculateClassAverage(c, data.students, data.grades, data.classes, data.activities);
              const teacher = data.users.find(u => u.id === c.teacherId);

              return (
                <div key={c.id} className="rounded-2xl border border-[#dfe6df] bg-[#f7f8f6] p-4">
                  <div className="flex items-center justify-between text-xs">
                    <div>
                      <strong className="text-[#26302b]">{c.name}</strong>
                      <div className="text-[11px] text-[#6d766f]">
                        {c.grade && <span className="font-bold text-[#2f8b3c]">{c.grade} · </span>}
                        {count} alumnos
                      </div>
                      {currentUser.role === 'admin' && (
                        <div className="text-[10px] text-[#546057] mt-0.5">
                          Docente: <strong>{teacher?.name || 'Por asignar'}</strong>
                        </div>
                      )}
                    </div>
                    <strong className="text-sm font-black text-[#236a2d]">{cAvg}%</strong>
                  </div>
                  <div className="mt-2.5 h-2 w-full overflow-hidden rounded-full bg-[#edf1ed]">
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{
                        width: `${cAvg}%`,
                        background: 'linear-gradient(90deg, #c6292e, #f5c400, #2f8b3c)'
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
