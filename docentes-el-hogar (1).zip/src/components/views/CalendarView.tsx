import React, { useState } from 'react';
import { Calendar as CalendarIcon, Plus, ChevronLeft, ChevronRight, Trash2, Tag } from 'lucide-react';
import { AppData, CalendarEvent, User } from '../../types';
import { formatDate } from '../../utils/storage';

interface CalendarViewProps {
  data: AppData;
  currentUser?: User | null;
  onAddEvent: () => void;
  onDeleteEvent: (id: string) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  data,
  currentUser,
  onAddEvent,
  onDeleteEvent
}) => {
  const isStudent = currentUser?.role === 'student';
  const [viewMode, setViewMode] = useState<'month' | 'week' | 'day'>('month');
  const [currentDate, setCurrentDate] = useState<Date>(new Date());

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth(); // 0-indexed

  const monthNames = [
    'Enero',
    'Febrero',
    'Marzo',
    'Abril',
    'Mayo',
    'Junio',
    'Julio',
    'Agosto',
    'Septiembre',
    'Octubre',
    'Noviembre',
    'Diciembre'
  ];

  const handlePrev = () => {
    if (viewMode === 'month') {
      setCurrentDate(new Date(year, month - 1, 1));
    } else if (viewMode === 'week') {
      const d = new Date(currentDate);
      d.setDate(d.getDate() - 7);
      setCurrentDate(d);
    } else {
      const d = new Date(currentDate);
      d.setDate(d.getDate() - 1);
      setCurrentDate(d);
    }
  };

  const handleNext = () => {
    if (viewMode === 'month') {
      setCurrentDate(new Date(year, month + 1, 1));
    } else if (viewMode === 'week') {
      const d = new Date(currentDate);
      d.setDate(d.getDate() + 7);
      setCurrentDate(d);
    } else {
      const d = new Date(currentDate);
      d.setDate(d.getDate() + 1);
      setCurrentDate(d);
    }
  };

  const handleToday = () => {
    setCurrentDate(new Date());
  };

  const getEventBadgeClass = (type: CalendarEvent['type']) => {
    switch (type) {
      case 'Actividad':
        return 'bg-[#eaf6ec] text-[#236a2d] border border-[#2f8b3c]/20';
      case 'Evaluación':
        return 'bg-[#fde7e7] text-[#c6292e] border border-[#c6292e]/20';
      case 'Reunión':
        return 'bg-[#eef2ee] text-[#26302b] border border-[#dfe6df]';
      case 'Proyecto':
        return 'bg-[#fff7cc] text-[#735f00] border border-[#f5c400]/30';
      case 'Importante':
        return 'bg-[#c6292e] text-white';
      default:
        return 'bg-[#f7f8f6] text-[#5d685f]';
    }
  };

  // Build Month Days Grid
  const renderMonthGrid = () => {
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);

    // Monday as first day of week (0: Mon, 6: Sun)
    const startPadding = (firstDay.getDay() + 6) % 7;
    const totalDays = lastDay.getDate();

    const cells = [];

    // Blank padding cells
    for (let i = 0; i < startPadding; i++) {
      cells.push(<div key={`pad-${i}`} className="min-h-[100px] rounded-2xl bg-[#f7f8f6]/50 p-2" />);
    }

    // Actual day cells
    for (let day = 1; day <= totalDays; day++) {
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const dayEvents = data.events.filter(e => e.date === dateStr);

      const isToday =
        new Date().toDateString() === new Date(year, month, day).toDateString();

      cells.push(
        <div
          key={dateStr}
          className={`flex min-h-[100px] flex-col justify-between rounded-2xl border p-2 transition ${
            isToday ? 'border-[#2f8b3c] bg-[#eaf6ec]/30 shadow-xs' : 'border-[#dfe6df] bg-white hover:border-[#b9d3bd]'
          }`}
        >
          <div className="flex items-center justify-between">
            <span
              className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-black ${
                isToday ? 'bg-[#2f8b3c] text-white' : 'text-[#26302b]'
              }`}
            >
              {day}
            </span>
            {dayEvents.length > 0 && (
              <span className="text-[10px] font-bold text-[#6d766f]">{dayEvents.length} ev</span>
            )}
          </div>

          <div className="mt-1 flex-1 space-y-1 overflow-y-auto">
            {dayEvents.map(e => (
              <div
                key={e.id}
                className={`group flex items-center justify-between rounded-lg px-1.5 py-1 text-[10px] font-bold leading-tight ${getEventBadgeClass(
                  e.type
                )}`}
              >
                <span className="truncate">{e.title}</span>
                {!isStudent && (
                  <button
                    onClick={evt => {
                      evt.stopPropagation();
                      onDeleteEvent(e.id);
                    }}
                    className="hidden shrink-0 text-[#c6292e] hover:opacity-80 group-hover:inline-block ml-1"
                    title="Eliminar evento"
                  >
                    <Trash2 className="h-2.5 w-2.5" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      );
    }

    return (
      <div className="space-y-2">
        <div className="grid grid-cols-7 gap-2 text-center text-xs font-black uppercase tracking-wider text-[#6d766f]">
          {['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'].map(d => (
            <div key={d} className="py-1">
              {d}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-2">{cells}</div>
      </div>
    );
  };

  // Week Grid
  const renderWeekGrid = () => {
    const d = new Date(currentDate);
    const day = (d.getDay() + 6) % 7;
    d.setDate(d.getDate() - day);

    const weekDays = Array.from({ length: 7 }, (_, i) => {
      const dayDate = new Date(d);
      dayDate.setDate(d.getDate() + i);
      return dayDate;
    });

    return (
      <div className="grid grid-cols-1 gap-3 md:grid-cols-7">
        {weekDays.map(dayDate => {
          const y = dayDate.getFullYear();
          const m = String(dayDate.getMonth() + 1).padStart(2, '0');
          const dayNum = String(dayDate.getDate()).padStart(2, '0');
          const dateStr = `${y}-${m}-${dayNum}`;
          const dayEvents = data.events.filter(e => e.date === dateStr);
          const isToday = new Date().toDateString() === dayDate.toDateString();

          return (
            <div
              key={dateStr}
              className={`min-h-[220px] rounded-2xl border p-3 ${
                isToday ? 'border-[#2f8b3c] bg-[#eaf6ec]/30' : 'border-[#dfe6df] bg-white'
              }`}
            >
              <div className="border-b border-[#dfe6df] pb-2 text-center">
                <div className="text-[11px] font-bold text-[#6d766f]">
                  {dayDate.toLocaleDateString('es-ES', { weekday: 'short' })}
                </div>
                <div className={`text-base font-black ${isToday ? 'text-[#2f8b3c]' : 'text-[#26302b]'}`}>
                  {dayDate.getDate()}
                </div>
              </div>

              <div className="mt-2 space-y-1.5">
                {dayEvents.map(e => (
                  <div
                    key={e.id}
                    className={`rounded-xl p-2 text-xs font-bold ${getEventBadgeClass(e.type)}`}
                  >
                    <div className="flex items-center justify-between">
                      <span>{e.title}</span>
                      {!isStudent && (
                        <button
                          onClick={() => onDeleteEvent(e.id)}
                          className="text-[#c6292e] hover:opacity-80 ml-1"
                        >
                          <Trash2 className="h-3 w-3" />
                        </button>
                      )}
                    </div>
                    <span className="block text-[10px] font-medium opacity-80">{e.type}</span>
                  </div>
                ))}
                {dayEvents.length === 0 && (
                  <div className="pt-8 text-center text-[11px] text-[#cad4cb]">Sin eventos</div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  // Day View
  const renderDayView = () => {
    const y = currentDate.getFullYear();
    const m = String(currentDate.getMonth() + 1).padStart(2, '0');
    const d = String(currentDate.getDate()).padStart(2, '0');
    const dateStr = `${y}-${m}-${d}`;
    const dayEvents = data.events.filter(e => e.date === dateStr);

    return (
      <div className="rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs">
        <div className="flex items-center justify-between border-b border-[#dfe6df] pb-3 mb-4">
          <div>
            <h3 className="text-base font-black text-[#26302b]">
              Eventos para {currentDate.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
            </h3>
            <span className="text-xs text-[#6d766f]">{dayEvents.length} eventos programados</span>
          </div>
          {!isStudent && (
            <button
              onClick={onAddEvent}
              className="rounded-xl bg-[#2f8b3c] px-3.5 py-1.5 text-xs font-bold text-white shadow-xs"
            >
              ＋ Agregar evento hoy
            </button>
          )}
        </div>

        {dayEvents.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-[#cad4cb] bg-[#fcfdfc] p-8 text-center text-xs text-[#6d766f]">
            No hay eventos programados para este día.
          </div>
        ) : (
          <div className="space-y-3">
            {dayEvents.map(e => (
              <div
                key={e.id}
                className={`flex items-center justify-between rounded-2xl p-4 ${getEventBadgeClass(e.type)}`}
              >
                <div>
                  <strong className="block text-sm font-black">{e.title}</strong>
                  <span className="text-xs opacity-90">{e.type}</span>
                </div>
                {!isStudent && (
                  <button
                    onClick={() => onDeleteEvent(e.id)}
                    className="rounded-lg p-1.5 text-[#c6292e] hover:bg-white/50"
                    title="Eliminar evento"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col justify-between gap-4 rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs sm:flex-row sm:items-center">
        <div>
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#c6292e]">
            Gestión del Tiempo
          </span>
          <h2 className="mt-1 text-2xl font-black text-[#26302b] sm:text-3xl">Calendario escolar</h2>
          <p className="mt-1 text-xs text-[#6d766f]">
            Agenda evaluaciones, tareas, reuniones y fechas institucionales.
          </p>
        </div>

        {!isStudent && (
          <button
            onClick={onAddEvent}
            className="flex items-center justify-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2.5 text-xs font-bold text-white shadow-sm transition hover:bg-[#9f1d24]"
          >
            <Plus className="h-4 w-4" />
            <span>Nuevo evento</span>
          </button>
        )}
      </div>

      {/* Calendar Controls Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#dfe6df] bg-white p-3.5 shadow-xs">
        {/* Navigation buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={handlePrev}
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-[#dfe6df] bg-[#f7f8f6] text-[#26302b] hover:bg-[#eef2ee]"
            title="Anterior"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>

          <button
            onClick={handleToday}
            className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-1.5 text-xs font-bold text-[#26302b] hover:bg-[#eef2ee]"
          >
            Hoy
          </button>

          <button
            onClick={handleNext}
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-[#dfe6df] bg-[#f7f8f6] text-[#26302b] hover:bg-[#eef2ee]"
            title="Siguiente"
          >
            <ChevronRight className="h-4 w-4" />
          </button>

          <h3 className="ml-2 text-sm font-black text-[#26302b]">
            {monthNames[month]} {year}
          </h3>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center rounded-xl bg-[#eef2ee] p-1">
          {(['month', 'week', 'day'] as const).map(mode => (
            <button
              key={mode}
              onClick={() => setViewMode(mode)}
              className={`rounded-lg px-3 py-1.5 text-xs font-bold transition ${
                viewMode === mode ? 'bg-white text-[#236a2d] shadow-xs' : 'text-[#5d685f] hover:text-[#26302b]'
              }`}
            >
              {mode === 'month' ? 'Mes' : mode === 'week' ? 'Semana' : 'Día'}
            </button>
          ))}
        </div>
      </div>

      {/* Calendar View Container */}
      <div className="rounded-3xl border border-[#dfe6df] bg-white p-5 shadow-xs">
        {viewMode === 'month' && renderMonthGrid()}
        {viewMode === 'week' && renderWeekGrid()}
        {viewMode === 'day' && renderDayView()}
      </div>
    </div>
  );
};
