import React, { useState, useMemo } from 'react';
import {
  CheckSquare,
  Plus,
  Search,
  Calendar,
  BarChart3,
  Edit,
  Trash2,
  CheckCircle2,
  Eye,
  Award,
  Users,
  LayoutGrid,
  Clock,
  AlertCircle,
  MessageSquare,
  Paperclip,
  Download,
  Upload,
  FileText,
  FileSpreadsheet,
  Image,
  Video,
  File,
  Lock,
  Cloud,
  MessagesSquare
} from 'lucide-react';
import { AppData, Activity, ActivityStudentGrade, AttachedFile, User, PeriodsConfig, ParcialId } from '../../types';
import { formatDate, formatFileSize, isStudentInClass, getInitials, getActivePeriod, isPeriodClosed } from '../../utils/storage';
import { getAllowedClasses } from '../../utils/rbac';
import { downloadAttachedFile } from '../../utils/fileHelpers';
import { GradeActivityModal } from '../modals/GradeActivityModal';
import { SubmitHomeworkModal } from '../modals/SubmitHomeworkModal';

interface ActivitiesViewProps {
  data: AppData;
  currentUser?: User;
  periodsConfig?: PeriodsConfig;
  initialClassId?: string;
  onAddActivity: () => void;
  onEditActivity: (activity: Activity) => void;
  onDeleteActivity: (id: string) => void;
  onUpdateStatus: (id: string, status: Activity['status']) => void;
  onSaveActivityGrades: (
    activityId: string,
    scores: Record<string, number>,
    studentGrades: Record<string, ActivityStudentGrade>
  ) => void;
  onSubmitHomework?: (
    activityId: string,
    studentId: string,
    submissionData: {
      attachments: AttachedFile[];
      studentComment?: string;
    }
  ) => void;
  onGoToGrades: (classId: string) => void;
  onOpenForumForActivity?: (activityId: string, classId: string) => void;
}

export const ActivitiesView: React.FC<ActivitiesViewProps> = ({
  data,
  currentUser,
  periodsConfig,
  initialClassId = '',
  onAddActivity,
  onEditActivity,
  onDeleteActivity,
  onUpdateStatus,
  onSaveActivityGrades,
  onSubmitHomework,
  onGoToGrades,
  onOpenForumForActivity
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'Pendiente' | 'Entregada' | 'Calificada'>('all');
  const [classFilter, setClassFilter] = useState(initialClassId);
  const [gradingActivity, setGradingActivity] = useState<Activity | null>(null);
  const [submittingActivity, setSubmittingActivity] = useState<Activity | null>(null);

  const effectivePeriodsConfig = periodsConfig || data.periodsConfig;
  const activePeriodObj = getActivePeriod(effectivePeriodsConfig);
  const [selectedParcial, setSelectedParcial] = useState<ParcialId | 'all'>(activePeriodObj.id);

  const periodsList = effectivePeriodsConfig?.periods || [
    { id: 1 as ParcialId, name: '1er Parcial', status: 'active' as const },
    { id: 2 as ParcialId, name: '2do Parcial', status: 'upcoming' as const },
    { id: 3 as ParcialId, name: '3er Parcial', status: 'upcoming' as const },
    { id: 4 as ParcialId, name: '4to Parcial', status: 'upcoming' as const }
  ];

  const isCurrentParcialClosed = selectedParcial !== 'all' && isPeriodClosed(effectivePeriodsConfig, selectedParcial);
  const isCurrentParcialActive = selectedParcial !== 'all' && periodsList.find(p => p.id === selectedParcial)?.status === 'active';

  const isStudent = currentUser?.role === 'student';
  const isTeacher = currentUser?.role === 'teacher';
  const isAdmin = currentUser?.role === 'admin';
  const canManage = isAdmin || isTeacher;

  // Role based class scoping
  const allowedClasses = useMemo(() => {
    return getAllowedClasses(data.classes, currentUser, data.students);
  }, [data.classes, currentUser, data.students]);

  const allowedClassIds = useMemo(() => {
    return new Set(allowedClasses.map(c => c.id));
  }, [allowedClasses]);

  const getClassName = (id: string) => {
    const c = data.classes.find(cl => cl.id === id);
    if (!c) return 'Sin clase';
    return `${c.name} ${c.grade ? `(${c.grade})` : ''}`;
  };

  // Find student profile if user is a student
  const studentProfile = useMemo(() => {
    if (!isStudent || !currentUser) return null;
    return data.students.find(
      s => s.userId === currentUser.id || s.name.toLowerCase() === currentUser.name.toLowerCase()
    );
  }, [isStudent, currentUser, data.students]);

  // Activities scoped to user's permissions
  const userActivities = useMemo(() => {
    return data.activities.filter(a => {
      if (isAdmin) return true;
      return allowedClassIds.has(a.classId);
    });
  }, [data.activities, isAdmin, allowedClassIds]);

  // Filtered activities by search, status, class, and academic period (parcial)
  const filteredActivities = useMemo(() => {
    return userActivities.filter(a => {
      const q = searchTerm.toLowerCase();
      const matchesSearch =
        a.title.toLowerCase().includes(q) || (a.description || '').toLowerCase().includes(q);
      const matchesStatus = statusFilter === 'all' || a.status === statusFilter;
      const matchesClass = !classFilter || a.classId === classFilter;
      const matchesParcial = selectedParcial === 'all' || (a.parcial || 1) === selectedParcial;
      return matchesSearch && matchesStatus && matchesClass && matchesParcial;
    });
  }, [userActivities, searchTerm, statusFilter, classFilter, selectedParcial]);

  // Selected class object
  const activeClassObj = data.classes.find(c => c.id === classFilter);

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'PDF':
        return <FileText className="h-3.5 w-3.5 text-[#c6292e]" />;
      case 'XLSX':
        return <FileSpreadsheet className="h-3.5 w-3.5 text-[#2f8b3c]" />;
      case 'DOCX':
        return <FileText className="h-3.5 w-3.5 text-[#1a5fb4]" />;
      case 'Imagen':
        return <Image className="h-3.5 w-3.5 text-[#e66100]" />;
      case 'Video':
        return <Video className="h-3.5 w-3.5 text-[#9141ac]" />;
      default:
        return <File className="h-3.5 w-3.5 text-[#5d685f]" />;
    }
  };

  // Students for the activity currently selected for grading
  const gradingClass = gradingActivity ? data.classes.find(c => c.id === gradingActivity.classId) || null : null;
  const gradingStudents = useMemo(() => {
    if (!gradingClass) return [];
    return data.students
      .filter(s => s.status !== 'Inactivo' && isStudentInClass(s, gradingClass))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [gradingClass, data.students]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col justify-between gap-4 rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs sm:flex-row sm:items-center">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#c6292e]">
              {isTeacher ? 'Evaluación y Calificación Docente' : 'Evaluaciones y Tareas'}
            </span>
            <span className="rounded-full bg-[#eaf6ec] px-2.5 py-0.5 text-[10px] font-bold text-[#236a2d]">
              Organizado por Clases
            </span>
          </div>
          <h2 className="mt-1 text-2xl font-black text-[#26302b] sm:text-3xl">
            {isTeacher ? 'Calificación de actividades escolares' : 'Actividades escolares'}
          </h2>
          <p className="mt-1 text-xs text-[#6d766f]">
            {isStudent
              ? 'Consulta tus tareas asignadas, fechas de entrega y el puntaje obtenido en cada una.'
              : isTeacher
              ? 'Selecciona tu clase, crea actividades y califica a los alumnos según el puntaje obtenido.'
              : 'Supervisa y administra las tareas, proyectos y calificaciones de todas las clases del centro.'}
          </p>
        </div>

        {canManage && (
          isCurrentParcialClosed ? (
            <button
              disabled
              className="flex items-center justify-center gap-1.5 rounded-xl bg-[#dfe6df] px-4 py-2.5 text-xs font-bold text-[#6d766f] cursor-not-allowed shadow-none"
              title="Este parcial está cerrado por Coordinación. No se pueden agregar nuevas actividades."
            >
              <Lock className="h-4 w-4" />
              <span>Parcial cerrado</span>
            </button>
          ) : (
            <button
              onClick={onAddActivity}
              className="flex items-center justify-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2.5 text-xs font-bold text-white shadow-sm transition hover:bg-[#9f1d24]"
            >
              <Plus className="h-4 w-4" />
              <span>Nueva actividad</span>
            </button>
          )
        )}
      </div>

      {/* Parcial Navigation Bar */}
      <div className="rounded-3xl border border-[#dfe6df] bg-white p-4 shadow-xs">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider text-[#26302b]">
              Periodo Académico:
            </span>
            {selectedParcial !== 'all' ? (
              isCurrentParcialClosed ? (
                <span className="flex items-center gap-1 rounded-full bg-[#fde7e7] px-2.5 py-0.5 text-xs font-bold text-[#c6292e]">
                  <Lock className="h-3 w-3" />
                  Cerrado por Coordinación (Modo solo lectura)
                </span>
              ) : isCurrentParcialActive ? (
                <span className="flex items-center gap-1 rounded-full bg-[#eaf6ec] px-2.5 py-0.5 text-xs font-bold text-[#236a2d]">
                  <span className="h-2 w-2 rounded-full bg-[#2f8b3c] animate-pulse"></span>
                  En Curso (Edición habilitada)
                </span>
              ) : (
                <span className="rounded-full bg-[#f7f8f6] px-2.5 py-0.5 text-xs font-bold text-[#6d766f]">
                  Próximo
                </span>
              )
            ) : (
              <span className="rounded-full bg-[#eef2ee] px-2.5 py-0.5 text-xs font-bold text-[#465249]">
                Mostrando actividades de todo el año escolar
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {periodsList.map(period => {
              const isSelected = selectedParcial === period.id;
              const isClosed = period.status === 'closed';
              const isActive = period.status === 'active';

              return (
                <button
                  key={period.id}
                  onClick={() => setSelectedParcial(period.id)}
                  className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-extrabold transition ${
                    isSelected
                      ? isActive
                        ? 'bg-[#2f8b3c] text-white shadow-xs'
                        : isClosed
                        ? 'bg-[#26302b] text-white shadow-xs'
                        : 'bg-[#546057] text-white shadow-xs'
                      : 'border border-[#dfe6df] bg-[#f7f8f6] text-[#546057] hover:bg-[#eef2ee]'
                  }`}
                >
                  {isClosed && <Lock className="h-3 w-3" />}
                  <span>{period.name}</span>
                  {isActive && (
                    <span className="ml-1 h-1.5 w-1.5 rounded-full bg-white animate-pulse" />
                  )}
                </button>
              );
            })}

            <button
              onClick={() => setSelectedParcial('all')}
              className={`rounded-xl px-3 py-1.5 text-xs font-extrabold transition ${
                selectedParcial === 'all'
                  ? 'bg-[#26302b] text-white shadow-xs'
                  : 'border border-[#dfe6df] bg-[#f7f8f6] text-[#546057] hover:bg-[#eef2ee]'
              }`}
            >
              Todos los parciales
            </button>
          </div>
        </div>
      </div>

      {isStudent && (
        <div className="flex items-center gap-2.5 rounded-2xl border border-[#2f8b3c]/20 bg-[#eaf6ec] p-4 text-xs font-bold text-[#236a2d]">
          <Eye className="h-4 w-4 shrink-0" />
          <span>
            Vista de alumno: Aquí puedes consultar las calificaciones y comentarios otorgados por tus docentes en cada actividad de tus materias.
          </span>
        </div>
      )}

      {/* Class Navigation Tabs (For Teachers and Admins) */}
      {canManage && allowedClasses.length > 0 && (
        <div className="rounded-3xl border border-[#dfe6df] bg-white p-4 shadow-xs">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#dfe6df] pb-3 mb-3">
            <div className="flex items-center gap-2">
              <LayoutGrid className="h-4 w-4 text-[#2f8b3c]" />
              <span className="text-xs font-extrabold uppercase tracking-wider text-[#26302b]">
                {isTeacher ? 'Tus Clases Asignadas' : 'Filtrar por Clase'}
              </span>
            </div>
            {classFilter && (
              <button
                type="button"
                onClick={() => setClassFilter('')}
                className="text-[11px] font-bold text-[#2f8b3c] hover:underline"
              >
                Ver todas las clases ({userActivities.length})
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setClassFilter('')}
              className={`flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold transition ${
                !classFilter
                  ? 'bg-[#26302b] text-white shadow-xs'
                  : 'border border-[#dfe6df] bg-[#f7f8f6] text-[#536057] hover:bg-[#eef2ee]'
              }`}
            >
              <span>Todas las clases</span>
              <span className={`rounded-full px-1.5 py-0.2 text-[10px] font-black ${
                !classFilter ? 'bg-white/20 text-white' : 'bg-[#e5e9e5] text-[#26302b]'
              }`}>
                {userActivities.length}
              </span>
            </button>

            {allowedClasses.map(c => {
              const count = userActivities.filter(a => a.classId === c.id).length;
              const isSelected = classFilter === c.id;
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setClassFilter(c.id)}
                  className={`flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold transition ${
                    isSelected
                      ? 'bg-[#2f8b3c] text-white shadow-xs ring-2 ring-[#2f8b3c]/20'
                      : 'border border-[#dfe6df] bg-[#f7f8f6] text-[#26302b] hover:bg-[#eef2ee]'
                  }`}
                >
                  <span>{c.name}</span>
                  {c.grade && (
                    <span className="text-[10px] opacity-80 font-medium">({c.grade})</span>
                  )}
                  <span className={`rounded-full px-1.5 py-0.2 text-[10px] font-black ${
                    isSelected ? 'bg-white/20 text-white' : 'bg-[#e5e9e5] text-[#26302b]'
                  }`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Filter Tabs & Search Bar */}
      <div className="space-y-3 rounded-2xl border border-[#dfe6df] bg-white p-3 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#dfe6df] pb-3">
          <div className="flex flex-wrap items-center gap-1.5">
            {(['all', 'Pendiente', 'Entregada', 'Calificada'] as const).map(tab => {
              const count =
                tab === 'all'
                  ? userActivities.filter(a => !classFilter || a.classId === classFilter).length
                  : userActivities.filter(a => (!classFilter || a.classId === classFilter) && a.status === tab).length;
              const label =
                tab === 'all' ? 'Todas' : tab === 'Pendiente' ? 'Pendientes' : tab === 'Entregada' ? 'Entregadas' : 'Calificadas';

              return (
                <button
                  key={tab}
                  onClick={() => setStatusFilter(tab)}
                  className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
                    statusFilter === tab
                      ? 'bg-[#2f8b3c] text-white shadow-xs'
                      : 'bg-[#eef2ee] text-[#5d685f] hover:bg-[#dfe6df] hover:text-[#26302b]'
                  }`}
                >
                  {label} ({count})
                </button>
              );
            })}
          </div>

          {activeClassObj && (
            <div className="flex items-center gap-1.5 text-xs text-[#236a2d] font-bold bg-[#eaf6ec] px-3 py-1 rounded-xl">
              <span>Clase activa: {activeClassObj.name}</span>
            </div>
          )}
        </div>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-3 h-4 w-4 text-[#6d766f]" />
            <input
              type="text"
              placeholder="Buscar actividad por título o descripción..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] py-2 pl-9 pr-4 text-xs outline-none transition focus:border-[#2f8b3c] focus:bg-white"
            />
          </div>

          <div className="flex items-center gap-2">
            <select
              value={classFilter}
              onChange={e => setClassFilter(e.target.value)}
              className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-2 text-xs font-bold text-[#435047] outline-none focus:border-[#2f8b3c]"
            >
              <option value="">Todas las clases</option>
              {allowedClasses.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name} {c.grade ? `(${c.grade})` : ''}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Activity Cards List */}
      {filteredActivities.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-[#cad4cb] bg-white p-12 text-center shadow-xs">
          <CheckSquare className="mx-auto h-12 w-12 text-[#cad4cb] mb-3" />
          <h3 className="text-sm font-extrabold text-[#26302b]">No hay actividades que coincidan</h3>
          <p className="mt-1 text-xs text-[#6d766f]">
            {searchTerm || statusFilter !== 'all' || classFilter
              ? 'Prueba cambiando los filtros de búsqueda o clase seleccionada.'
              : isTeacher
              ? 'Aún no has creado actividades para tus clases. Haz clic en "Nueva actividad" para comenzar.'
              : 'Las actividades asignadas aparecerán aquí.'}
          </p>
          {canManage && (
            <button
              onClick={onAddActivity}
              className="mt-4 inline-flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-[#9f1d24]"
            >
              <Plus className="h-4 w-4" />
              <span>Crear actividad</span>
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredActivities.map(act => {
            const classObj = data.classes.find(c => c.id === act.classId);
            const classStudents = data.students.filter(
              s => s.status !== 'Inactivo' && (classObj ? isStudentInClass(s, classObj) : s.classId === act.classId)
            );
            const totalClassStudents = classStudents.length;

            const itemParcialId = (act.parcial || 1) as ParcialId;
            const isActivityClosed = isPeriodClosed(effectivePeriodsConfig, itemParcialId);
            const actPeriodObj = periodsList.find(p => p.id === itemParcialId);

            // Student grading metrics
            const recordedScores = act.scores || {};
            const scoredStudents = classStudents.filter(s => recordedScores[s.id] !== undefined && recordedScores[s.id] !== null);
            const gradedCount = scoredStudents.length;
            const progressPercent = totalClassStudents > 0 ? Math.round((gradedCount / totalClassStudents) * 100) : 0;

            const scoresList = scoredStudents.map(s => Number(recordedScores[s.id]));
            const avgScore = scoresList.length > 0
              ? (scoresList.reduce((a, b) => a + b, 0) / scoresList.length).toFixed(1)
              : null;

            // Student specific score if role is student
            const studentPersonalScore = studentProfile ? recordedScores[studentProfile.id] : undefined;
            const hasPersonalScore = studentPersonalScore !== undefined && studentPersonalScore !== null;
            const personalPercent = hasPersonalScore && act.value > 0 ? Math.round((studentPersonalScore / act.value) * 100) : 0;
            const personalGradeInfo = studentProfile ? act.studentGrades?.[studentProfile.id] : undefined;

            const linkedTopic = (data.forumTopics || []).find(t => t.activityId === act.id);
            const forumCommentCount = linkedTopic
              ? (data.forumComments || []).filter(c => c.topicId === linkedTopic.id).length
              : 0;

            return (
              <div
                key={act.id}
                className="flex flex-col justify-between gap-4 rounded-3xl border border-[#dfe6df] bg-white p-5 shadow-xs transition hover:shadow-md"
              >
                <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                  <div className="space-y-1.5 min-w-0 flex-1">
                    {/* Tags row */}
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="rounded-lg bg-[#f0f4f0] border border-[#dfe6df] px-2.5 py-0.5 text-xs font-black text-[#26302b]">
                        {getClassName(act.classId)}
                      </span>
                      <span className="rounded-lg bg-[#f7f8f6] border border-[#dfe6df] px-2.5 py-0.5 text-xs font-bold text-[#546057]">
                        {actPeriodObj?.name || `${itemParcialId}º Parcial`}
                      </span>
                      {isActivityClosed && (
                        <span className="flex items-center gap-1 rounded-lg bg-[#fde7e7] border border-[#c6292e]/20 px-2 py-0.5 text-xs font-bold text-[#c6292e]">
                          <Lock className="h-3 w-3" />
                          Cerrado
                        </span>
                      )}
                      <span className="rounded-lg bg-[#fff7cc] border border-[#f5c400]/30 px-2 py-0.5 text-xs font-black text-[#735f00]">
                        Valor: {act.value} pts
                      </span>
                      <span className="flex items-center gap-1 text-xs text-[#6d766f]">
                        <Clock className="h-3.5 w-3.5 text-[#98a39b]" />
                        Vence: {formatDate(act.deadline)}
                      </span>
                    </div>

                    <h3 className="text-base font-black text-[#26302b]">{act.title}</h3>
                    {act.description && (
                      <p className="text-xs text-[#546057] line-clamp-2 leading-relaxed">
                        {act.description}
                      </p>
                    )}

                    {/* TEACHER ATTACHED MATERIALS & FILES */}
                    {act.attachments && act.attachments.length > 0 && (
                      <div className="mt-3 rounded-2xl border border-[#dfe6df] bg-[#fbfdfb] p-3 text-xs">
                        <div className="flex items-center gap-1.5 font-black text-[#26302b] mb-2">
                          <Paperclip className="h-3.5 w-3.5 text-[#2f8b3c]" />
                          <span>Materiales y archivos de la actividad ({act.attachments.length}):</span>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {act.attachments.map(att => (
                            <button
                              key={att.id}
                              type="button"
                              onClick={() => downloadAttachedFile(att, act.title)}
                              className="group inline-flex items-center gap-2 rounded-xl bg-white px-3 py-1.5 font-bold text-[#26302b] border border-[#dfe6df] hover:border-[#2f8b3c] hover:text-[#236a2d] hover:bg-[#eaf6ec] transition shadow-2xs"
                              title={`Descargar ${att.name}`}
                            >
                              {getFileIcon(att.type)}
                              <span className="max-w-[200px] truncate text-xs">{att.name}</span>
                              <span className="text-[10px] text-[#6d766f]">({formatFileSize(att.size)})</span>
                              {att.storageUrl && (
                                <span className="inline-flex items-center gap-0.5 rounded bg-[#eaf6ec] px-1 py-0.2 text-[9px] font-bold text-[#236a2d]" title="Alojado en Firebase Cloud Storage">
                                  <Cloud className="h-2.5 w-2.5" />
                                </span>
                              )}
                              <Download className="h-3.5 w-3.5 text-[#6d766f] group-hover:text-[#236a2d]" />
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* TEACHER METRIC BAR: Score progress for the class */}
                    {!isStudent && totalClassStudents > 0 && (
                      <div className="mt-3 flex flex-wrap items-center gap-4 rounded-2xl bg-[#f7f8f6] p-2.5 border border-[#dfe6df]">
                        <div className="flex items-center gap-2">
                          <Users className="h-3.5 w-3.5 text-[#2f8b3c]" />
                          <span className="text-xs font-semibold text-[#536057]">
                            Calificados: <strong className="text-[#26302b]">{gradedCount} de {totalClassStudents}</strong> alumnos
                          </span>
                        </div>

                        {/* Progress meter */}
                        <div className="flex items-center gap-2 flex-1 max-w-xs">
                          <div className="h-2 w-full overflow-hidden rounded-full bg-[#edf1ed]">
                            <div
                              className="h-full rounded-full transition-all duration-300"
                              style={{
                                width: `${progressPercent}%`,
                                backgroundColor: progressPercent === 100 ? '#2f8b3c' : '#f5c400'
                              }}
                            />
                          </div>
                          <span className="text-[11px] font-bold text-[#6d766f]">{progressPercent}%</span>
                        </div>

                        {avgScore !== null && (
                          <div className="flex items-center gap-1 text-xs">
                            <span className="text-[#6d766f]">Promedio:</span>
                            <span className="font-black text-[#236a2d]">
                              {avgScore} / {act.value} pts
                            </span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* STUDENT VIEW: Personal score card */}
                    {isStudent && (
                      <div className="mt-2.5 rounded-2xl border border-[#dfe6df] bg-[#fbfdfb] p-3">
                        {hasPersonalScore ? (
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <Award className="h-4 w-4 text-[#2f8b3c]" />
                                <span className="text-xs font-bold text-[#26302b]">Tu puntaje obtenido:</span>
                                <span className="rounded-xl bg-[#eaf6ec] px-2.5 py-0.5 text-xs font-black text-[#236a2d] border border-[#2f8b3c]/20">
                                  {studentPersonalScore} / {act.value} pts ({personalPercent}%)
                                </span>
                              </div>
                              <span
                                className={`rounded-lg px-2 py-0.5 text-[11px] font-extrabold ${
                                  personalPercent >= 70
                                    ? 'bg-[#eaf6ec] text-[#236a2d]'
                                    : personalPercent >= 60
                                    ? 'bg-[#fff7cc] text-[#735f00]'
                                    : 'bg-[#fde7e7] text-[#c6292e]'
                                }`}
                              >
                                {personalPercent >= 70 ? 'Aprobado' : personalPercent >= 60 ? 'En riesgo' : 'Reprobado'}
                              </span>
                            </div>
                            {personalGradeInfo?.feedback && (
                              <div className="mt-1 flex items-start gap-1.5 text-xs text-[#546057] bg-white p-2 rounded-xl border border-[#dfe6df]">
                                <MessageSquare className="h-3.5 w-3.5 text-[#2f8b3c] shrink-0 mt-0.5" />
                                <span>Observación del maestro: <em>"{personalGradeInfo.feedback}"</em></span>
                              </div>
                            )}
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 text-xs text-[#6d766f]">
                            <Clock className="h-3.5 w-3.5 text-[#98a39b]" />
                            <span>Aún no tienes calificación registrada para esta actividad.</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* STUDENT HOMEWORK SUBMISSION SECTION */}
                    {isStudent && (
                      <div className="mt-3 rounded-2xl border border-[#bfe2c4]/70 bg-[#f7fbf8] p-3">
                        <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center sm:justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-black text-[#26302b]">
                                Tu entrega de tarea:
                              </span>
                              <span
                                className={`rounded-lg px-2 py-0.5 text-[10px] font-black ${
                                  personalGradeInfo?.status === 'Calificado'
                                    ? 'bg-[#eaf6ec] text-[#236a2d] border border-[#bfe2c4]'
                                    : personalGradeInfo?.status === 'Entregado'
                                    ? 'bg-[#fff7cc] text-[#735f00] border border-[#f5c400]/40'
                                    : 'bg-[#f0f4f0] text-[#536057] border border-[#dfe6df]'
                                }`}
                              >
                                {personalGradeInfo?.status || 'Pendiente'}
                              </span>
                              {personalGradeInfo?.submittedAt && (
                                <span className="text-[10px] text-[#6d766f]">
                                  Entregado: {formatDate(personalGradeInfo.submittedAt)}
                                </span>
                              )}
                            </div>

                            {personalGradeInfo?.attachments && personalGradeInfo.attachments.length > 0 ? (
                              <div className="mt-2 flex flex-wrap items-center gap-2">
                                <span className="text-[11px] font-bold text-[#536057]">Archivos adjuntados:</span>
                                {personalGradeInfo.attachments.map(att => (
                                  <button
                                    key={att.id}
                                    type="button"
                                    onClick={() => downloadAttachedFile(att, `Mi_Entrega_${act.title}`)}
                                    className="inline-flex items-center gap-1.5 rounded-lg bg-white px-2.5 py-1 text-xs font-bold text-[#26302b] border border-[#dfe6df] hover:border-[#2f8b3c] hover:text-[#236a2d] transition shadow-2xs"
                                    title={`Descargar ${att.name}`}
                                  >
                                    {getFileIcon(att.type)}
                                    <span className="max-w-[150px] truncate">{att.name}</span>
                                    <span className="text-[10px] text-[#6d766f]">({formatFileSize(att.size)})</span>
                                    {att.storageUrl && (
                                      <span className="inline-flex items-center gap-0.5 rounded bg-[#eaf6ec] px-1 py-0.2 text-[9px] font-bold text-[#236a2d]" title="Alojado en Firebase Cloud Storage">
                                        <Cloud className="h-2.5 w-2.5" />
                                      </span>
                                    )}
                                    <Download className="h-3 w-3 text-[#2f8b3c]" />
                                  </button>
                                ))}
                              </div>
                            ) : (
                              <p className="mt-1 text-[11px] text-[#6d766f]">
                                Aún no has adjuntado archivos para esta tarea escolar.
                              </p>
                            )}

                            {personalGradeInfo?.studentComment && (
                              <p className="mt-1.5 text-[11px] text-[#536057] italic bg-white/70 px-2 py-1 rounded-lg border border-[#dfe6df]/50">
                                Comentario enviado: "{personalGradeInfo.studentComment}"
                              </p>
                            )}
                          </div>

                          {studentProfile && (
                            isActivityClosed ? (
                              <span
                                className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#edf1ed] px-3.5 py-2 text-xs font-bold text-[#6d766f] border border-[#dfe6df] shrink-0"
                                title="Este parcial está cerrado por Coordinación. No se permiten nuevas entregas."
                              >
                                <Lock className="h-3.5 w-3.5" />
                                <span>Entregas cerradas</span>
                              </span>
                            ) : (
                              <button
                                type="button"
                                onClick={() => setSubmittingActivity(act)}
                                className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#2f8b3c] px-3.5 py-2 text-xs font-black text-white shadow-xs hover:bg-[#236a2d] transition shrink-0"
                              >
                                <Upload className="h-3.5 w-3.5" />
                                <span>
                                  {personalGradeInfo?.attachments && personalGradeInfo.attachments.length > 0
                                    ? 'Modificar mi entrega'
                                    : 'Entregar tarea / Subir archivo'}
                                </span>
                              </button>
                            )
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Actions & Status row */}
                  <div className="flex flex-wrap items-center gap-2 shrink-0 pt-2 lg:pt-0">
                    {/* For teachers/admins: Primary CALIFICAR ALUMNOS button */}
                    {!isStudent && (
                      <button
                        type="button"
                        onClick={() => setGradingActivity(act)}
                        className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-black shadow-xs transition ${
                          isActivityClosed
                            ? 'bg-[#546057] text-white hover:bg-[#3d463f]'
                            : gradedCount > 0
                            ? 'bg-[#2f8b3c] text-white hover:bg-[#236a2d]'
                            : 'bg-[#26302b] text-white hover:bg-black'
                        }`}
                        title={
                          isActivityClosed
                            ? 'Ver calificaciones y entregas de los alumnos (Modo solo lectura)'
                            : 'Calificar a cada alumno según el puntaje obtenido en esta clase'
                        }
                      >
                        {isActivityClosed ? <Lock className="h-4 w-4" /> : <Award className="h-4 w-4" />}
                        <span>
                          {isActivityClosed
                            ? `Ver Calificaciones (${gradedCount}/${totalClassStudents})`
                            : gradedCount > 0
                            ? `Calificar Alumnos (${gradedCount}/${totalClassStudents})`
                            : 'Calificar Alumnos'}
                        </span>
                      </button>
                    )}

                    {/* Forum discussion button */}
                    <button
                      type="button"
                      onClick={() => onOpenForumForActivity?.(act.id, act.classId)}
                      className={`flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold transition shadow-2xs ${
                        linkedTopic
                          ? 'border-[#236a2d] bg-[#f4f7f4] text-[#236a2d] hover:bg-[#eef5ee]'
                          : 'border-[#dfe6df] bg-white text-[#526456] hover:border-[#236a2d] hover:text-[#236a2d]'
                      }`}
                      title={
                        linkedTopic
                          ? `Ver debate en el foro (${forumCommentCount} opiniones)`
                          : isStudent
                          ? 'Ver foro de debate'
                          : 'Abrir debate en el foro para esta tarea'
                      }
                    >
                      <MessagesSquare className="h-4 w-4" />
                      <span className="hidden sm:inline">
                        {linkedTopic ? 'Debate en Foro' : 'Foro'}
                      </span>
                      {forumCommentCount > 0 && (
                        <span className="rounded-full bg-[#236a2d] text-white px-1.5 py-0.2 text-[10px] font-bold">
                          {forumCommentCount}
                        </span>
                      )}
                    </button>

                    {/* Status Badge / Toggle */}
                    {isStudent ? (
                      <span
                        className={`rounded-xl px-3 py-1.5 text-xs font-black ${
                          act.status === 'Calificada'
                            ? 'bg-[#eaf6ec] text-[#236a2d] border border-[#2f8b3c]/20'
                            : act.status === 'Entregada'
                            ? 'bg-[#fff7cc] text-[#735f00] border border-[#f5c400]/30'
                            : 'bg-[#f7f8f6] text-[#26302b] border border-[#dfe6df]'
                        }`}
                      >
                        Estado: {act.status}
                      </span>
                    ) : isActivityClosed ? (
                      <span
                        className="flex items-center gap-1 rounded-xl bg-[#edf1ed] px-3 py-1.5 text-xs font-black text-[#546057] border border-[#dfe6df]"
                        title="Parcial cerrado por Coordinación. Estado protegido."
                      >
                        <Lock className="h-3.5 w-3.5 text-[#6d766f]" />
                        Estado: {act.status}
                      </span>
                    ) : (
                      <div className="flex rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-1">
                        {(['Pendiente', 'Entregada', 'Calificada'] as const).map(st => (
                          <button
                            key={st}
                            onClick={() => onUpdateStatus(act.id, st)}
                            className={`rounded-lg px-2.5 py-1 text-[10px] font-extrabold transition ${
                              act.status === st
                                ? st === 'Calificada'
                                  ? 'bg-[#2f8b3c] text-white'
                                  : st === 'Entregada'
                                  ? 'bg-[#f5c400] text-black'
                                  : 'bg-[#26302b] text-white'
                                : 'text-[#6d766f] hover:text-[#26302b]'
                            }`}
                          >
                            {st}
                          </button>
                        ))}
                      </div>
                    )}

                    {canManage && (
                      isActivityClosed ? (
                        <span
                          className="flex items-center gap-1 rounded-xl bg-[#edf1ed] px-2.5 py-1.5 text-[11px] font-bold text-[#6d766f] border border-[#dfe6df]"
                          title="Parcial cerrado por Coordinación. No se puede modificar ni eliminar."
                        >
                          <Lock className="h-3.5 w-3.5" />
                          <span>Protegido</span>
                        </span>
                      ) : (
                        <>
                          <button
                            onClick={() => onEditActivity(act)}
                            className="rounded-xl border border-[#dfe6df] p-2 text-[#5d685f] hover:bg-[#eef2ee]"
                            title="Editar información de la actividad"
                          >
                            <Edit className="h-4 w-4" />
                          </button>

                          <button
                            onClick={() => onDeleteActivity(act.id)}
                            className="rounded-xl border border-[#fde7e7] bg-[#fde7e7]/40 p-2 text-[#c6292e] hover:bg-[#fde7e7]"
                            title="Eliminar actividad"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </>
                      )
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Grade Activity Modal */}
      {gradingActivity && (
        <GradeActivityModal
          isOpen={Boolean(gradingActivity)}
          activity={gradingActivity}
          classRoom={gradingClass}
          students={gradingStudents}
          isReadOnly={isPeriodClosed(effectivePeriodsConfig, (gradingActivity.parcial || 1) as ParcialId)}
          onClose={() => setGradingActivity(null)}
          onSaveGrades={(actId, newScores, newGrades) => {
            onSaveActivityGrades(actId, newScores, newGrades);
            setGradingActivity(null);
          }}
        />
      )}

      {/* Student Submit Homework Modal */}
      {submittingActivity && studentProfile && (
        <SubmitHomeworkModal
          isOpen={Boolean(submittingActivity)}
          activity={submittingActivity}
          student={studentProfile}
          currentGrade={submittingActivity.studentGrades?.[studentProfile.id]}
          onClose={() => setSubmittingActivity(null)}
          onSubmitHomework={(actId, studId, submission) => {
            if (onSubmitHomework) {
              onSubmitHomework(actId, studId, submission);
            }
            setSubmittingActivity(null);
          }}
        />
      )}
    </div>
  );
};
