import React, { useState, useMemo } from 'react';
import { FileSpreadsheet, Printer, Users, CheckCircle2, FileDown, BookOpen, GraduationCap, ShieldCheck, Lock } from 'lucide-react';
import { AppData, Student, User, PeriodsConfig, ParcialId } from '../../types';
import {
  calculateStudentAverage,
  calculateStudentAttendancePercentage,
  formatDate,
  isStudentInClass,
  getActivePeriod,
  isPeriodClosed
} from '../../utils/storage';
import { HOGAR_LOGO } from '../../constants/initialData';
import { getAllowedStudents, getAllowedClasses } from '../../utils/rbac';

interface ReportsViewProps {
  data: AppData;
  currentUser?: User | null;
  periodsConfig?: PeriodsConfig;
  initialStudentId?: string;
  onPrintStudentReport: (student: Student, parcial?: ParcialId | 'all') => void;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  data,
  currentUser,
  periodsConfig,
  initialStudentId = '',
  onPrintStudentReport
}) => {
  const isStudent = currentUser?.role === 'student';
  const effectivePeriodsConfig = periodsConfig || data.periodsConfig;
  const activePeriodObj = getActivePeriod(effectivePeriodsConfig);
  const [selectedParcial, setSelectedParcial] = useState<ParcialId | 'all'>(activePeriodObj.id);

  const periodsList = effectivePeriodsConfig?.periods || [
    { id: 1 as ParcialId, name: '1er Parcial', status: 'active' as const },
    { id: 2 as ParcialId, name: '2do Parcial', status: 'upcoming' as const },
    { id: 3 as ParcialId, name: '3er Parcial', status: 'upcoming' as const },
    { id: 4 as ParcialId, name: '4to Parcial', status: 'upcoming' as const }
  ];

  const currentPeriodName = selectedParcial === 'all'
    ? 'Reporte Consolidado Anual'
    : periodsList.find(p => p.id === selectedParcial)?.name || `${selectedParcial}º Parcial`;

  const isCurrentParcialClosed = selectedParcial !== 'all' && isPeriodClosed(effectivePeriodsConfig, selectedParcial);
  const isCurrentParcialActive = selectedParcial !== 'all' && periodsList.find(p => p.id === selectedParcial)?.status === 'active';

  const allowedStudents = useMemo(() => {
    return getAllowedStudents(data.students, data.classes, currentUser);
  }, [data.students, data.classes, currentUser]);

  const [selectedStudentId, setSelectedStudentId] = useState<string>(() => {
    if (initialStudentId && allowedStudents.some(s => s.id === initialStudentId)) {
      return initialStudentId;
    }
    return allowedStudents[0]?.id || '';
  });

  // Ensure selected student is allowed
  const currentStudent = allowedStudents.find(s => s.id === selectedStudentId) || allowedStudents[0];

  // Group allowed students by grade for admin/teachers to navigate easily
  const studentsByGrade = useMemo(() => {
    const map: Record<string, Student[]> = {};
    allowedStudents.forEach(s => {
      const g = s.grade || 'Sin Grado';
      if (!map[g]) map[g] = [];
      map[g].push(s);
    });
    return map;
  }, [allowedStudents]);

  const allowedClasses = useMemo(() => {
    return getAllowedClasses(data.classes, currentUser, data.students);
  }, [data.classes, currentUser, data.students]);

  // Find all classes relevant to this student (all classes belonging to the student's grade)
  // For teachers, strictly scope to classes assigned to them!
  const studentClasses = useMemo(() => {
    if (!currentStudent) return [];
    let classes = data.classes.filter(c => isStudentInClass(currentStudent, c));
    // If no match found by grade/enrolledClassIds, fallback to student's explicit classId
    if (classes.length === 0 && currentStudent.classId) {
      classes = data.classes.filter(c => c.id === currentStudent.classId);
    }
    // Strict scoping for teacher: only show their assigned classes/grades
    if (currentUser?.role === 'teacher') {
      const allowedClassIds = new Set(allowedClasses.map(c => c.id));
      classes = classes.filter(c => allowedClassIds.has(c.id));
    }
    return classes;
  }, [currentStudent, data.classes, currentUser, allowedClasses]);

  // Calculate totals per class filtered by selected academic period
  const classReports = useMemo(() => {
    if (!currentStudent) return [];

    return studentClasses.map(cls => {
      const teacher = data.users?.find(u => u.id === cls.teacherId);
      const gradesInClass = data.grades.filter(g => {
        if (g.classId !== cls.id) return false;
        if (selectedParcial === 'all') return true;
        return (g.parcial || 1) === selectedParcial;
      });
      const activitiesInClass = data.activities.filter(a => {
        if (a.classId !== cls.id) return false;
        if (selectedParcial === 'all') return true;
        return (a.parcial || 1) === selectedParcial;
      });
      const totalEvaluations = gradesInClass.length + activitiesInClass.length;

      // Calculate total points scored / max points across both
      let totalEarned = 0;
      let totalMax = 0;

      gradesInClass.forEach(g => {
        const score = Number(g.scores?.[currentStudent.id] ?? 0);
        totalEarned += score;
        totalMax += g.scale;
      });

      activitiesInClass.forEach(a => {
        const score = Number(a.scores?.[currentStudent.id] ?? a.studentGrades?.[currentStudent.id]?.score ?? 0);
        totalEarned += score;
        totalMax += (a.value || 100);
      });

      const avgClass = calculateStudentAverage(
        currentStudent.id,
        cls.id,
        data.grades,
        data.activities,
        selectedParcial === 'all' ? undefined : selectedParcial
      );
      const attClass = calculateStudentAttendancePercentage(currentStudent.id, cls.id, data.attendance);

      const status = avgClass >= 70 ? 'Aprobado' : avgClass >= 60 ? 'En riesgo' : 'Reprobado';

      return {
        classId: cls.id,
        className: cls.name,
        grade: cls.grade,
        teacherName: teacher ? teacher.name : 'Titular Asignado',
        totalEvaluations,
        evaluationsCount: gradesInClass.length,
        activitiesCount: activitiesInClass.length,
        gradesInClass,
        activitiesInClass,
        totalEarned,
        totalMax: totalMax || 100,
        finalGrade: avgClass,
        attendancePercent: attClass,
        status
      };
    });
  }, [currentStudent, studentClasses, data.grades, data.activities, data.attendance, data.users, selectedParcial]);

  // Overall calculations across all classes
  const overallAverage = useMemo(() => {
    if (classReports.length === 0) return 0;
    const sum = classReports.reduce((acc, c) => acc + c.finalGrade, 0);
    return Math.round(sum / classReports.length);
  }, [classReports]);

  const overallAttendance = useMemo(() => {
    if (!currentStudent) return 100;
    return calculateStudentAttendancePercentage(currentStudent.id, currentStudent.classId, data.attendance);
  }, [currentStudent, data.attendance]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col justify-between gap-4 rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs sm:flex-row sm:items-center">
        <div>
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#c6292e]">
            Boletín Informativo
          </span>
          <h2 className="mt-1 text-2xl font-black text-[#26302b] sm:text-3xl">Reportes académicos</h2>
          <p className="mt-1 text-xs text-[#6d766f]">
            {isStudent
              ? 'Consulta tu informe académico consolidado con los totales finales por clase.'
              : 'Genera boletas y reportes consolidados por clase listos para imprimir o guardar en PDF.'}
          </p>
        </div>

        {currentStudent && (
          <button
            onClick={() => onPrintStudentReport(currentStudent, selectedParcial)}
            className="flex items-center justify-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-[#9f1d24]"
          >
            <Printer className="h-4 w-4" />
            <span>Imprimir reporte / PDF</span>
          </button>
        )}
      </div>

      {/* Parcial Navigation Bar */}
      <div className="rounded-3xl border border-[#dfe6df] bg-white p-4 shadow-xs">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider text-[#26302b]">
              Periodo Académico:
            </span>
            {selectedParcial !== 'all' ? (
              isCurrentParcialClosed ? (
                <span className="flex items-center gap-1 rounded-full bg-[#fde7e7] px-2.5 py-0.5 text-xs font-bold text-[#c6292e]">
                  <Lock className="h-3 w-3" />
                  Parcial Cerrado por Coordinación
                </span>
              ) : isCurrentParcialActive ? (
                <span className="flex items-center gap-1 rounded-full bg-[#eaf6ec] px-2.5 py-0.5 text-xs font-bold text-[#236a2d]">
                  <span className="h-2 w-2 rounded-full bg-[#2f8b3c] animate-pulse"></span>
                  Parcial en Curso
                </span>
              ) : (
                <span className="rounded-full bg-[#f7f8f6] px-2.5 py-0.5 text-xs font-bold text-[#6d766f]">
                  Próximo
                </span>
              )
            ) : (
              <span className="rounded-full bg-[#eef2ee] px-2.5 py-0.5 text-xs font-bold text-[#465249]">
                Consolidado Anual Completo
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {periodsList.map(period => {
              const isSelected = selectedParcial === period.id;
              const isClosed = period.status === 'closed';
              const isActive = period.status === 'active';

              return (
                <button
                  key={period.id}
                  onClick={() => setSelectedParcial(period.id)}
                  className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-extrabold transition ${
                    isSelected
                      ? isActive
                        ? 'bg-[#2f8b3c] text-white shadow-xs'
                        : isClosed
                        ? 'bg-[#26302b] text-white shadow-xs'
                        : 'bg-[#546057] text-white shadow-xs'
                      : 'border border-[#dfe6df] bg-[#f7f8f6] text-[#546057] hover:bg-[#eef2ee]'
                  }`}
                >
                  {isClosed && <Lock className="h-3 w-3" />}
                  <span>{period.name}</span>
                  {isActive && (
                    <span className="ml-1 h-1.5 w-1.5 rounded-full bg-white animate-pulse" />
                  )}
                </button>
              );
            })}

            <button
              onClick={() => setSelectedParcial('all')}
              className={`rounded-xl px-3 py-1.5 text-xs font-extrabold transition ${
                selectedParcial === 'all'
                  ? 'bg-[#26302b] text-white shadow-xs'
                  : 'border border-[#dfe6df] bg-[#f7f8f6] text-[#546057] hover:bg-[#eef2ee]'
              }`}
            >
              Consolidado Anual
            </button>
          </div>
        </div>
      </div>

      {/* Selector Bar - Only for Teachers and Admins */}
      {!isStudent ? (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#dfe6df] bg-white p-4 shadow-xs">
          <div className="flex items-center gap-3">
            <label className="text-xs font-extrabold text-[#26302b]">Seleccionar alumno:</label>
            <select
              value={currentStudent?.id || ''}
              onChange={e => setSelectedStudentId(e.target.value)}
              className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3.5 py-2 text-xs font-bold text-[#26302b] outline-none focus:border-[#2f8b3c]"
            >
              {allowedStudents.length === 0 && <option value="">No hay alumnos disponibles</option>}
              {Object.entries(studentsByGrade).map(([gradeName, list]) => (
                <optgroup key={gradeName} label={`Grado: ${gradeName}`}>
                  {list.map(s => {
                    const cName = data.classes.find(c => c.id === s.classId)?.name || 'Sin clase';
                    return (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.code || 'ID'}) — {cName}
                      </option>
                    );
                  })}
                </optgroup>
              ))}
            </select>
          </div>

          <span className="text-xs text-[#6d766f]">
            Totales calculados por clase/materia en base a todas las actividades evaluadas.
          </span>
        </div>
      ) : (
        <div className="flex items-center gap-2 rounded-2xl border border-[#2f8b3c]/20 bg-[#eaf6ec] p-4 text-xs font-bold text-[#236a2d]">
          <GraduationCap className="h-4 w-4" />
          <span>Reporte personal exclusivo de: <strong>{currentStudent?.name}</strong></span>
        </div>
      )}

      {/* Report Card Paper Preview */}
      {!currentStudent ? (
        <div className="rounded-3xl border border-dashed border-[#cad4cb] bg-white p-12 text-center shadow-xs">
          <FileSpreadsheet className="mx-auto h-12 w-12 text-[#cad4cb] mb-3" />
          <h3 className="text-sm font-extrabold text-[#26302b]">No hay alumno seleccionado</h3>
          <p className="mt-1 text-xs text-[#6d766f]">Selecciona un alumno para visualizar su reporte.</p>
        </div>
      ) : (
        <div className="mx-auto max-w-3xl rounded-3xl border border-[#dfe6df] bg-white p-8 shadow-md">
          {/* Institutional Header */}
          <div className="flex items-center justify-between border-b-4 border-[#c6292e] pb-5">
            <div className="flex items-center gap-4">
              <img
                src={HOGAR_LOGO}
                alt="Docentes El Hogar"
                className="h-16 w-16 rounded-xl object-contain border border-[#dfe6df] p-1 shadow-xs"
              />
              <div>
                <strong className="block text-xl font-black text-[#26302b]">Docentes El Hogar.</strong>
                <span className="block text-xs font-semibold text-[#546057]">
                  Hogar de Amor y Esperanza · {currentPeriodName}
                </span>
                {isCurrentParcialClosed && (
                  <span className="mt-1 inline-flex items-center gap-1 rounded-md bg-[#fde7e7] px-2 py-0.5 text-[10px] font-bold text-[#c6292e]">
                    <Lock className="h-2.5 w-2.5" />
                    Periodo Cerrado por Coordinación
                  </span>
                )}
              </div>
            </div>

            <div className="text-right text-xs text-[#6d766f]">
              <div>Fecha de emisión:</div>
              <strong className="text-[#26302b]">{new Date().toLocaleDateString('es-ES')}</strong>
            </div>
          </div>

          {/* Student Info */}
          <div className="mt-6 flex flex-col justify-between gap-4 rounded-2xl bg-[#f7f8f6] p-4 border border-[#dfe6df] sm:flex-row sm:items-center">
            <div>
              <h3 className="text-lg font-black text-[#26302b]">{currentStudent.name}</h3>
              <p className="text-xs text-[#6d766f]">
                Grado: <strong className="text-[#26302b]">{currentStudent.grade || '—'}</strong> · Sección:{' '}
                <strong className="text-[#26302b]">{currentStudent.section || 'Única'}</strong>
                {currentStudent.guardianName && (
                  <span> · Encargado: <strong className="text-[#26302b]">{currentStudent.guardianName}</strong></span>
                )}
              </p>
            </div>
            <div className="text-xs text-[#546057]">
              <div>
                ID Estudiantil: <strong className="font-mono text-[#26302b]">{currentStudent.code || '—'}</strong>
              </div>
              <div>
                Estado Escolar: <strong className="text-[#2f8b3c]">{currentStudent.status}</strong>
              </div>
            </div>
          </div>

          {/* Key Metrics Summary */}
          <div className="mt-6 grid grid-cols-3 gap-3">
            <div className="rounded-2xl border border-[#dfe6df] p-4 text-center">
              <div className="text-xs font-bold text-[#6d766f]">Promedio General Total</div>
              <div className="mt-1 text-2xl font-black text-[#236a2d]">{overallAverage}%</div>
              <div className="text-[10px] text-[#6d766f]">
                {overallAverage >= 70 ? 'Satisfactorio' : 'Requiere Reforzamiento'}
              </div>
            </div>

            <div className="rounded-2xl border border-[#dfe6df] p-4 text-center">
              <div className="text-xs font-bold text-[#6d766f]">Asistencia General</div>
              <div className="mt-1 text-2xl font-black text-[#26302b]">{overallAttendance}%</div>
              <div className="text-[10px] text-[#2f8b3c] font-semibold">Registro Institucional</div>
            </div>

            <div className="rounded-2xl border border-[#dfe6df] p-4 text-center">
              <div className="text-xs font-bold text-[#6d766f]">Clases Cursadas</div>
              <div className="mt-1 text-2xl font-black text-[#26302b]">{classReports.length}</div>
              <div className="text-[10px] text-[#6d766f]">Materias Oficiales</div>
            </div>
          </div>

          {/* TOTALS PER CLASS TABLE (User explicitly requested: "totales por clase no por evaluación") */}
          <div className="mt-6">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-black uppercase tracking-wider text-[#26302b]">
                Resumen de Calificaciones Totales por Clase
              </h4>
              <span className="text-[11px] font-bold text-[#6d766f]">
                Consolidado Oficial por Materia
              </span>
            </div>

            {classReports.length === 0 ? (
              <p className="text-xs text-[#6d766f] italic">No hay clases asignadas para este estudiante.</p>
            ) : (
              <div className="overflow-hidden rounded-2xl border border-[#dfe6df]">
                <table className="w-full border-collapse text-left text-xs">
                  <thead>
                    <tr className="border-b border-[#dfe6df] bg-[#f7f8f6] text-[11px] font-bold uppercase tracking-wider text-[#6d766f]">
                      <th className="py-3 px-3.5">Clase / Asignatura</th>
                      <th className="py-3 px-3 text-center">Docente</th>
                      <th className="py-3 px-3 text-center">Actividades</th>
                      <th className="py-3 px-3 text-center">Asistencia</th>
                      <th className="py-3 px-3.5 text-center">Total Clase</th>
                      <th className="py-3 px-3.5 text-right">Resultado</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#dfe6df]">
                    {classReports.map(cr => (
                      <tr key={cr.classId} className="hover:bg-[#fbfcfb]">
                        <td className="py-3 px-3.5 font-black text-[#26302b]">
                          <div>{cr.className}</div>
                          {cr.grade && <span className="text-[10px] text-[#6d766f]">{cr.grade}</span>}
                        </td>
                        <td className="py-3 px-3 text-center text-[#546057]">{cr.teacherName}</td>
                        <td className="py-3 px-3 text-center">
                          <div className="font-bold text-[#26302b]">{cr.totalEvaluations} ítems</div>
                          <div className="text-[10px] text-[#6d766f]">{cr.activitiesCount} activ. + {cr.evaluationsCount} eval.</div>
                        </td>
                        <td className="py-3 px-3 text-center font-bold text-[#236a2d]">
                          {cr.attendancePercent}%
                        </td>
                        <td className="py-3 px-3.5 text-center">
                          <span className="text-sm font-black text-[#236a2d]">{cr.finalGrade}%</span>
                        </td>
                        <td className="py-3 px-3.5 text-right">
                          <span
                            className={`inline-block rounded-lg px-2.5 py-0.5 text-[10px] font-black ${
                              cr.status === 'Aprobado'
                                ? 'bg-[#eaf6ec] text-[#236a2d] border border-[#2f8b3c]/20'
                                : cr.status === 'En riesgo'
                                ? 'bg-[#fff7cc] text-[#735f00] border border-[#f5c400]/30'
                                : 'bg-[#fde7e7] text-[#c6292e] border border-[#c6292e]/20'
                            }`}
                          >
                            {cr.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="border-t-2 border-[#dfe6df] bg-[#f7f8f6] font-bold">
                      <td colSpan={4} className="py-3 px-3.5 text-right uppercase tracking-wider text-xs text-[#26302b]">
                        Promedio Final Ponderado:
                      </td>
                      <td className="py-3 px-3.5 text-center text-sm font-black text-[#236a2d]">
                        {overallAverage}%
                      </td>
                      <td className="py-3 px-3.5 text-right">
                        <span className="rounded-lg bg-[#2f8b3c] px-2.5 py-1 text-xs font-black text-white">
                          {overallAverage >= 70 ? 'APROBADO' : 'EN REFORZAMIENTO'}
                        </span>
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </div>

          {/* Detailed breakdown per class of activities & evaluations */}
          <div className="mt-6 space-y-4">
            <h4 className="text-xs font-black uppercase tracking-wider text-[#26302b]">
              Desglose de Actividades y Evaluaciones por Asignatura
            </h4>
            {classReports.map(cr => {
              const allItems = [
                ...(cr.gradesInClass || []).map(g => ({
                  id: g.id,
                  title: g.title,
                  type: g.type,
                  isActivity: false,
                  score: Number(g.scores?.[currentStudent.id] ?? 0),
                  max: g.scale,
                  isGraded: g.scores?.[currentStudent.id] !== undefined
                })),
                ...(cr.activitiesInClass || []).map(a => ({
                  id: a.id,
                  title: a.title,
                  type: 'Actividad / Tarea',
                  isActivity: true,
                  score: Number(a.scores?.[currentStudent.id] ?? a.studentGrades?.[currentStudent.id]?.score ?? 0),
                  max: a.value || 100,
                  isGraded: a.scores?.[currentStudent.id] !== undefined || a.studentGrades?.[currentStudent.id]?.score !== undefined
                }))
              ];

              if (allItems.length === 0) return null;

              return (
                <div key={cr.classId} className="rounded-2xl border border-[#dfe6df] bg-[#fcfdfc] p-4 text-xs">
                  <div className="flex items-center justify-between border-b border-[#dfe6df] pb-2 mb-2.5">
                    <strong className="text-xs font-bold text-[#26302b]">{cr.className} ({cr.grade || 'General'})</strong>
                    <span className="text-[11px] font-black text-[#236a2d]">Promedio: {cr.finalGrade}%</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {allItems.map(it => (
                      <div key={it.id} className="flex items-center justify-between rounded-xl bg-white p-2.5 border border-[#edf1ed]">
                        <div className="min-w-0 pr-2">
                          <div className="flex items-center gap-1.5">
                            <span className={`rounded px-1.5 py-0.5 text-[9px] font-extrabold ${it.isActivity ? 'bg-[#eaf6ec] text-[#236a2d]' : 'bg-[#eef2ee] text-[#465249]'}`}>
                              {it.isActivity ? 'Actividad' : 'Evaluación'}
                            </span>
                            <strong className="truncate block text-xs text-[#26302b]">{it.title}</strong>
                          </div>
                          <span className="text-[10px] text-[#6d766f]">{it.type}</span>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="font-black text-xs text-[#236a2d]">{it.score} / {it.max}</span>
                          <div className="text-[9px] text-[#6d766f]">
                            {it.max > 0 ? `${Math.round((it.score / it.max) * 100)}%` : ''}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Observations */}
          <div className="mt-6 rounded-2xl border border-[#dfe6df] bg-[#f7f8f6] p-4 text-xs">
            <strong className="block text-[#26302b] mb-1">Observaciones institucionales:</strong>
            <p className="text-[#546057] leading-relaxed">
              {currentStudent.notes ||
                'El estudiante ha mostrado un comportamiento participativo y continuo compromiso con sus tareas escolares en todas las asignaturas.'}
            </p>
          </div>

          {/* Signature lines */}
          <div className="mt-12 grid grid-cols-2 gap-10 pt-6 text-center text-xs text-[#6d766f]">
            <div className="border-t border-[#cad4cb] pt-2 font-bold">Firma del Docente / Tutor</div>
            <div className="border-t border-[#cad4cb] pt-2 font-bold">Firma y Sello de la Dirección</div>
          </div>
        </div>
      )}
    </div>
  );
};
