import React, { useState } from 'react';
import {
  Clock,
  Calendar as CalendarIcon,
  CheckCircle2,
  Users,
  Save,
  Check,
  Eye,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { AppData, AttendanceStatus, User } from '../../types';
import {
  getTodayDateString,
  formatDate,
  getInitials,
  calculateStudentAttendancePercentage,
  isStudentInClass
} from '../../utils/storage';
import { getAllowedClasses, getAllowedStudents } from '../../utils/rbac';

interface AttendanceViewProps {
  data: AppData;
  currentUser?: User | null;
  initialClassId?: string;
  onSetAttendance: (classId: string, date: string, studentId: string, status: AttendanceStatus) => void;
  onMarkAllPresent: (classId: string, date: string) => void;
  onSaveToast: () => void;
}

type PeriodMode = 'day' | 'week' | 'month' | 'year';

export const AttendanceView: React.FC<AttendanceViewProps> = ({
  data,
  currentUser,
  initialClassId = '',
  onSetAttendance,
  onMarkAllPresent,
  onSaveToast
}) => {
  const isStudent = currentUser?.role === 'student';
  const allowedClasses = getAllowedClasses(data.classes, currentUser, data.students);

  const [selectedClassId, setSelectedClassId] = useState<string>(
    initialClassId && allowedClasses.some(c => c.id === initialClassId)
      ? initialClassId
      : allowedClasses[0]?.id || ''
  );

  const activeClassId = allowedClasses.some(c => c.id === selectedClassId)
    ? selectedClassId
    : allowedClasses[0]?.id || '';

  const [periodMode, setPeriodMode] = useState<PeriodMode>('day');
  const [selectedDate, setSelectedDate] = useState<string>(getTodayDateString());

  // Week anchor date
  const [weekAnchorDate, setWeekAnchorDate] = useState<Date>(new Date());
  // Selected month & year
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(new Date().getMonth() + 1);

  const currentClass = allowedClasses.find(c => c.id === activeClassId);
  const allowedStudents = getAllowedStudents(data.students, data.classes, currentUser);
  const classStudents = allowedStudents.filter(
    s => s.status !== 'Inactivo' && (currentClass ? isStudentInClass(s, currentClass) : s.classId === activeClassId)
  );

  const attendanceKey = `${selectedDate}:${activeClassId}`;
  const dayRecords = data.attendance[attendanceKey] || {};

  const STATUS_CONFIG: Record<
    AttendanceStatus,
    { label: string; activeClass: string; inactiveClass: string; badgeClass: string }
  > = {
    P: {
      label: 'Presente',
      activeClass: 'bg-[#2f8b3c] text-white shadow-xs',
      inactiveClass: 'bg-[#eef2ee] text-[#5d685f] hover:bg-[#eaf6ec] hover:text-[#236a2d]',
      badgeClass: 'bg-[#eaf6ec] text-[#236a2d] border border-[#2f8b3c]/20'
    },
    A: {
      label: 'Ausente',
      activeClass: 'bg-[#c6292e] text-white shadow-xs',
      inactiveClass: 'bg-[#eef2ee] text-[#5d685f] hover:bg-[#fde7e7] hover:text-[#c6292e]',
      badgeClass: 'bg-[#fde7e7] text-[#c6292e] border border-[#c6292e]/20'
    },
    T: {
      label: 'Tarde',
      activeClass: 'bg-[#f5c400] text-black shadow-xs font-bold',
      inactiveClass: 'bg-[#eef2ee] text-[#5d685f] hover:bg-[#fff7cc] hover:text-[#735f00]',
      badgeClass: 'bg-[#fff7cc] text-[#735f00] border border-[#f5c400]/30'
    },
    J: {
      label: 'Justificado',
      activeClass: 'bg-[#236a2d] text-white shadow-xs',
      inactiveClass: 'bg-[#eef2ee] text-[#5d685f] hover:bg-[#eaf6ec] hover:text-[#236a2d]',
      badgeClass: 'bg-[#eef2ee] text-[#26302b] border border-[#dfe6df]'
    }
  };

  // Helper for Week view: calculate Monday to Friday of weekAnchorDate
  const getWeekDays = (anchor: Date) => {
    const d = new Date(anchor);
    const dayOfWeek = d.getDay(); // 0 is Sunday, 1 is Monday...
    const diffToMonday = (dayOfWeek + 6) % 7; // distance from Monday
    const monday = new Date(d);
    monday.setDate(d.getDate() - diffToMonday);

    const weekDays = [];
    for (let i = 0; i < 5; i++) {
      const day = new Date(monday);
      day.setDate(monday.getDate() + i);
      const y = day.getFullYear();
      const m = String(day.getMonth() + 1).padStart(2, '0');
      const dayNum = String(day.getDate()).padStart(2, '0');
      const dateStr = `${y}-${m}-${dayNum}`;
      weekDays.push({
        dateStr,
        dayName: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie'][i],
        dayNumber: day.getDate()
      });
    }
    return weekDays;
  };

  const weekDays = getWeekDays(weekAnchorDate);

  // Month names for selector
  const monthNames = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ];

  // Calculate monthly stats for a student
  const getStudentMonthStats = (studentId: string, month: number, year: number) => {
    let p = 0;
    let a = 0;
    let t = 0;
    let j = 0;
    const prefix = `${year}-${String(month).padStart(2, '0')}`;

    Object.entries(data.attendance).forEach(([key, records]) => {
      const [date, cId] = key.split(':');
      if (cId === activeClassId && date.startsWith(prefix)) {
        const st = records[studentId];
        if (st === 'P') p++;
        else if (st === 'A') a++;
        else if (st === 'T') t++;
        else if (st === 'J') j++;
      }
    });

    const total = p + a + t + j;
    const pct = total > 0 ? Math.round(((p + j + t * 0.5) / total) * 100) : 100;
    return { p, a, t, j, total, pct };
  };

  // Calculate yearly stats for a student
  const getStudentYearStats = (studentId: string, year: number) => {
    let p = 0;
    let a = 0;
    let t = 0;
    let j = 0;
    const prefix = `${year}-`;

    Object.entries(data.attendance).forEach(([key, records]) => {
      const [date, cId] = key.split(':');
      if (cId === activeClassId && date.startsWith(prefix)) {
        const st = records[studentId];
        if (st === 'P') p++;
        else if (st === 'A') a++;
        else if (st === 'T') t++;
        else if (st === 'J') j++;
      }
    });

    const total = p + a + t + j;
    const pct = total > 0 ? Math.round(((p + j + t * 0.5) / total) * 100) : 100;
    return { p, a, t, j, total, pct };
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col justify-between gap-4 rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs sm:flex-row sm:items-center">
        <div>
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#c6292e]">
            Control y Registro
          </span>
          <h2 className="mt-1 text-2xl font-black text-[#26302b] sm:text-3xl">Control de asistencia</h2>
          <p className="mt-1 text-xs text-[#6d766f]">
            {isStudent
              ? 'Consulta tu historial de puntualidad, faltas y asistencias por día, semana, mes y año.'
              : 'Registra y analiza la asistencia escolar por día, semana, mes o año académico.'}
          </p>
        </div>

        {!isStudent && (
          <div className="flex items-center gap-2">
            {periodMode === 'day' && activeClassId && classStudents.length > 0 && (
              <button
                onClick={() => onMarkAllPresent(activeClassId, selectedDate)}
                className="flex items-center gap-1.5 rounded-xl border border-[#dfe6df] bg-[#eef2ee] px-3.5 py-2.5 text-xs font-bold text-[#26302b] hover:bg-[#dfe6df]"
                title="Marcar 'Presente' a todos los alumnos de este día"
              >
                <Check className="h-4 w-4 text-[#2f8b3c]" />
                <span>Todos presentes</span>
              </button>
            )}

            <button
              onClick={onSaveToast}
              className="flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-[#9f1d24]"
            >
              <Save className="h-4 w-4" />
              <span>Guardar registro</span>
            </button>
          </div>
        )}
      </div>

      {isStudent && (
        <div className="flex items-center gap-2.5 rounded-2xl border border-[#2f8b3c]/20 bg-[#eaf6ec] p-4 text-xs font-bold text-[#236a2d]">
          <Eye className="h-4 w-4 shrink-0" />
          <span>
            Modo visualización de alumno: Solo lectura. Las modificaciones son efectuadas por el docente o administración.
          </span>
        </div>
      )}

      {/* View Period Selector & Filters Toolbar */}
      <div className="space-y-3 rounded-2xl border border-[#dfe6df] bg-white p-4 shadow-xs">
        {/* Period mode tabs */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#dfe6df] pb-3">
          <div className="flex items-center gap-1 rounded-xl bg-[#f7f8f6] p-1 border border-[#dfe6df]">
            <button
              onClick={() => setPeriodMode('day')}
              className={`rounded-lg px-3.5 py-1.5 text-xs font-black transition ${
                periodMode === 'day'
                  ? 'bg-[#c6292e] text-white shadow-xs'
                  : 'text-[#5d685f] hover:text-[#26302b]'
              }`}
            >
              Por Día
            </button>
            <button
              onClick={() => setPeriodMode('week')}
              className={`rounded-lg px-3.5 py-1.5 text-xs font-black transition ${
                periodMode === 'week'
                  ? 'bg-[#c6292e] text-white shadow-xs'
                  : 'text-[#5d685f] hover:text-[#26302b]'
              }`}
            >
              Por Semana
            </button>
            <button
              onClick={() => setPeriodMode('month')}
              className={`rounded-lg px-3.5 py-1.5 text-xs font-black transition ${
                periodMode === 'month'
                  ? 'bg-[#c6292e] text-white shadow-xs'
                  : 'text-[#5d685f] hover:text-[#26302b]'
              }`}
            >
              Por Mes
            </button>
            <button
              onClick={() => setPeriodMode('year')}
              className={`rounded-lg px-3.5 py-1.5 text-xs font-black transition ${
                periodMode === 'year'
                  ? 'bg-[#c6292e] text-white shadow-xs'
                  : 'text-[#5d685f] hover:text-[#26302b]'
              }`}
            >
              Por Año
            </button>
          </div>

          <div className="flex items-center gap-2">
            <label className="text-xs font-extrabold text-[#26302b]">Clase:</label>
            <select
              value={activeClassId}
              onChange={e => setSelectedClassId(e.target.value)}
              className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-2 text-xs font-bold text-[#26302b] outline-none focus:border-[#2f8b3c]"
            >
              {allowedClasses.length === 0 && <option value="">No hay clases asignadas</option>}
              {allowedClasses.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name} {c.grade ? `(${c.grade})` : ''}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Mode specific controls */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          {periodMode === 'day' && (
            <div className="flex items-center gap-2">
              <label className="text-xs font-extrabold text-[#26302b]">Fecha del día:</label>
              <input
                type="date"
                value={selectedDate}
                onChange={e => setSelectedDate(e.target.value)}
                className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-2 text-xs font-bold text-[#26302b] outline-none focus:border-[#2f8b3c]"
              />
              <span className="text-xs text-[#6d766f]">({formatDate(selectedDate)})</span>
            </div>
          )}

          {periodMode === 'week' && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  const d = new Date(weekAnchorDate);
                  d.setDate(d.getDate() - 7);
                  setWeekAnchorDate(d);
                }}
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-[#dfe6df] bg-[#f7f8f6] text-[#26302b] hover:bg-[#eef2ee]"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <span className="text-xs font-bold text-[#26302b]">
                Semana: {weekDays[0].dateStr} al {weekDays[4].dateStr}
              </span>
              <button
                onClick={() => {
                  const d = new Date(weekAnchorDate);
                  d.setDate(d.getDate() + 7);
                  setWeekAnchorDate(d);
                }}
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-[#dfe6df] bg-[#f7f8f6] text-[#26302b] hover:bg-[#eef2ee]"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
              <button
                onClick={() => setWeekAnchorDate(new Date())}
                className="rounded-lg bg-[#eef2ee] px-2.5 py-1 text-[11px] font-bold text-[#435047] hover:bg-[#dfe6df]"
              >
                Esta semana
              </button>
            </div>
          )}

          {periodMode === 'month' && (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <label className="text-xs font-extrabold text-[#26302b]">Mes:</label>
                <select
                  value={selectedMonth}
                  onChange={e => setSelectedMonth(Number(e.target.value))}
                  className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-2 text-xs font-bold text-[#26302b] outline-none"
                >
                  {monthNames.map((name, i) => (
                    <option key={i + 1} value={i + 1}>
                      {name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex items-center gap-2">
                <label className="text-xs font-extrabold text-[#26302b]">Año:</label>
                <select
                  value={selectedYear}
                  onChange={e => setSelectedYear(Number(e.target.value))}
                  className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-2 text-xs font-bold text-[#26302b] outline-none"
                >
                  {[2024, 2025, 2026, 2027].map(y => (
                    <option key={y} value={y}>
                      {y}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {periodMode === 'year' && (
            <div className="flex items-center gap-2">
              <label className="text-xs font-extrabold text-[#26302b]">Año escolar:</label>
              <select
                value={selectedYear}
                onChange={e => setSelectedYear(Number(e.target.value))}
                className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-2 text-xs font-bold text-[#26302b] outline-none"
              >
                {[2024, 2025, 2026, 2027].map(y => (
                  <option key={y} value={y}>
                    Ciclo Escolar {y}
                  </option>
                ))}
              </select>
            </div>
          )}

          {currentClass && (
            <div className="text-xs text-[#6d766f]">
              Clase: <strong className="text-[#26302b]">{currentClass.name}</strong> · {classStudents.length} alumnos
            </div>
          )}
        </div>
      </div>

      {/* Attendance Content Table */}
      <div className="overflow-hidden rounded-3xl border border-[#dfe6df] bg-white shadow-xs">
        {classStudents.length === 0 ? (
          <div className="p-12 text-center text-xs text-[#6d766f]">
            <Users className="mx-auto h-12 w-12 text-[#cad4cb] mb-3" />
            <strong className="block text-sm font-extrabold text-[#26302b]">
              No hay alumnos para mostrar
            </strong>
            <span>Verifica la clase o agrega estudiantes para visualizar su asistencia.</span>
          </div>
        ) : (
          <div className="overflow-x-auto">
            {/* 1. DAY VIEW */}
            {periodMode === 'day' && (
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-[#dfe6df] bg-[#f7f8f6] text-[11px] font-bold uppercase tracking-wider text-[#6d766f]">
                    <th className="py-3.5 px-5">Alumno</th>
                    <th className="py-3.5 px-5">Asistencia global</th>
                    <th className="py-3.5 px-5 text-right">Estado ({formatDate(selectedDate)})</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#dfe6df]">
                  {classStudents.map(student => {
                    const studentStatus = dayRecords[student.id] || 'P';
                    const attPercent = calculateStudentAttendancePercentage(
                      student.id,
                      activeClassId,
                      data.attendance
                    );

                    return (
                      <tr key={student.id} className="transition hover:bg-[#fbfcfb]">
                        <td className="py-3.5 px-5">
                          <div className="flex items-center gap-3">
                            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#2f8b3c]/15 text-xs font-bold text-[#236a2d]">
                              {getInitials(student.name)}
                            </div>
                            <div>
                              <strong className="block text-xs font-extrabold text-[#26302b]">
                                {student.name}
                              </strong>
                              <span className="block text-[11px] text-[#6d766f]">ID: {student.code || '—'}</span>
                            </div>
                          </div>
                        </td>

                        <td className="py-3.5 px-5">
                          <span className="font-bold text-[#236a2d]">{attPercent}%</span>
                        </td>

                        <td className="py-3.5 px-5 text-right">
                          {isStudent ? (
                            <span
                              className={`inline-block rounded-xl px-3 py-1.5 text-xs font-extrabold ${
                                STATUS_CONFIG[studentStatus]?.badgeClass || 'bg-[#eef2ee] text-[#26302b]'
                              }`}
                            >
                              {STATUS_CONFIG[studentStatus]?.label || 'Presente'}
                            </span>
                          ) : (
                            <div className="inline-flex gap-1.5 rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-1">
                              {(['P', 'A', 'T', 'J'] as const).map(statusKey => {
                                const config = STATUS_CONFIG[statusKey];
                                const isSelected = studentStatus === statusKey;

                                return (
                                  <button
                                    key={statusKey}
                                    onClick={() =>
                                      onSetAttendance(activeClassId, selectedDate, student.id, statusKey)
                                    }
                                    className={`rounded-lg px-3 py-1.5 text-xs font-extrabold transition ${
                                      isSelected ? config.activeClass : config.inactiveClass
                                    }`}
                                  >
                                    {config.label}
                                  </button>
                                );
                              })}
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}

            {/* 2. WEEK VIEW */}
            {periodMode === 'week' && (
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-[#dfe6df] bg-[#f7f8f6] text-[11px] font-bold uppercase tracking-wider text-[#6d766f]">
                    <th className="py-3.5 px-5 min-w-[180px]">Alumno</th>
                    {weekDays.map(w => (
                      <th key={w.dateStr} className="py-3.5 px-3 text-center">
                        <div className="font-black text-[#26302b]">{w.dayName} {w.dayNumber}</div>
                        <div className="text-[10px] text-[#6d766f]">{w.dateStr.slice(5)}</div>
                      </th>
                    ))}
                    <th className="py-3.5 px-4 text-center">Total semana</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#dfe6df]">
                  {classStudents.map(student => {
                    let weekPresents = 0;

                    return (
                      <tr key={student.id} className="transition hover:bg-[#fbfcfb]">
                        <td className="py-3.5 px-5">
                          <strong className="block text-xs font-extrabold text-[#26302b]">
                            {student.name}
                          </strong>
                          <span className="text-[10px] text-[#6d766f]">ID: {student.code || '—'}</span>
                        </td>

                        {weekDays.map(w => {
                          const wKey = `${w.dateStr}:${activeClassId}`;
                          const st = data.attendance[wKey] ? data.attendance[wKey][student.id] : undefined;
                          if (st === 'P' || st === 'J') weekPresents++;

                          return (
                            <td key={w.dateStr} className="py-3.5 px-3 text-center">
                              {!st ? (
                                <span className="text-[#cad4cb] font-bold">—</span>
                              ) : (
                                <span
                                  className={`inline-block rounded-lg px-2 py-0.5 text-[11px] font-black ${
                                    STATUS_CONFIG[st]?.badgeClass || 'bg-gray-100'
                                  }`}
                                >
                                  {st}
                                </span>
                              )}
                            </td>
                          );
                        })}

                        <td className="py-3.5 px-4 text-center">
                          <span className="rounded-lg bg-[#eaf6ec] px-2.5 py-1 text-xs font-bold text-[#236a2d]">
                            {weekPresents}/5 asist.
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}

            {/* 3. MONTH VIEW */}
            {periodMode === 'month' && (
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-[#dfe6df] bg-[#f7f8f6] text-[11px] font-bold uppercase tracking-wider text-[#6d766f]">
                    <th className="py-3.5 px-5">Alumno</th>
                    <th className="py-3.5 px-4 text-center">Presentes (P)</th>
                    <th className="py-3.5 px-4 text-center">Ausentes (A)</th>
                    <th className="py-3.5 px-4 text-center">Tardanzas (T)</th>
                    <th className="py-3.5 px-4 text-center">Justificadas (J)</th>
                    <th className="py-3.5 px-5 text-right">% Asistencia del Mes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#dfe6df]">
                  {classStudents.map(student => {
                    const stats = getStudentMonthStats(student.id, selectedMonth, selectedYear);

                    return (
                      <tr key={student.id} className="transition hover:bg-[#fbfcfb]">
                        <td className="py-3.5 px-5">
                          <strong className="block text-xs font-extrabold text-[#26302b]">
                            {student.name}
                          </strong>
                          <span className="text-[10px] text-[#6d766f]">ID: {student.code || '—'}</span>
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          <span className="font-bold text-[#2f8b3c]">{stats.p}</span>
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          <span className="font-bold text-[#c6292e]">{stats.a}</span>
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          <span className="font-bold text-[#f5c400]">{stats.t}</span>
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          <span className="font-bold text-[#236a2d]">{stats.j}</span>
                        </td>

                        <td className="py-3.5 px-5 text-right">
                          <span
                            className={`rounded-xl px-2.5 py-1 text-xs font-extrabold ${
                              stats.pct >= 85
                                ? 'bg-[#eaf6ec] text-[#236a2d]'
                                : stats.pct >= 75
                                ? 'bg-[#fff7cc] text-[#735f00]'
                                : 'bg-[#fde7e7] text-[#c6292e]'
                            }`}
                          >
                            {stats.pct}%
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}

            {/* 4. YEAR VIEW */}
            {periodMode === 'year' && (
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-[#dfe6df] bg-[#f7f8f6] text-[11px] font-bold uppercase tracking-wider text-[#6d766f]">
                    <th className="py-3.5 px-5">Alumno</th>
                    <th className="py-3.5 px-4 text-center">Sesiones Evaluadas</th>
                    <th className="py-3.5 px-4 text-center">Total Presentes</th>
                    <th className="py-3.5 px-4 text-center">Total Inasistencias</th>
                    <th className="py-3.5 px-5 text-right">% Anual Acumulado</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#dfe6df]">
                  {classStudents.map(student => {
                    const stats = getStudentYearStats(student.id, selectedYear);

                    return (
                      <tr key={student.id} className="transition hover:bg-[#fbfcfb]">
                        <td className="py-3.5 px-5">
                          <strong className="block text-xs font-extrabold text-[#26302b]">
                            {student.name}
                          </strong>
                          <span className="text-[10px] text-[#6d766f]">ID: {student.code || '—'}</span>
                        </td>

                        <td className="py-3.5 px-4 text-center text-[#5d685f]">
                          {stats.total} días registrados
                        </td>

                        <td className="py-3.5 px-4 text-center font-bold text-[#2f8b3c]">
                          {stats.p + stats.j} días
                        </td>

                        <td className="py-3.5 px-4 text-center font-bold text-[#c6292e]">
                          {stats.a} faltas ({stats.t} tardes)
                        </td>

                        <td className="py-3.5 px-5 text-right">
                          <span
                            className={`rounded-xl px-3 py-1 text-xs font-black ${
                              stats.pct >= 85
                                ? 'bg-[#eaf6ec] text-[#236a2d]'
                                : stats.pct >= 75
                                ? 'bg-[#fff7cc] text-[#735f00]'
                                : 'bg-[#fde7e7] text-[#c6292e]'
                            }`}
                          >
                            {stats.pct}%
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
