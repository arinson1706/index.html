import React, { useState, useMemo, useEffect } from 'react';
import { LayoutGrid, Plus, Search, Users, BarChart3, Edit, Trash2, UserCheck, GraduationCap, ArrowRight, BookOpen, CheckSquare } from 'lucide-react';
import { AppData, ClassRoom, User } from '../../types';
import { calculateClassAverage, isStudentInClass, matchGrade } from '../../utils/storage';
import { getAllowedClasses } from '../../utils/rbac';
import { STANDARD_GRADES } from '../../constants/initialData';

interface ClassesViewProps {
  data: AppData;
  currentUser: User;
  onAddClass: (defaultGrade?: string) => void;
  onEditClass: (classItem: ClassRoom) => void;
  onDeleteClass: (id: string) => void;
  onViewClassStudents: (classId: string) => void;
  onViewClassGrades: (classId: string) => void;
  onViewClassActivities?: (classId: string) => void;
  onAddStudentToClass?: (classId: string, defaultGrade?: string) => void;
}

export const ClassesView: React.FC<ClassesViewProps> = ({
  data,
  currentUser,
  onAddClass,
  onEditClass,
  onDeleteClass,
  onViewClassStudents,
  onViewClassGrades,
  onViewClassActivities,
  onAddStudentToClass
}) => {
  const [selectedGrade, setSelectedGrade] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const isAdmin = currentUser.role === 'admin';
  const isTeacher = currentUser.role === 'teacher';

  // Role based class scoping: teachers only see classes assigned to them
  const allowedClasses = getAllowedClasses(data.classes, currentUser, data.students);

  // Visible grades list:
  // For teachers: ONLY the grades where the teacher is assigned classes.
  // For admins: All system grades.
  const gradeList = useMemo(() => {
    if (isTeacher) {
      // Find distinct grades from classes explicitly assigned to this teacher
      const teacherClassGrades = allowedClasses
        .map(c => c.grade)
        .filter((g): g is string => Boolean(g && g.trim()));

      const list: { value: string; label: string }[] = [];
      const seenValues = new Set<string>();

      teacherClassGrades.forEach(g => {
        // Find matching standard grade for a clean display name if present
        const standardMatch = STANDARD_GRADES.find(sg => matchGrade(sg.value, g));
        const canonicalValue = standardMatch ? standardMatch.value : g.trim();
        const canonicalLabel = standardMatch ? standardMatch.label : (g.toLowerCase().startsWith('grado') ? g.trim() : `Grado ${g.trim()}`);

        if (!seenValues.has(canonicalValue)) {
          seenValues.add(canonicalValue);
          list.push({ value: canonicalValue, label: canonicalLabel });
        }
      });

      // Sort in standard scholastic order
      list.sort((a, b) => {
        const idxA = STANDARD_GRADES.findIndex(sg => sg.value === a.value);
        const idxB = STANDARD_GRADES.findIndex(sg => sg.value === b.value);
        if (idxA !== -1 && idxB !== -1) return idxA - idxB;
        if (idxA !== -1) return -1;
        if (idxB !== -1) return 1;
        return a.value.localeCompare(b.value);
      });

      return list;
    }

    // Admins see all standard grades plus custom ones
    const list: { value: string; label: string }[] = [...STANDARD_GRADES];
    const customInClasses = data.classes
      .map(c => c.grade)
      .filter((g): g is string => Boolean(g) && !STANDARD_GRADES.some(sg => sg.value === g));
    const uniqueCustom = Array.from(new Set(customInClasses));
    uniqueCustom.forEach(cg => {
      list.push({ value: cg, label: `Grado ${cg}` });
    });
    return list;
  }, [data.classes, allowedClasses, isTeacher]);

  // Keep selectedGrade consistent if user is teacher and current selection is not in their assigned grades
  useEffect(() => {
    if (isTeacher && selectedGrade !== 'all') {
      const exists = gradeList.some(g => matchGrade(g.value, selectedGrade) || g.value === selectedGrade);
      if (!exists) {
        setSelectedGrade('all');
      }
    }
  }, [isTeacher, selectedGrade, gradeList]);

  // Filter classes by selected grade and search
  const filteredClasses = useMemo(() => {
    return allowedClasses.filter(c => {
      const matchesGrade = selectedGrade === 'all' || matchGrade(c.grade, selectedGrade);
      const q = searchTerm.toLowerCase();
      const teacher = data.users.find(u => u.id === c.teacherId);
      const matchesSearch =
        !q ||
        c.name.toLowerCase().includes(q) ||
        (c.grade || '').toLowerCase().includes(q) ||
        (c.section || '').toLowerCase().includes(q) ||
        (c.subject || '').toLowerCase().includes(q) ||
        (teacher?.name || '').toLowerCase().includes(q);
      return matchesGrade && matchesSearch;
    });
  }, [allowedClasses, selectedGrade, searchTerm, data.users]);

  // Details of currently selected grade
  const selectedGradeObj = gradeList.find(g => matchGrade(g.value, selectedGrade) || g.value === selectedGrade);
  const selectedGradeStudentCount = selectedGrade === 'all'
    ? (isTeacher
        ? data.students.filter(s => s.status !== 'Inactivo' && allowedClasses.some(c => isStudentInClass(s, c))).length
        : data.students.filter(s => s.status !== 'Inactivo').length)
    : (isTeacher
        ? data.students.filter(s => s.status !== 'Inactivo' && matchGrade(s.grade, selectedGrade) && allowedClasses.some(c => isStudentInClass(s, c))).length
        : data.students.filter(s => s.status !== 'Inactivo' && matchGrade(s.grade, selectedGrade)).length);

  const selectedGradeClassCount = selectedGrade === 'all'
    ? allowedClasses.length
    : allowedClasses.filter(c => matchGrade(c.grade, selectedGrade)).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col justify-between gap-4 rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs sm:flex-row sm:items-center">
        <div>
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#c6292e]">
            {isAdmin ? 'Supervisión Institucional' : 'Espacio de Trabajo'}
          </span>
          <h2 className="mt-1 text-2xl font-black text-[#26302b] sm:text-3xl">
            {isAdmin
              ? 'Asignación de Clases por Grado'
              : isTeacher
              ? 'Mis Clases y Grados Asignados'
              : 'Mis Clases'}
          </h2>
          <p className="mt-1 text-xs text-[#6d766f]">
            {isAdmin
              ? 'Primero selecciona el grado escolar para supervisar o asignar nuevas materias y docentes titulares.'
              : 'Consulta las materias y grupos organizados por grado académico.'}
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => onAddClass(selectedGrade !== 'all' ? selectedGrade : undefined)}
            className="flex items-center justify-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2.5 text-xs font-bold text-white shadow-sm transition hover:bg-[#9f1d24]"
          >
            <Plus className="h-4 w-4" />
            <span>
              {selectedGrade !== 'all'
                ? `Asignar clase a ${selectedGradeObj?.label || selectedGrade}`
                : 'Crear y asignar clase'}
            </span>
          </button>
        )}
      </div>

      {/* PASO 1: BARRA SELECTORA DE GRADOS */}
      <div className="rounded-3xl border border-[#dfe6df] bg-white p-5 shadow-xs">
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#f0f4f0] text-[#2f8b3c]">
              <GraduationCap className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-[#26302b]">
                {isAdmin ? '1. Selecciona el Grado Escolar' : 'Tus Grados Asignados'}
              </h3>
              <p className="text-[11px] text-[#6d766f]">
                {isAdmin
                  ? 'Haz clic en un grado para ver sus clases o asignarle una nueva materia.'
                  : 'Solo se muestran los grados escolares donde tienes clases asignadas a tu cargo.'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {onAddStudentToClass && selectedGrade !== 'all' && (
              <button
                onClick={() => onAddStudentToClass('', selectedGrade)}
                className="inline-flex items-center gap-1.5 rounded-xl bg-[#2f8b3c] px-3.5 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-[#236a2d]"
                title={`Agregar alumno a ${selectedGradeObj?.label || selectedGrade}`}
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Agregar alumno a {selectedGrade}</span>
              </button>
            )}
            {isAdmin && selectedGrade !== 'all' && (
              <button
                onClick={() => onAddClass(selectedGrade)}
                className="hidden sm:inline-flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-3 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-[#9f1d24]"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Asignar clase a {selectedGrade}</span>
              </button>
            )}
          </div>
        </div>

        {/* Grade Chips Scrollable */}
        {isTeacher && gradeList.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-[#dfe6df] bg-[#fbfdfb] p-6 text-center">
            <GraduationCap className="mx-auto h-8 w-8 text-[#98a39b] mb-1.5" />
            <p className="text-xs font-bold text-[#26302b]">
              No tienes ningún grado escolar asignado por el momento
            </p>
            <p className="mt-1 text-[11px] text-[#6d766f] max-w-sm mx-auto">
              El administrador aún no te ha asignado clases. Cuando se te asigne una materia, su grado aparecerá automáticamente aquí.
            </p>
          </div>
        ) : (
          <div className="flex flex-wrap items-center gap-2 pt-1">
            {(!isTeacher || gradeList.length > 1) && (
              <button
                type="button"
                onClick={() => setSelectedGrade('all')}
                className={`flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold transition ${
                  selectedGrade === 'all'
                    ? 'bg-[#26302b] text-white shadow-sm'
                    : 'border border-[#dfe6df] bg-[#f7f8f6] text-[#536057] hover:bg-[#eef2ee]'
                }`}
              >
                <LayoutGrid className="h-3.5 w-3.5" />
                <span>{isTeacher ? 'Todos mis grados' : 'Todos los grados'}</span>
                <span className={`rounded-full px-1.5 py-0.2 text-[10px] font-black ${
                  selectedGrade === 'all' ? 'bg-white/20 text-white' : 'bg-[#e5e9e5] text-[#26302b]'
                }`}>
                  {allowedClasses.length}
                </span>
              </button>
            )}

            {gradeList.map(g => {
              const countInGrade = allowedClasses.filter(c => matchGrade(c.grade, g.value)).length;
              const studentsInGrade = isTeacher
                ? data.students.filter(s => matchGrade(s.grade, g.value) && s.status !== 'Inactivo' && allowedClasses.some(c => isStudentInClass(s, c))).length
                : data.students.filter(s => matchGrade(s.grade, g.value) && s.status !== 'Inactivo').length;
              const isSelected = selectedGrade === g.value || matchGrade(selectedGrade, g.value);

              return (
                <button
                  key={g.value}
                  type="button"
                  onClick={() => setSelectedGrade(g.value)}
                  className={`flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold transition ${
                    isSelected
                      ? 'bg-[#2f8b3c] text-white shadow-sm ring-2 ring-[#2f8b3c]/20'
                      : 'border border-[#dfe6df] bg-[#f7f8f6] text-[#26302b] hover:bg-[#eef2ee]'
                  }`}
                >
                  <span>{g.label}</span>
                  <span className={`rounded-full px-1.5 py-0.2 text-[10px] font-black ${
                    isSelected ? 'bg-white/20 text-white' : 'bg-[#e5e9e5] text-[#26302b]'
                  }`}>
                    {countInGrade} {countInGrade === 1 ? 'clase' : 'clases'}
                  </span>
                  {studentsInGrade > 0 && (
                    <span className="text-[10px] opacity-75 font-semibold">
                      ({studentsInGrade} alum.)
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* BANNER DE ESTADO DEL GRADO SELECCIONADO */}
      {selectedGrade !== 'all' && (
        <div className="flex flex-col justify-between gap-4 rounded-3xl border border-[#bfe2c4] bg-[#f4fbf5] p-5 shadow-xs sm:flex-row sm:items-center">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#2f8b3c] text-white shadow-xs">
              <GraduationCap className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-[#236a2d]">
                  {isTeacher ? 'Grado Asignado' : 'Grado Activo'}
                </span>
                <span className="rounded-full bg-white px-2 py-0.5 text-[10px] font-bold text-[#236a2d] border border-[#bfe2c4]">
                  Año 2026
                </span>
              </div>
              <h3 className="text-lg font-black text-[#26302b]">
                {selectedGradeObj?.label || `Grado ${selectedGrade}`}
              </h3>
              <p className="text-xs text-[#536057]">
                <strong>{selectedGradeStudentCount} alumnos</strong> matriculados · <strong>{selectedGradeClassCount} {selectedGradeClassCount === 1 ? 'clase' : 'clases'}</strong> {isTeacher ? 'a tu cargo' : 'asignadas'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedGrade('all')}
              className="rounded-xl border border-[#cad4cb] bg-white px-3 py-2 text-xs font-bold text-[#536057] hover:bg-[#f7f8f6]"
            >
              {isTeacher ? 'Ver todos mis grados' : 'Ver todos los grados'}
            </button>
            {isAdmin && (
              <button
                onClick={() => onAddClass(selectedGrade)}
                className="flex items-center gap-1.5 rounded-xl bg-[#2f8b3c] px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-[#236a2d]"
              >
                <Plus className="h-4 w-4" />
                <span>Asignar clase a este grado</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* BUSCADOR Y FILTROS */}
      <div className="flex items-center gap-3 rounded-2xl border border-[#dfe6df] bg-white p-3 shadow-xs">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-[#6d766f]" />
          <input
            type="text"
            placeholder={
              selectedGrade !== 'all'
                ? `Buscar en ${selectedGradeObj?.label || selectedGrade} por materia o profesor...`
                : 'Buscar por nombre, grado, materia o docente asignado...'
            }
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] py-2 pl-9 pr-4 text-xs outline-none transition focus:border-[#2f8b3c] focus:bg-white"
          />
        </div>
      </div>

      {/* Class Cards Grid */}
      {filteredClasses.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-[#cad4cb] bg-white p-12 text-center shadow-xs">
          <LayoutGrid className="mx-auto h-12 w-12 text-[#cad4cb] mb-3" />
          <h3 className="text-sm font-extrabold text-[#26302b]">
            {selectedGrade !== 'all'
              ? `No hay clases asignadas para ${selectedGradeObj?.label || selectedGrade}`
              : 'No se encontraron clases'}
          </h3>
          <p className="mt-1 text-xs text-[#6d766f] max-w-md mx-auto">
            {searchTerm
              ? 'Intenta con otro término de búsqueda.'
              : selectedGrade !== 'all' && isAdmin
              ? `Este grado tiene ${selectedGradeStudentCount} alumnos matriculados esperando sus asignaturas. Haz clic en el botón para asignarle su primera materia y profesor.`
              : isAdmin
              ? 'Selecciona un grado y crea la primera clase con su docente.'
              : isTeacher
              ? 'No tienes materias ni clases asignadas a tu cargo en este grado actualmente.'
              : 'Aún no tienes clases asignadas en este grado.'}
          </p>
          {isAdmin && (
            <button
              onClick={() => onAddClass(selectedGrade !== 'all' ? selectedGrade : undefined)}
              className="mt-4 inline-flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-[#9f1d24]"
            >
              <Plus className="h-4 w-4" />
              <span>
                {selectedGrade !== 'all'
                  ? `Asignar clase a ${selectedGradeObj?.label || selectedGrade}`
                  : 'Crear y asignar clase'}
              </span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          {filteredClasses.map(c => {
            const studentCount = data.students.filter(s => isStudentInClass(s, c)).length;
            const avg = calculateClassAverage(c, data.students, data.grades, data.classes, data.activities);
            const teacher = data.users.find(u => u.id === c.teacherId);

            return (
              <div
                key={c.id}
                className="flex flex-col justify-between rounded-3xl border border-[#dfe6df] bg-white p-5 shadow-xs transition hover:shadow-md"
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-1.5 mb-1">
                        <span className="rounded-full bg-[#eaf6ec] px-2.5 py-0.5 text-[10px] font-black text-[#236a2d]">
                          {c.grade || 'Sin grado'}
                        </span>
                        <span className="rounded-full bg-[#f7f8f6] px-2 py-0.5 text-[10px] font-bold text-[#536057] border border-[#dfe6df]">
                          Sec. {c.section || 'A'}
                        </span>
                      </div>
                      <h3 className="text-base font-extrabold text-[#26302b]">{c.name}</h3>
                      <p className="mt-0.5 text-xs text-[#6d766f]">
                        {c.subject || 'Sin materia asignada'} · Año {c.year}
                      </p>
                    </div>
                  </div>

                  {/* Teacher Assignment Highlight */}
                  <div className="mt-3.5 rounded-2xl bg-[#f7f8f6] p-3 border border-[#dfe6df]">
                    <div className="flex items-center gap-2 text-xs text-[#26302b]">
                      <UserCheck className="h-4 w-4 text-[#2f8b3c] shrink-0" />
                      <div>
                        <span className="text-[10px] uppercase tracking-wider text-[#6d766f] block font-bold">
                          Docente titular
                        </span>
                        <strong className="text-xs text-[#26302b]">
                          {teacher?.name || 'Sin docente asignado'}
                        </strong>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center justify-between text-xs text-[#536057]">
                    <span className="flex items-center gap-1">
                      <Users className="h-3.5 w-3.5 text-[#2f8b3c]" />
                      <strong>{studentCount}</strong> alumnos en este grado
                    </span>
                    <span className="flex items-center gap-1">
                      <BarChart3 className="h-3.5 w-3.5 text-[#2f8b3c]" />
                      Promedio: <strong className="text-[#236a2d]">{avg}%</strong>
                    </span>
                  </div>

                  <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-[#edf1ed]">
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{
                        width: `${avg}%`,
                        background: 'linear-gradient(90deg, #c6292e, #f5c400, #2f8b3c)'
                      }}
                    />
                  </div>
                </div>

                <div className="mt-5 border-t border-[#dfe6df] pt-3.5">
                  <div className="grid grid-cols-3 gap-1.5">
                    <button
                      onClick={() => onViewClassStudents(c.id)}
                      className="flex items-center justify-center gap-1 rounded-xl bg-[#eef2ee] py-2 px-1.5 text-[11px] font-bold text-[#26302b] hover:bg-[#dfe6df] transition"
                      title="Ver alumnos matriculados en esta clase"
                    >
                      <Users className="h-3.5 w-3.5 shrink-0" />
                      <span className="truncate">Alumnos ({studentCount})</span>
                    </button>
                    <button
                      onClick={() => onViewClassActivities ? onViewClassActivities(c.id) : onViewClassGrades(c.id)}
                      className="flex items-center justify-center gap-1 rounded-xl bg-[#eef2ee] py-2 px-1.5 text-[11px] font-bold text-[#26302b] hover:bg-[#dfe6df] transition"
                      title="Calificar actividades de esta clase"
                    >
                      <CheckSquare className="h-3.5 w-3.5 shrink-0 text-[#c6292e]" />
                      <span className="truncate">Actividades ({data.activities.filter(a => a.classId === c.id).length})</span>
                    </button>
                    <button
                      onClick={() => onViewClassGrades(c.id)}
                      className="flex items-center justify-center gap-1 rounded-xl bg-[#eef2ee] py-2 px-1.5 text-[11px] font-bold text-[#26302b] hover:bg-[#dfe6df] transition"
                      title="Registro general de calificaciones"
                    >
                      <BarChart3 className="h-3.5 w-3.5 shrink-0 text-[#2f8b3c]" />
                      <span className="truncate">Notas</span>
                    </button>
                  </div>

                  {onAddStudentToClass && (
                    <div className="mt-2.5">
                      <button
                        onClick={() => onAddStudentToClass(c.id, c.grade)}
                        className="w-full flex items-center justify-center gap-1.5 rounded-xl border border-[#2f8b3c]/20 bg-[#f4faf4] py-1.5 px-2.5 text-[11px] font-bold text-[#236a2d] hover:bg-[#eaf6ec] transition"
                        title="Matricular un nuevo alumno en esta clase"
                      >
                        <Plus className="h-3 w-3 text-[#2f8b3c]" />
                        <span>+ Agregar alumno a esta clase</span>
                      </button>
                    </div>
                  )}

                  {isAdmin && (
                    <div className="mt-2 flex items-center justify-end gap-2">
                      <button
                        onClick={() => onEditClass(c)}
                        className="flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-semibold text-[#286e33] hover:bg-[#eaf6ec]"
                      >
                        <Edit className="h-3 w-3" />
                        <span>Editar</span>
                      </button>
                      <button
                        onClick={() => onDeleteClass(c.id)}
                        className="flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-semibold text-[#c6292e] hover:bg-[#fde7e7]"
                      >
                        <Trash2 className="h-3 w-3" />
                        <span>Eliminar</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
