import React, { useState } from 'react';
import {
  BarChart3,
  Plus,
  Trash2,
  CheckCircle2,
  Users,
  ShieldAlert,
  BookOpen,
  GraduationCap,
  Award,
  CheckCircle,
  Clock,
  AlertCircle,
  CheckSquare,
  Paperclip,
  Filter,
  Calendar,
  Lock,
  Unlock,
  Info
} from 'lucide-react';
import { AppData, GradeEvaluation, Activity, User, PeriodsConfig, ParcialId } from '../../types';
import {
  calculateClassAverage,
  calculateStudentAverage,
  getInitials,
  isStudentInClass,
  formatDate,
  isPeriodClosed,
  getActivePeriod
} from '../../utils/storage';
import { getAllowedClasses, getAllowedStudents } from '../../utils/rbac';

interface GradesViewProps {
  data: AppData;
  currentUser: User;
  initialClassId?: string;
  periodsConfig?: PeriodsConfig;
  onAddEvaluation: (classId: string, defaultParcial?: ParcialId) => void;
  onDeleteEvaluation: (id: string) => void;
  onUpdateScore: (evaluationId: string, studentId: string, score: number) => void;
  onUpdateActivityScore?: (activityId: string, studentId: string, score: number) => void;
  onDeleteActivity?: (id: string) => void;
  onAddActivity?: (classId?: string, defaultParcial?: ParcialId) => void;
  onAddClass: () => void;
  onAddStudent: (classId: string) => void;
}

export const GradesView: React.FC<GradesViewProps> = ({
  data,
  currentUser,
  initialClassId = '',
  periodsConfig,
  onAddEvaluation,
  onDeleteEvaluation,
  onUpdateScore,
  onUpdateActivityScore,
  onDeleteActivity,
  onAddActivity,
  onAddClass,
  onAddStudent
}) => {
  const effectivePeriodsConfig = periodsConfig || data.periodsConfig;
  const activePeriodObj = getActivePeriod(effectivePeriodsConfig);
  const [selectedParcial, setSelectedParcial] = useState<ParcialId | 'all'>(activePeriodObj.id);

  const periodsList = effectivePeriodsConfig?.periods || [
    { id: 1 as ParcialId, name: '1er Parcial', status: 'active' as const },
    { id: 2 as ParcialId, name: '2do Parcial', status: 'upcoming' as const },
    { id: 3 as ParcialId, name: '3er Parcial', status: 'upcoming' as const },
    { id: 4 as ParcialId, name: '4to Parcial', status: 'upcoming' as const }
  ];

  const currentPeriodMeta = selectedParcial !== 'all' ? periodsList.find(p => p.id === selectedParcial) : null;
  const isCurrentParcialClosed = selectedParcial !== 'all' && isPeriodClosed(effectivePeriodsConfig, selectedParcial);
  const isCurrentParcialActive = selectedParcial !== 'all' && currentPeriodMeta?.status === 'active';

  const isStudent = currentUser.role === 'student';
  const canManageEvaluations = currentUser.role === 'admin' || currentUser.role === 'teacher';

  // Scoped classes based on role (Teacher only gets assigned classes)
  const allowedClasses = getAllowedClasses(data.classes, currentUser, data.students);

  const [selectedClassId, setSelectedClassId] = useState<string>(() => {
    if (initialClassId && allowedClasses.some(c => c.id === initialClassId)) {
      return initialClassId;
    }
    return allowedClasses[0]?.id || '';
  });

  const [itemFilter, setItemFilter] = useState<'all' | 'activities' | 'evaluations'>('all');

  // Ensure selectedClassId stays valid if allowedClasses changes
  const activeClassId = allowedClasses.some(c => c.id === selectedClassId)
    ? selectedClassId
    : allowedClasses[0]?.id || '';

  // -------------------------------------------------------------
  // STUDENT VIEW: Only see their own grades, separated by classes
  // -------------------------------------------------------------
  if (isStudent) {
    const studentProfile = data.students.find(
      s => s.userId === currentUser.id || s.name.toLowerCase() === currentUser.name.toLowerCase()
    );

    // Classes for this student
    const studentClasses = data.classes.filter(
      c => studentProfile && isStudentInClass(studentProfile, c)
    );

    // Overall student average across their classes (factoring both grades & activities and selectedParcial)
    const classAverages = studentClasses.map(c => {
      if (!studentProfile) return 0;
      return calculateStudentAverage(
        studentProfile.id,
        c.id,
        data.grades,
        data.activities,
        selectedParcial === 'all' ? undefined : selectedParcial
      );
    });

    const overallAverage = classAverages.length > 0
      ? Math.round(classAverages.reduce((a, b) => a + b, 0) / classAverages.length)
      : 0;

    return (
      <div className="space-y-6">
        {/* Student Header */}
        <div className="flex flex-col justify-between gap-4 rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs sm:flex-row sm:items-center">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#2f8b3c]">
                Boleta de Evaluaciones y Actividades
              </span>
              <span className="rounded-full bg-[#eaf6ec] px-2.5 py-0.5 text-[10px] font-bold text-[#236a2d]">
                Privado y Confidencial
              </span>
            </div>
            <h2 className="mt-1 text-2xl font-black text-[#26302b] sm:text-3xl">
              Mis calificaciones y actividades
            </h2>
            <p className="mt-1 text-xs text-[#6d766f]">
              Consulta el detalle de tus tareas, actividades continuas y evaluaciones oficiales por cada parcial.
            </p>
          </div>

          {/* Student Stats Pill */}
          <div className="flex items-center gap-3 rounded-2xl border border-[#dfe6df] bg-[#f7f8f6] p-3.5">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#2f8b3c] text-white shadow-xs">
              <Award className="h-5 w-5" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-[#6d766f]">
                {selectedParcial === 'all' ? 'Promedio anual' : `Promedio ${currentPeriodMeta?.name || ''}`}
              </div>
              <div className="text-xl font-black text-[#26302b]">{overallAverage}%</div>
            </div>
            <span
              className={`ml-2 rounded-xl px-2.5 py-1 text-xs font-bold ${
                overallAverage >= 70
                  ? 'bg-[#eaf6ec] text-[#236a2d]'
                  : overallAverage >= 60
                  ? 'bg-[#fff7cc] text-[#735f00]'
                  : 'bg-[#fde7e7] text-[#c6292e]'
              }`}
            >
              {overallAverage >= 70 ? 'Aprobado' : overallAverage >= 60 ? 'En riesgo' : 'Reprobado'}
            </span>
          </div>
        </div>

        {/* Parcial Navigation Bar for Student */}
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#dfe6df] bg-white p-3.5 shadow-xs">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
            <span className="text-xs font-black text-[#26302b] mr-1 hidden sm:inline">Período:</span>
            {periodsList.map(p => {
              const isSelected = selectedParcial === p.id;
              return (
                <button
                  key={p.id}
                  onClick={() => setSelectedParcial(p.id)}
                  className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-extrabold transition shrink-0 ${
                    isSelected
                      ? 'bg-[#26302b] text-white shadow-xs'
                      : 'bg-[#f7f8f6] text-[#546057] border border-[#dfe6df] hover:bg-[#eef2ee]'
                  }`}
                >
                  <span>{p.name}</span>
                  {p.status === 'active' && (
                    <span className={`h-1.5 w-1.5 rounded-full ${isSelected ? 'bg-[#5cd46e]' : 'bg-[#2f8b3c]'}`} />
                  )}
                  {p.status === 'closed' && (
                    <Lock className={`h-2.5 w-2.5 ${isSelected ? 'text-white/80' : 'text-[#6d766f]'}`} />
                  )}
                </button>
              );
            })}
            <button
              onClick={() => setSelectedParcial('all')}
              className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-extrabold transition shrink-0 ${
                selectedParcial === 'all'
                  ? 'bg-[#26302b] text-white shadow-xs'
                  : 'bg-[#f7f8f6] text-[#546057] border border-[#dfe6df] hover:bg-[#eef2ee]'
              }`}
            >
              <span>Todos / Anual</span>
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs">
            {isCurrentParcialClosed ? (
              <span className="flex items-center gap-1.5 rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-1 text-[11px] font-bold text-[#6d766f]">
                <Lock className="h-3 w-3" />
                Parcial cerrado por Coordinación (Solo lectura)
              </span>
            ) : isCurrentParcialActive ? (
              <span className="flex items-center gap-1.5 rounded-xl border border-[#2f8b3c]/20 bg-[#eaf6ec] px-3 py-1 text-[11px] font-black text-[#236a2d]">
                <span className="h-2 w-2 rounded-full bg-[#2f8b3c] animate-pulse" />
                Parcial activo en curso
              </span>
            ) : null}
          </div>
        </div>

        {studentClasses.length === 0 ? (
          <div className="rounded-3xl border border-dashed border-[#cad4cb] bg-white p-12 text-center shadow-xs">
            <GraduationCap className="mx-auto h-12 w-12 text-[#cad4cb] mb-3" />
            <h3 className="text-sm font-extrabold text-[#26302b]">No tienes clases asignadas</h3>
            <p className="mt-1 text-xs text-[#6d766f]">
              Tu usuario aún no está matriculado en un grado o clase específico. Contacta a tu docente o administración.
            </p>
          </div>
        ) : (
          /* Separate sections per Class */
          <div className="space-y-6">
            {studentClasses.map(cls => {
              const teacher = data.users.find(u => u.id === cls.teacherId);
              const evaluations = data.grades.filter(
                g => g.classId === cls.id && (selectedParcial === 'all' ? true : (g.parcial || 1) === selectedParcial)
              );
              const activities = data.activities.filter(
                a => a.classId === cls.id && (selectedParcial === 'all' ? true : (a.parcial || 1) === selectedParcial)
              );

              const studentAvg = studentProfile
                ? calculateStudentAverage(
                    studentProfile.id,
                    cls.id,
                    data.grades,
                    data.activities,
                    selectedParcial === 'all' ? undefined : selectedParcial
                  )
                : 0;

              // Combine evaluations and activities for unified viewing
              const unifiedItems = [
                ...evaluations.map(e => {
                  const rawScore = studentProfile ? e.scores?.[studentProfile.id] : undefined;
                  const isGraded = rawScore !== undefined && rawScore !== null;
                  const scoreNum = Number(rawScore ?? 0);
                  const percent = e.scale > 0 ? (scoreNum / e.scale) * 100 : 0;
                  return {
                    id: e.id,
                    title: e.title,
                    isActivity: false,
                    type: e.type,
                    weightLabel: `${e.value}%`,
                    scale: e.scale,
                    scoreNum,
                    isGraded,
                    percent,
                    statusText: isGraded ? 'Calificada' : 'Por calificar',
                    attachmentsCount: 0
                  };
                }),
                ...activities.map(a => {
                  const gradeObj = studentProfile ? a.studentGrades?.[studentProfile.id] : undefined;
                  const directScore = studentProfile ? a.scores?.[studentProfile.id] : undefined;
                  const scoreNum = Number(directScore ?? gradeObj?.score ?? 0);
                  const isGraded = directScore !== undefined || gradeObj?.status === 'Calificado' || a.status === 'Calificada';
                  const maxVal = a.value || 100;
                  const percent = maxVal > 0 ? (scoreNum / maxVal) * 100 : 0;
                  const isSubmitted = gradeObj?.status === 'Entregado' || (gradeObj?.attachments && gradeObj.attachments.length > 0);
                  return {
                    id: a.id,
                    title: a.title,
                    isActivity: true,
                    type: 'Actividad / Tarea',
                    weightLabel: `${a.value} pts`,
                    scale: a.value,
                    scoreNum,
                    isGraded,
                    percent,
                    statusText: isGraded ? 'Calificada' : isSubmitted ? 'Entregada' : 'Pendiente',
                    attachmentsCount: (gradeObj?.attachments?.length || 0) + (a.attachments?.length || 0)
                  };
                })
              ];

              return (
                <div
                  key={cls.id}
                  className="rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs"
                >
                  {/* Class Header Bar */}
                  <div className="flex flex-col justify-between gap-3 border-b border-[#dfe6df] pb-4 sm:flex-row sm:items-center">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="rounded-lg bg-[#eef2ee] px-2 py-0.5 text-[11px] font-extrabold text-[#5d685f]">
                          {cls.grade || 'Grado no especificado'} {cls.section ? `· Sección ${cls.section}` : ''}
                        </span>
                        {cls.subject && (
                          <span className="rounded-lg bg-[#eaf6ec] px-2 py-0.5 text-[11px] font-extrabold text-[#236a2d]">
                            {cls.subject}
                          </span>
                        )}
                        <span className="rounded-lg bg-[#f7f8f6] border border-[#dfe6df] px-2 py-0.5 text-[10px] font-bold text-[#6d766f]">
                          {activities.length} actividades · {evaluations.length} evaluaciones
                        </span>
                      </div>
                      <h3 className="mt-1.5 text-lg font-black text-[#26302b]">{cls.name}</h3>
                      <p className="text-xs text-[#6d766f]">
                        Docente encargado: <strong className="text-[#26302b]">{teacher?.name || 'Titular asignado'}</strong>
                      </p>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="text-[11px] font-bold text-[#6d766f]">Promedio en esta clase</div>
                        <div className="text-xl font-black text-[#26302b]">{studentAvg}%</div>
                      </div>
                      <span
                        className={`rounded-xl px-3 py-1.5 text-xs font-black ${
                          studentAvg >= 70
                            ? 'bg-[#eaf6ec] text-[#236a2d]'
                            : studentAvg >= 60
                            ? 'bg-[#fff7cc] text-[#735f00]'
                            : 'bg-[#fde7e7] text-[#c6292e]'
                        }`}
                      >
                        {studentAvg >= 70 ? 'Aprobado' : studentAvg >= 60 ? 'En riesgo' : 'Reprobado'}
                      </span>
                    </div>
                  </div>

                  {/* Class Unified Table strictly for THIS student */}
                  {unifiedItems.length === 0 ? (
                    <div className="py-8 text-center text-xs text-[#6d766f]">
                      No hay actividades ni evaluaciones registradas aún en esta materia.
                    </div>
                  ) : (
                    <div className="mt-4 overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-[#dfe6df] text-[11px] font-extrabold uppercase tracking-wider text-[#6d766f]">
                            <th className="py-2.5 pr-4">Ítem / Actividad</th>
                            <th className="py-2.5 px-3">Categoría</th>
                            <th className="py-2.5 px-3">Puntaje / Valor</th>
                            <th className="py-2.5 px-3">Escala</th>
                            <th className="py-2.5 px-3 text-right">Tu calificación</th>
                            <th className="py-2.5 pl-3 text-right">Estado</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#edf1ed]">
                          {unifiedItems.map(item => (
                            <tr key={item.id} className="hover:bg-[#f7f8f6]">
                              <td className="py-3 pr-4 font-bold text-[#26302b]">
                                <div className="flex items-center gap-1.5">
                                  <span
                                    className={`rounded px-1.5 py-0.5 text-[9px] font-extrabold ${
                                      item.isActivity
                                        ? 'bg-[#eaf6ec] text-[#236a2d]'
                                        : 'bg-[#eef2ee] text-[#465249]'
                                    }`}
                                  >
                                    {item.isActivity ? 'Actividad' : 'Evaluación'}
                                  </span>
                                  <span>{item.title}</span>
                                  {item.attachmentsCount > 0 && (
                                    <span
                                      className="inline-flex items-center text-[#236a2d]"
                                      title="Contiene archivos adjuntos"
                                    >
                                      <Paperclip className="h-3 w-3" />
                                    </span>
                                  )}
                                </div>
                              </td>
                              <td className="py-3 px-3">
                                <span className="rounded-lg bg-[#f0f4f0] px-2 py-0.5 text-[11px] font-bold text-[#465249]">
                                  {item.type}
                                </span>
                              </td>
                              <td className="py-3 px-3 text-[#6d766f]">
                                {item.weightLabel}
                              </td>
                              <td className="py-3 px-3 text-[#6d766f]">
                                0–{item.scale} pts
                              </td>
                              <td className="py-3 px-3 text-right">
                                {item.isGraded ? (
                                  <span
                                    className={`inline-block rounded-lg px-2.5 py-1 text-xs font-black ${
                                      item.percent >= 70
                                        ? 'bg-[#eaf6ec] text-[#236a2d]'
                                        : item.percent >= 60
                                        ? 'bg-[#fff7cc] text-[#735f00]'
                                        : 'bg-[#fde7e7] text-[#c6292e]'
                                    }`}
                                  >
                                    {item.scoreNum} / {item.scale}
                                  </span>
                                ) : (
                                  <span className="rounded-lg bg-[#eef2ee] px-2 py-1 text-[11px] font-semibold text-[#6d766f]">
                                    {item.statusText}
                                  </span>
                                )}
                              </td>
                              <td className="py-3 pl-3 text-right">
                                {item.isGraded ? (
                                  <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#2f8b3c]">
                                    <CheckCircle className="h-3.5 w-3.5" />
                                    <span>Calificada</span>
                                  </span>
                                ) : item.statusText === 'Entregada' ? (
                                  <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#735f00]">
                                    <Clock className="h-3.5 w-3.5" />
                                    <span>Entregada</span>
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#6d766f]">
                                    <Clock className="h-3.5 w-3.5" />
                                    <span>Pendiente</span>
                                  </span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  // -------------------------------------------------------------
  // TEACHER / ADMIN VIEW: Scoped strictly to teacher's classes
  // -------------------------------------------------------------
  const currentClass = allowedClasses.find(c => c.id === activeClassId);
  const classStudents = data.students.filter(
    s => s.status !== 'Inactivo' && (currentClass ? isStudentInClass(s, currentClass) : s.classId === activeClassId)
  );

  const classEvaluations = data.grades.filter(
    g => g.classId === activeClassId && (selectedParcial === 'all' ? true : (g.parcial || 1) === selectedParcial)
  );
  const classActivities = data.activities.filter(
    a => a.classId === activeClassId && (selectedParcial === 'all' ? true : (a.parcial || 1) === selectedParcial)
  );

  const classAvg = currentClass
    ? calculateClassAverage(
        currentClass,
        data.students,
        data.grades,
        data.classes,
        data.activities,
        selectedParcial === 'all' ? undefined : selectedParcial
      )
    : 0;

  // Filter items to display based on user filter tab
  const showEvaluations = itemFilter === 'all' || itemFilter === 'evaluations';
  const showActivities = itemFilter === 'all' || itemFilter === 'activities';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col justify-between gap-4 rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs sm:flex-row sm:items-center">
        <div>
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#c6292e]">
            {currentUser.role === 'admin' ? 'Supervisión de Calificaciones y Actividades' : 'Evaluación Continua y Calificaciones'}
          </span>
          <h2 className="mt-1 text-2xl font-black text-[#26302b] sm:text-3xl">
            Registro de notas y actividades
          </h2>
          <p className="mt-1 text-xs text-[#6d766f]">
            {currentUser.role === 'admin'
              ? 'Supervisa las evaluaciones y actividades de todas las clases y grados de la institución.'
              : 'Asigna puntajes a tus actividades y evaluaciones continuas; los promedios se calculan en tiempo real.'}
          </p>
        </div>

        {/* Action Buttons */}
        {activeClassId && (
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => onAddStudent(activeClassId)}
              className="flex items-center justify-center gap-1.5 rounded-xl border border-[#2f8b3c]/30 bg-[#eaf6ec] px-3.5 py-2.5 text-xs font-bold text-[#236a2d] transition hover:bg-[#d8eedb]"
              title="Agregar un nuevo estudiante a esta clase"
            >
              <Users className="h-4 w-4 text-[#2f8b3c]" />
              <span>+ Agregar alumno</span>
            </button>

            {onAddActivity && (
              <button
                disabled={isCurrentParcialClosed}
                onClick={() => onAddActivity(activeClassId, selectedParcial !== 'all' ? selectedParcial : activePeriodObj.id)}
                className={`flex items-center justify-center gap-1.5 rounded-xl px-3.5 py-2.5 text-xs font-bold shadow-sm transition ${
                  isCurrentParcialClosed
                    ? 'bg-[#dfe6df] text-[#869288] cursor-not-allowed'
                    : 'bg-[#2f8b3c] text-white hover:bg-[#236a2d]'
                }`}
                title={
                  isCurrentParcialClosed
                    ? 'Este parcial está cerrado por Coordinación. No se pueden agregar actividades.'
                    : 'Crear nueva actividad'
                }
              >
                {isCurrentParcialClosed ? <Lock className="h-4 w-4" /> : <CheckSquare className="h-4 w-4" />}
                <span>+ Nueva actividad</span>
              </button>
            )}

            <button
              disabled={isCurrentParcialClosed}
              onClick={() => onAddEvaluation(activeClassId, selectedParcial !== 'all' ? selectedParcial : activePeriodObj.id)}
              className={`flex items-center justify-center gap-1.5 rounded-xl px-3.5 py-2.5 text-xs font-bold shadow-sm transition ${
                isCurrentParcialClosed
                  ? 'bg-[#dfe6df] text-[#869288] cursor-not-allowed'
                  : 'bg-[#c6292e] text-white hover:bg-[#9f1d24]'
              }`}
              title={
                isCurrentParcialClosed
                  ? 'Este parcial está cerrado por Coordinación. No se pueden agregar evaluaciones.'
                  : 'Crear nueva evaluación'
              }
            >
              {isCurrentParcialClosed ? <Lock className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
              <span>+ Nueva evaluación</span>
            </button>
          </div>
        )}
      </div>

      {/* Parcial Navigation Bar for Teacher / Admin */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#dfe6df] bg-white p-3.5 shadow-xs">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <span className="text-xs font-black text-[#26302b] mr-1 hidden sm:inline">Período:</span>
          {periodsList.map(p => {
            const isSelected = selectedParcial === p.id;
            return (
              <button
                key={p.id}
                onClick={() => setSelectedParcial(p.id)}
                className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-extrabold transition shrink-0 ${
                  isSelected
                    ? 'bg-[#26302b] text-white shadow-xs'
                    : 'bg-[#f7f8f6] text-[#546057] border border-[#dfe6df] hover:bg-[#eef2ee]'
                }`}
              >
                <span>{p.name}</span>
                {p.status === 'active' && (
                  <span className={`h-1.5 w-1.5 rounded-full ${isSelected ? 'bg-[#5cd46e]' : 'bg-[#2f8b3c]'}`} />
                )}
                {p.status === 'closed' && (
                  <Lock className={`h-2.5 w-2.5 ${isSelected ? 'text-white/80' : 'text-[#6d766f]'}`} />
                )}
              </button>
            );
          })}
          <button
            onClick={() => setSelectedParcial('all')}
            className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-extrabold transition shrink-0 ${
              selectedParcial === 'all'
                ? 'bg-[#26302b] text-white shadow-xs'
                : 'bg-[#f7f8f6] text-[#546057] border border-[#dfe6df] hover:bg-[#eef2ee]'
            }`}
          >
            <span>Todos / Anual</span>
          </button>
        </div>

        <div className="flex items-center gap-2 text-xs">
          {isCurrentParcialClosed ? (
            <span className="flex items-center gap-1.5 rounded-xl border border-[#c6292e]/20 bg-[#fde7e7] px-3 py-1 text-[11px] font-bold text-[#c6292e]">
              <Lock className="h-3 w-3" />
              Parcial cerrado por Coordinación (Modo solo lectura)
            </span>
          ) : isCurrentParcialActive ? (
            <span className="flex items-center gap-1.5 rounded-xl border border-[#2f8b3c]/20 bg-[#eaf6ec] px-3 py-1 text-[11px] font-black text-[#236a2d]">
              <span className="h-2 w-2 rounded-full bg-[#2f8b3c] animate-pulse" />
              Parcial activo para trabajo
            </span>
          ) : (
            <span className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-1 text-[11px] font-bold text-[#6d766f]">
              Vista consolidada
            </span>
          )}
        </div>
      </div>

      {/* Class Selector Bar (Only allowed classes) & Filter Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#dfe6df] bg-white p-4 shadow-xs">
        <div className="flex items-center gap-3">
          <label className="text-xs font-extrabold text-[#26302b]">
            {currentUser.role === 'admin' ? 'Clase a supervisar:' : 'Tu clase asignada:'}
          </label>
          <select
            value={activeClassId}
            onChange={e => setSelectedClassId(e.target.value)}
            className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3.5 py-2 text-xs font-bold text-[#26302b] outline-none focus:border-[#2f8b3c]"
          >
            {allowedClasses.length === 0 && <option value="">No tienes clases asignadas</option>}
            {allowedClasses.map(c => (
              <option key={c.id} value={c.id}>
                {c.name} {c.grade ? `(${c.grade})` : ''} {c.subject ? `· ${c.subject}` : ''}
              </option>
            ))}
          </select>
        </div>

        {currentClass && (
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <span className="text-[#6d766f]">
              Alumnos: <strong className="text-[#26302b]">{classStudents.length}</strong>
            </span>
            <span className="text-[#6d766f]">
              Actividades: <strong className="text-[#236a2d]">{classActivities.length}</strong>
            </span>
            <span className="text-[#6d766f]">
              Evaluaciones: <strong className="text-[#c6292e]">{classEvaluations.length}</strong>
            </span>
            <span className="rounded-xl bg-[#eaf6ec] px-2.5 py-1 text-xs font-black text-[#236a2d]">
              Promedio grupal: {classAvg}%
            </span>
          </div>
        )}
      </div>

      {/* Filter Tabs for Combined View */}
      {currentClass && (classEvaluations.length > 0 || classActivities.length > 0) && (
        <div className="flex items-center gap-2">
          <button
            onClick={() => setItemFilter('all')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition ${
              itemFilter === 'all'
                ? 'bg-[#26302b] text-white shadow-xs'
                : 'bg-white text-[#6d766f] border border-[#dfe6df] hover:bg-[#f7f8f6]'
            }`}
          >
            Todos ({classEvaluations.length + classActivities.length})
          </button>
          <button
            onClick={() => setItemFilter('activities')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition ${
              itemFilter === 'activities'
                ? 'bg-[#2f8b3c] text-white shadow-xs'
                : 'bg-white text-[#6d766f] border border-[#dfe6df] hover:bg-[#f7f8f6]'
            }`}
          >
            Solo Actividades ({classActivities.length})
          </button>
          <button
            onClick={() => setItemFilter('evaluations')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition ${
              itemFilter === 'evaluations'
                ? 'bg-[#c6292e] text-white shadow-xs'
                : 'bg-white text-[#6d766f] border border-[#dfe6df] hover:bg-[#f7f8f6]'
            }`}
          >
            Solo Evaluaciones ({classEvaluations.length})
          </button>
        </div>
      )}

      {/* Empty States */}
      {allowedClasses.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-[#cad4cb] bg-white p-12 text-center shadow-xs">
          <BarChart3 className="mx-auto h-12 w-12 text-[#cad4cb] mb-3" />
          <h3 className="text-sm font-extrabold text-[#26302b]">
            {currentUser.role === 'admin' ? 'No hay clases creadas' : 'No tienes grados ni clases asignadas'}
          </h3>
          <p className="mt-1 text-xs text-[#6d766f]">
            {currentUser.role === 'admin'
              ? 'Crea una clase para comenzar a registrar notas y actividades.'
              : 'La administración debe asignarte como docente de una clase o grado para calificar.'}
          </p>
          {currentUser.role === 'admin' && (
            <button
              onClick={onAddClass}
              className="mt-4 rounded-xl bg-[#c6292e] px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-[#9f1d24]"
            >
              Crear clase
            </button>
          )}
        </div>
      ) : classStudents.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-[#cad4cb] bg-white p-12 text-center shadow-xs">
          <Users className="mx-auto h-12 w-12 text-[#cad4cb] mb-3" />
          <h3 className="text-sm font-extrabold text-[#26302b]">No hay alumnos en {currentClass?.name}</h3>
          <p className="mt-1 text-xs text-[#6d766f]">
            Agrega estudiantes a este curso y grado para calificar sus actividades y evaluaciones.
          </p>
          <button
            onClick={() => onAddStudent(activeClassId)}
            className="mt-4 rounded-xl bg-[#2f8b3c] px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-[#236a2d]"
          >
            + Agregar alumno a esta clase
          </button>
        </div>
      ) : classEvaluations.length === 0 && classActivities.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-[#cad4cb] bg-white p-12 text-center shadow-xs">
          <BarChart3 className="mx-auto h-12 w-12 text-[#cad4cb] mb-3" />
          <h3 className="text-sm font-extrabold text-[#26302b]">No hay actividades ni evaluaciones para esta clase</h3>
          <p className="mt-1 text-xs text-[#6d766f]">
            Crea una tarea, actividad continua o examen para comenzar a calificar a los {classStudents.length} alumnos.
          </p>
          <div className="mt-4 flex items-center justify-center gap-3">
            {onAddActivity && (
              <button
                onClick={() => onAddActivity(activeClassId)}
                className="rounded-xl bg-[#2f8b3c] px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-[#236a2d]"
              >
                + Crear actividad / tarea
              </button>
            )}
            <button
              onClick={() => onAddEvaluation(activeClassId)}
              className="rounded-xl bg-[#c6292e] px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-[#9f1d24]"
            >
              + Crear evaluación
            </button>
          </div>
        </div>
      ) : (
        /* Evaluation & Activity Cards Grid */
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {/* Render Class Activities */}
          {showActivities && classActivities.map(activity => {
            const hasAttachments = activity.attachments && activity.attachments.length > 0;
            const submittedCount = classStudents.filter(s => {
              const stGrade = activity.studentGrades?.[s.id];
              return stGrade?.status === 'Entregado' || stGrade?.status === 'Calificado' || (stGrade?.attachments && stGrade.attachments.length > 0);
            }).length;
            const itemParcialId = (activity.parcial || 1) as ParcialId;
            const isActivityClosed = isPeriodClosed(effectivePeriodsConfig, itemParcialId);
            const actPeriodObj = periodsList.find(p => p.id === itemParcialId);

            return (
              <div
                key={activity.id}
                className="flex flex-col justify-between rounded-3xl border border-[#2f8b3c]/30 bg-white p-5 shadow-xs"
              >
                <div>
                  {/* Activity Card Header */}
                  <div className="flex items-start justify-between gap-3 border-b border-[#dfe6df] pb-3 mb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="flex items-center gap-1 rounded-lg bg-[#eaf6ec] px-2 py-0.5 text-[10px] font-extrabold text-[#236a2d]">
                          <CheckSquare className="h-3 w-3" />
                          Actividad / Tarea
                        </span>
                        <span className="rounded-lg bg-[#f7f8f6] border border-[#dfe6df] px-2 py-0.5 text-[10px] font-bold text-[#546057]">
                          {actPeriodObj?.name || `${itemParcialId}º Parcial`}
                        </span>
                        {isActivityClosed && (
                          <span className="flex items-center gap-0.5 rounded-lg bg-[#fde7e7] px-1.5 py-0.5 text-[10px] font-bold text-[#c6292e]">
                            <Lock className="h-2.5 w-2.5" />
                            Cerrado
                          </span>
                        )}
                        {hasAttachments && (
                          <span className="flex items-center gap-0.5 text-[10px] text-[#236a2d] font-bold" title="Tiene archivos adjuntos">
                            <Paperclip className="h-3 w-3" />
                            {activity.attachments?.length}
                          </span>
                        )}
                        <span className="rounded-lg bg-[#f7f8f6] px-2 py-0.5 text-[10px] font-semibold text-[#6d766f]">
                          Entregas: {submittedCount}/{classStudents.length}
                        </span>
                      </div>
                      <h3 className="mt-1.5 text-sm font-black text-[#26302b]">{activity.title}</h3>
                      <div className="mt-0.5 text-xs text-[#6d766f] flex items-center gap-2">
                        <span>Puntaje máx: <strong className="text-[#236a2d]">{activity.value} pts</strong></span>
                        {activity.deadline && (
                          <span>· Vence: <strong className="text-[#26302b]">{formatDate(activity.deadline)}</strong></span>
                        )}
                      </div>
                    </div>

                    {onDeleteActivity && (
                      isActivityClosed ? (
                        <span
                          className="flex items-center gap-1 rounded-lg bg-[#edf1ed] px-2 py-1 text-[10px] font-bold text-[#6d766f]"
                          title="Parcial cerrado por Coordinación. No se puede eliminar."
                        >
                          <Lock className="h-3 w-3" />
                          Protegido
                        </span>
                      ) : (
                        <button
                          onClick={() => onDeleteActivity(activity.id)}
                          className="rounded-lg p-1 text-[#c6292e] hover:bg-[#fde7e7]"
                          title="Eliminar esta actividad y sus notas"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )
                    )}
                  </div>

                  {/* Student Score Rows for Activity */}
                  <div className="divide-y divide-[#edf1ed] space-y-1">
                    {classStudents.map(student => {
                      const stGrade = activity.studentGrades?.[student.id];
                      const rawScore = activity.scores?.[student.id] ?? stGrade?.score;
                      const currentScore = rawScore !== undefined ? rawScore : '';
                      const studentAvg = calculateStudentAverage(
                        student.id,
                        activeClassId,
                        data.grades,
                        data.activities,
                        selectedParcial === 'all' ? undefined : selectedParcial
                      );
                      const hasStudentFiles = stGrade?.attachments && stGrade.attachments.length > 0;

                      return (
                        <div
                          key={student.id}
                          className="flex items-center justify-between py-2 pt-2.5 rounded-xl px-2 transition hover:bg-[#f7f8f6]"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#eef2ee] text-[10px] font-bold text-[#26302b]">
                              {getInitials(student.name)}
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <strong className="block truncate text-xs text-[#26302b]">{student.name}</strong>
                                {hasStudentFiles && (
                                  <span className="flex items-center gap-0.5 rounded bg-[#eaf6ec] px-1 py-0.2 text-[9px] font-black text-[#236a2d]" title="Alumno adjuntó archivos">
                                    <Paperclip className="h-2.5 w-2.5" />
                                    {stGrade.attachments?.length}
                                  </span>
                                )}
                              </div>
                              <span className="block text-[10px] text-[#6d766f]">
                                Promedio acumulado: <strong className="text-[#236a2d]">{studentAvg}%</strong>
                              </span>
                            </div>
                          </div>

                          {/* Interactive Score Input for Activity or Locked Display */}
                          <div className="flex items-center gap-1.5 shrink-0">
                            {isActivityClosed ? (
                              <div
                                className="flex items-center gap-1.5 rounded-xl border border-[#dfe6df] bg-[#edf1ed] px-2.5 py-1.5 text-center text-xs font-black text-[#546057]"
                                title="Parcial cerrado por Coordinación (Modo solo lectura)"
                              >
                                <Lock className="h-3 w-3 text-[#6d766f]" />
                                <span>{currentScore !== '' ? currentScore : '—'}</span>
                                <span className="text-[11px] text-[#6d766f]">/ {activity.value}</span>
                              </div>
                            ) : (
                              <>
                                <input
                                  type="number"
                                  min="0"
                                  max={activity.value}
                                  step={activity.value <= 10 ? '0.1' : '1'}
                                  value={currentScore}
                                  onChange={e => {
                                    const val = parseFloat(e.target.value);
                                    if (onUpdateActivityScore) {
                                      onUpdateActivityScore(activity.id, student.id, isNaN(val) ? 0 : val);
                                    }
                                  }}
                                  className="w-20 rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-2.5 py-1.5 text-center text-xs font-black text-[#26302b] outline-none transition focus:border-[#2f8b3c] focus:bg-white focus:ring-2 focus:ring-[#2f8b3c]/20"
                                  placeholder="0"
                                />
                                <span className="text-[11px] text-[#6d766f]">/ {activity.value}</span>
                              </>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="mt-4 rounded-xl bg-[#f4faf4] p-2.5 text-right text-[11px] text-[#236a2d] font-semibold border border-[#2f8b3c]/20 flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px]">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    Puntaje de actividad reflejado en promedio y reportes
                  </span>
                  <span>Alumnos: {classStudents.length}</span>
                </div>
              </div>
            );
          })}

          {/* Render Class Evaluations */}
          {showEvaluations && classEvaluations.map(evalItem => {
            const evalParcialId = (evalItem.parcial || 1) as ParcialId;
            const isEvaluationClosed = isPeriodClosed(effectivePeriodsConfig, evalParcialId);
            const evalPeriodObj = periodsList.find(p => p.id === evalParcialId);

            return (
              <div
                key={evalItem.id}
                className="flex flex-col justify-between rounded-3xl border border-[#dfe6df] bg-white p-5 shadow-xs"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 border-b border-[#dfe6df] pb-3 mb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="rounded-lg bg-[#eef2ee] px-2 py-0.5 text-[10px] font-extrabold text-[#465249]">
                          Evaluación Oficial
                        </span>
                        <span className="rounded-lg bg-[#f0f4f0] px-2 py-0.5 text-[10px] font-bold text-[#2f8b3c]">
                          {evalItem.type}
                        </span>
                        <span className="rounded-lg bg-[#f7f8f6] border border-[#dfe6df] px-2 py-0.5 text-[10px] font-bold text-[#546057]">
                          {evalPeriodObj?.name || `${evalParcialId}º Parcial`}
                        </span>
                        {isEvaluationClosed && (
                          <span className="flex items-center gap-0.5 rounded-lg bg-[#fde7e7] px-1.5 py-0.5 text-[10px] font-bold text-[#c6292e]">
                            <Lock className="h-2.5 w-2.5" />
                            Cerrado
                          </span>
                        )}
                      </div>
                      <h3 className="mt-1.5 text-sm font-black text-[#26302b]">{evalItem.title}</h3>
                      <div className="mt-0.5 text-xs text-[#6d766f]">
                        Ponderación: <strong>{evalItem.value}%</strong> · Escala 0–{evalItem.scale}
                      </div>
                    </div>

                    {isEvaluationClosed ? (
                      <span
                        className="flex items-center gap-1 rounded-lg bg-[#edf1ed] px-2 py-1 text-[10px] font-bold text-[#6d766f]"
                        title="Parcial cerrado por Coordinación. No se puede eliminar."
                      >
                        <Lock className="h-3 w-3" />
                        Protegido
                      </span>
                    ) : (
                      <button
                        onClick={() => onDeleteEvaluation(evalItem.id)}
                        className="rounded-lg p-1 text-[#c6292e] hover:bg-[#fde7e7]"
                        title="Eliminar esta evaluación y sus notas"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>

                  {/* Students score rows */}
                  <div className="divide-y divide-[#edf1ed] space-y-1">
                    {classStudents.map(student => {
                      const rawScore = evalItem.scores?.[student.id];
                      const currentScore = rawScore !== undefined ? rawScore : '';
                      const studentAvg = calculateStudentAverage(
                        student.id,
                        activeClassId,
                        data.grades,
                        data.activities,
                        selectedParcial === 'all' ? undefined : selectedParcial
                      );

                      return (
                        <div
                          key={student.id}
                          className="flex items-center justify-between py-2 pt-2.5 rounded-xl px-2 transition hover:bg-[#f7f8f6]"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#eef2ee] text-[10px] font-bold text-[#26302b]">
                              {getInitials(student.name)}
                            </div>
                            <div className="min-w-0">
                              <strong className="block truncate text-xs text-[#26302b]">{student.name}</strong>
                              <span className="block text-[10px] text-[#6d766f]">
                                Promedio actual: <strong className="text-[#236a2d]">{studentAvg}%</strong>
                              </span>
                            </div>
                          </div>

                          {/* Interactive score input or Locked Display */}
                          <div className="flex items-center gap-1.5 shrink-0">
                            {isEvaluationClosed ? (
                              <div
                                className="flex items-center gap-1.5 rounded-xl border border-[#dfe6df] bg-[#edf1ed] px-2.5 py-1.5 text-center text-xs font-black text-[#546057]"
                                title="Parcial cerrado por Coordinación (Modo solo lectura)"
                              >
                                <Lock className="h-3 w-3 text-[#6d766f]" />
                                <span>{currentScore !== '' ? currentScore : '—'}</span>
                                <span className="text-[11px] text-[#6d766f]">/ {evalItem.scale}</span>
                              </div>
                            ) : (
                              <>
                                <input
                                  type="number"
                                  min="0"
                                  max={evalItem.scale}
                                  step={evalItem.scale === 10 ? '0.1' : '1'}
                                  value={currentScore}
                                  onChange={e => {
                                    const val = parseFloat(e.target.value);
                                    onUpdateScore(evalItem.id, student.id, isNaN(val) ? 0 : val);
                                  }}
                                  className="w-20 rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-2.5 py-1.5 text-center text-xs font-black text-[#26302b] outline-none transition focus:border-[#2f8b3c] focus:bg-white focus:ring-2 focus:ring-[#2f8b3c]/20"
                                  placeholder="0"
                                />
                                <span className="text-[11px] text-[#6d766f]">/ {evalItem.scale}</span>
                              </>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="mt-4 rounded-xl bg-[#f7f8f6] p-2.5 text-right text-[11px] text-[#2f8b3c] font-semibold border border-[#dfe6df]/80 flex items-center justify-between">
                  <span className="flex items-center gap-1 text-[10px]">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    Se guarda automáticamente en tiempo real
                  </span>
                  <span>Alumnos en el curso: {classStudents.length}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
