import React, { useState, useRef } from 'react';
import {
  Shield,
  Plus,
  Search,
  Key,
  Edit,
  Trash2,
  ToggleLeft,
  ToggleRight,
  Download,
  Upload,
  RefreshCw,
  Users,
  Eye,
  EyeOff,
  Copy,
  Check,
  Calendar,
  Lock,
  Unlock,
  CheckCircle2,
  AlertTriangle,
  Cloud,
  FileCode
} from 'lucide-react';
import { AppData, User, PeriodsConfig, ParcialId } from '../../types';
import { INITIAL_DATA, DEFAULT_PERIODS_CONFIG } from '../../constants/initialData';
import { ResetDatabaseModal } from '../modals/ResetDatabaseModal';
import { PeriodsControlModal } from '../modals/PeriodsControlModal';
import { DownloadCodeModal } from '../modals/DownloadCodeModal';
import { testStorageConnection, getStorageBucketName } from '../../services/firebase';

interface AdminViewProps {
  data: AppData;
  currentUser: User;
  periodsConfig?: PeriodsConfig;
  onAddUser: () => void;
  onEditUser: (user: User) => void;
  onResetPassword: (user: User) => void;
  onToggleUserActive: (userId: string) => void;
  onDeleteUser: (userId: string) => void;
  onRestoreBackup: (newData: AppData) => void;
  onEmptyDatabase: () => void;
  onStartPeriod?: (parcialId: ParcialId) => void;
  onClosePeriod?: (parcialId: ParcialId) => void;
  onReopenPeriod?: (parcialId: ParcialId) => void;
}

export const AdminView: React.FC<AdminViewProps> = ({
  data,
  currentUser,
  periodsConfig,
  onAddUser,
  onEditUser,
  onResetPassword,
  onToggleUserActive,
  onDeleteUser,
  onRestoreBackup,
  onEmptyDatabase,
  onStartPeriod,
  onClosePeriod,
  onReopenPeriod
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const [showAllPasswords, setShowAllPasswords] = useState(true);
  const [revealedPasswords, setRevealedPasswords] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [resetDbModalOpen, setResetDbModalOpen] = useState(false);
  const [periodsModalOpen, setPeriodsModalOpen] = useState(false);
  const [downloadCodeModalOpen, setDownloadCodeModalOpen] = useState(false);
  const [isTestingStorage, setIsTestingStorage] = useState(false);
  const [storageTestResult, setStorageTestResult] = useState<{ success: boolean; message: string; bucket?: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const effectivePeriodsConfig = periodsConfig || data.periodsConfig || DEFAULT_PERIODS_CONFIG;
  const periodsList = effectivePeriodsConfig.periods;
  const activePeriod = periodsList.find(p => p.status === 'active') || periodsList[0];

  const adminCount = data.users.filter(u => u.role === 'admin' && u.active).length;
  const teacherCount = data.users.filter(u => u.role === 'teacher' && u.active).length;
  const studentCount = data.users.filter(u => u.role === 'student' && u.active).length;

  const cloudResourcesCount = data.resources.filter(r => r.storageUrl).length;
  const cloudBucketName = getStorageBucketName();

  const handleTestStorage = async () => {
    setIsTestingStorage(true);
    setStorageTestResult(null);
    try {
      const res = await testStorageConnection();
      setStorageTestResult(res);
    } catch (err: any) {
      setStorageTestResult({
        success: false,
        message: err?.message || 'Error al conectar con Cloud Storage'
      });
    } finally {
      setIsTestingStorage(false);
    }
  };

  const filteredUsers = data.users.filter(u => {
    const q = searchTerm.toLowerCase();
    const matchesSearch = u.name.toLowerCase().includes(q) || u.username.toLowerCase().includes(q);
    const matchesRole = !roleFilter || u.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const handleExportBackup = () => {
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `docentes-el-hogar-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImportBackupFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = evt => {
      try {
        const parsed = JSON.parse(evt.target?.result as string);
        if (parsed && Array.isArray(parsed.users) && Array.isArray(parsed.classes)) {
          if (confirm('¿Deseas restaurar esta copia de seguridad? Se sobrescribirán los datos actuales.')) {
            onRestoreBackup(parsed);
          }
        } else {
          alert('El archivo no tiene el formato válido de copia de seguridad de Docentes El Hogar.');
        }
      } catch (err) {
        alert('Error al leer el archivo JSON de copia de seguridad.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col justify-between gap-4 rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs sm:flex-row sm:items-center">
        <div>
          <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#c6292e]">
            Control de Acceso
          </span>
          <h2 className="mt-1 text-2xl font-black text-[#26302b] sm:text-3xl">Panel de administración</h2>
          <p className="mt-1 text-xs text-[#6d766f]">
            Administra usuarios docentes, estudiantes y configuraciones generales del sistema.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onAddUser}
            className="flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-[#9f1d24]"
          >
            <Plus className="h-4 w-4" />
            <span>Crear usuario</span>
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-2xl border border-[#dfe6df] bg-white p-5 shadow-xs">
          <span className="text-xs font-bold text-[#6d766f]">Administradores</span>
          <div className="mt-1 text-2xl font-black text-[#c6292e]">{adminCount}</div>
          <span className="text-[10px] text-[#6d766f]">Cuentas activas</span>
        </div>

        <div className="rounded-2xl border border-[#dfe6df] bg-white p-5 shadow-xs">
          <span className="text-xs font-bold text-[#6d766f]">Docentes</span>
          <div className="mt-1 text-2xl font-black text-[#2f8b3c]">{teacherCount}</div>
          <span className="text-[10px] text-[#6d766f]">Profesores con acceso</span>
        </div>

        <div className="rounded-2xl border border-[#dfe6df] bg-white p-5 shadow-xs">
          <span className="text-xs font-bold text-[#6d766f]">Alumnos con cuenta</span>
          <div className="mt-1 text-2xl font-black text-[#735f00]">{studentCount}</div>
          <span className="text-[10px] text-[#6d766f]">Acceso para consulta</span>
        </div>

        <div className="rounded-2xl border border-[#dfe6df] bg-white p-5 shadow-xs">
          <span className="text-xs font-bold text-[#6d766f]">Total de usuarios</span>
          <div className="mt-1 text-2xl font-black text-[#26302b]">{data.users.length}</div>
          <span className="text-[10px] text-[#6d766f]">En la base de datos</span>
        </div>
      </div>

      {/* Coordination Academic Periods Control */}
      <div className="rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center border-b border-[#dfe6df] pb-4 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#2f8b3c]">
                Dirección & Coordinación Académica
              </span>
              <span className="inline-flex items-center gap-1 rounded-full bg-[#eaf6ec] px-2.5 py-0.5 text-[11px] font-black text-[#236a2d]">
                <Calendar className="h-3 w-3" />
                4 Parciales Anuales
              </span>
            </div>
            <h3 className="mt-1 text-lg font-black text-[#26302b]">Control y Cierre de Parciales</h3>
            <p className="mt-1 text-xs text-[#6d766f]">
              Inicia o cierra los parciales del ciclo. Al cerrar un parcial, sus notas y actividades pasan a solo lectura y nadie puede modificarlos.
            </p>
          </div>

          <button
            onClick={() => setPeriodsModalOpen(true)}
            className="flex items-center gap-1.5 rounded-xl bg-[#236a2d] px-4 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-[#1b5323] transition self-start sm:self-auto"
          >
            <Lock className="h-4 w-4" />
            <span>Gestionar Parciales (Iniciar / Cerrar)</span>
          </button>
        </div>

        {/* 4 Periods Status Grid */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {periodsList.map(period => {
            const isActive = period.status === 'active';
            const isClosed = period.status === 'closed';

            return (
              <div
                key={period.id}
                className={`relative rounded-2xl border p-4 transition ${
                  isActive
                    ? 'border-[#2f8b3c] bg-[#eaf6ec]/40 ring-1 ring-[#2f8b3c]'
                    : isClosed
                    ? 'border-[#dfe6df] bg-[#f7f8f6]'
                    : 'border-[#dfe6df] bg-white opacity-80'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-[#26302b]">{period.name}</span>
                  {isActive ? (
                    <span className="flex items-center gap-1 rounded-full bg-[#2f8b3c] px-2 py-0.5 text-[10px] font-bold text-white">
                      <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulse" />
                      Activo / Abierto
                    </span>
                  ) : isClosed ? (
                    <span className="flex items-center gap-1 rounded-full bg-[#fde7e7] px-2 py-0.5 text-[10px] font-bold text-[#c6292e]">
                      <Lock className="h-2.5 w-2.5" />
                      Cerrado
                    </span>
                  ) : (
                    <span className="rounded-full bg-[#f7f8f6] border border-[#dfe6df] px-2 py-0.5 text-[10px] font-bold text-[#6d766f]">
                      Próximo
                    </span>
                  )}
                </div>

                <div className="mt-2 text-xs text-[#546057]">
                  {isActive && (
                    <p className="text-[11px] font-medium text-[#236a2d]">
                      En curso. Docentes y alumnos pueden registrar y calificar actividades.
                    </p>
                  )}
                  {isClosed && (
                    <p className="text-[11px] font-medium text-[#6d766f]">
                      Cerrado{period.closedBy ? ` por ${period.closedBy}` : ''}. Modo solo lectura protegido.
                    </p>
                  )}
                  {!isActive && !isClosed && (
                    <p className="text-[11px] font-medium text-[#6d766f]">
                      Aún no iniciado. Se activará cuando coordinación lo decida.
                    </p>
                  )}
                </div>

                {period.startDate && (
                  <div className="mt-3 flex items-center justify-between border-t border-[#dfe6df]/80 pt-2 text-[10px] text-[#6d766f]">
                    <span>Inicio: {period.startDate}</span>
                    {period.endDate && <span>Cierre: {period.endDate}</span>}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Backup & Data Preservation Toolbar */}
      <div className="rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center border-b border-[#dfe6df] pb-4 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-extrabold text-[#26302b]">Seguridad, Nube y Respaldos</h3>
              <span className="inline-flex items-center gap-1 rounded-full bg-[#eaf6ec] px-2.5 py-0.5 text-[10px] font-bold text-[#236a2d]">
                <Cloud className="h-3 w-3" />
                Firebase Conectado
              </span>
            </div>
            <p className="text-xs text-[#6d766f] mt-1">
              Todos los cambios se replican automáticamente en la nube con Firebase Firestore y se guardan también localmente para acceso offline inmediato.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setDownloadCodeModalOpen(true)}
              className="flex items-center gap-1.5 rounded-xl bg-[#2f8b3c] px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-[#236a2d] transition"
              title="Descargar código en HTML (index.html, aplicación autónoma o reporte)"
            >
              <FileCode className="h-4 w-4" />
              <span>Descargar en HTML</span>
            </button>

            <button
              onClick={handleExportBackup}
              className="flex items-center gap-1.5 rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3.5 py-2 text-xs font-bold text-[#26302b] hover:bg-[#eef2ee]"
              title="Descargar copia de seguridad en archivo JSON"
            >
              <Download className="h-4 w-4 text-[#2f8b3c]" />
              <span>Exportar copia (JSON)</span>
            </button>

            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3.5 py-2 text-xs font-bold text-[#26302b] hover:bg-[#eef2ee]"
              title="Restaurar copia desde archivo JSON"
            >
              <Upload className="h-4 w-4 text-[#735f00]" />
              <span>Restaurar copia</span>
            </button>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImportBackupFile}
              accept=".json"
              className="hidden"
            />

            <button
              onClick={() => setResetDbModalOpen(true)}
              className="flex items-center gap-1 rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-2 text-xs font-bold text-[#6d766f] hover:bg-[#fde7e7] hover:text-[#c6292e]"
              title="Vaciar todos los registros para empezar de cero"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              <span>Vaciar base de datos</span>
            </button>
          </div>
        </div>

        {/* Cloud Storage Integration Details */}
        <div className="rounded-2xl border border-[#bfe2c4] bg-[#f7fbf8] p-4 text-xs">
          <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-[#2f8b3c] text-white">
                  <Cloud className="h-3.5 w-3.5" />
                </span>
                <span className="font-black text-[#26302b]">Firebase Cloud Storage</span>
                <span className="rounded-full bg-[#2f8b3c] px-2 py-0.5 text-[9px] font-black uppercase text-white">
                  Conectado
                </span>
              </div>
              <p className="font-mono text-[11px] text-[#465249]">
                Bucket: <strong className="text-[#236a2d]">{cloudBucketName}</strong>
              </p>
              <p className="text-[11px] text-[#6d766f]">
                Archivos y materiales alojados en la nube: <strong>{cloudResourcesCount} de {data.resources.length} recursos</strong>.
                Todos los documentos adjuntos de tareas y actividades se almacenan de forma segura en Google Cloud Storage.
              </p>
            </div>

            <button
              type="button"
              onClick={handleTestStorage}
              disabled={isTestingStorage}
              className="flex shrink-0 items-center gap-1.5 rounded-xl bg-[#2f8b3c] px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-[#236a2d] disabled:opacity-60"
            >
              {isTestingStorage ? (
                <>
                  <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                  <span>Verificando...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>Probar conexión Cloud Storage</span>
                </>
              )}
            </button>
          </div>

          {storageTestResult && (
            <div
              className={`mt-3 flex items-start gap-2 rounded-xl p-3 text-xs font-medium ${
                storageTestResult.success
                  ? 'border border-[#bfe2c4] bg-[#eaf6ec] text-[#236a2d]'
                  : 'border border-[#f8b4b4] bg-[#fde7e7] text-[#c6292e]'
              }`}
            >
              {storageTestResult.success ? (
                <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5 text-[#2f8b3c]" />
              ) : (
                <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5 text-[#c6292e]" />
              )}
              <div>
                <p className="font-bold">
                  {storageTestResult.success ? 'Conexión verificada con éxito' : 'Alerta de conexión'}
                </p>
                <p className="mt-0.5 text-[11px]">{storageTestResult.message}</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Users Table Card */}
      <div className="rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-xs space-y-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3.5 top-3 h-4 w-4 text-[#6d766f]" />
            <input
              type="text"
              placeholder="Buscar por nombre o nombre de usuario..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] py-2 pl-9 pr-4 text-xs outline-none focus:border-[#2f8b3c]"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setShowAllPasswords(!showAllPasswords)}
              className="flex items-center gap-1.5 rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-2 text-xs font-bold text-[#26302b] transition hover:bg-[#eef2ee]"
              title={showAllPasswords ? 'Ocultar contraseñas' : 'Mostrar todas las contraseñas'}
            >
              {showAllPasswords ? (
                <>
                  <EyeOff className="h-3.5 w-3.5 text-[#c6292e]" />
                  <span>Ocultar claves</span>
                </>
              ) : (
                <>
                  <Eye className="h-3.5 w-3.5 text-[#2f8b3c]" />
                  <span>Ver todas las claves</span>
                </>
              )}
            </button>

            <select
              value={roleFilter}
              onChange={e => setRoleFilter(e.target.value)}
              className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3.5 py-2 text-xs font-bold text-[#435047] outline-none focus:border-[#2f8b3c]"
            >
              <option value="">Todos los perfiles</option>
              <option value="teacher">Docentes</option>
              <option value="student">Alumnos</option>
              <option value="admin">Administradores</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto rounded-2xl border border-[#dfe6df]">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-[#dfe6df] bg-[#f7f8f6] text-[11px] font-bold uppercase tracking-wider text-[#6d766f]">
                <th className="py-3 px-4">Usuario</th>
                <th className="py-3 px-4">Nombre de usuario</th>
                <th className="py-3 px-4">Contraseña</th>
                <th className="py-3 px-4">Perfil</th>
                <th className="py-3 px-4">Estado</th>
                <th className="py-3 px-4 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#dfe6df]">
              {filteredUsers.map(user => {
                const roleBadge =
                  user.role === 'admin' ? (
                    <span className="rounded-full bg-[#fde7e7] px-2.5 py-0.5 text-[10px] font-black text-[#c6292e]">
                      Administrador
                    </span>
                  ) : user.role === 'teacher' ? (
                    <span className="rounded-full bg-[#eaf6ec] px-2.5 py-0.5 text-[10px] font-black text-[#286e33]">
                      Docente
                    </span>
                  ) : (
                    <span className="rounded-full bg-[#fff7cc] px-2.5 py-0.5 text-[10px] font-black text-[#735f00]">
                      Alumno
                    </span>
                  );

                const isRevealed = showAllPasswords || !!revealedPasswords[user.id];
                const passText = user.password || '••••';

                const handleCopyCredentials = () => {
                  navigator.clipboard.writeText(`Usuario: ${user.username} | Clave: ${passText}`);
                  setCopiedId(user.id);
                  setTimeout(() => setCopiedId(null), 2000);
                };

                return (
                  <tr key={user.id} className="transition hover:bg-[#fbfcfb]">
                    <td className="py-3 px-4 font-bold text-[#26302b]">
                      {user.name}
                      {user.id === currentUser.id && (
                        <span className="ml-2 rounded bg-[#2f8b3c]/20 px-1.5 py-0.5 text-[9px] font-extrabold text-[#236a2d]">
                          Tú
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-[#26302b]">
                      @{user.username}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`rounded-lg px-2 py-0.5 font-mono text-xs font-bold ${
                            isRevealed
                              ? 'bg-[#eaf6ec] text-[#236a2d]'
                              : 'bg-[#eef2ee] text-[#6d766f]'
                          }`}
                        >
                          {isRevealed ? passText : '••••••••'}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setRevealedPasswords(prev => ({
                              ...prev,
                              [user.id]: !prev[user.id]
                            }))
                          }
                          className="rounded p-1 text-[#6d766f] hover:bg-[#eef2ee] hover:text-[#26302b]"
                          title={isRevealed ? 'Ocultar clave' : 'Ver clave'}
                        >
                          {isRevealed ? (
                            <EyeOff className="h-3.5 w-3.5" />
                          ) : (
                            <Eye className="h-3.5 w-3.5" />
                          )}
                        </button>
                        <button
                          type="button"
                          onClick={handleCopyCredentials}
                          className="rounded p-1 text-[#6d766f] hover:bg-[#eef2ee] hover:text-[#2f8b3c]"
                          title="Copiar usuario y contraseña"
                        >
                          {copiedId === user.id ? (
                            <Check className="h-3.5 w-3.5 text-[#2f8b3c]" />
                          ) : (
                            <Copy className="h-3.5 w-3.5" />
                          )}
                        </button>
                      </div>
                    </td>
                    <td className="py-3 px-4">{roleBadge}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                          user.active ? 'bg-[#eaf6ec] text-[#236a2d]' : 'bg-[#eef2ee] text-[#6d766f]'
                        }`}
                      >
                        {user.active ? 'Activo' : 'Inactivo'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onResetPassword(user)}
                          className="flex items-center gap-1 rounded-lg bg-[#eef2ee] px-2.5 py-1 text-xs font-semibold text-[#26302b] hover:bg-[#dfe6df]"
                          title="Cambiar contraseña"
                        >
                          <Key className="h-3 w-3" />
                          <span className="hidden sm:inline">Clave</span>
                        </button>
                        <button
                          onClick={() => onEditUser(user)}
                          className="rounded-lg p-1.5 text-[#5d685f] hover:bg-[#eef2ee]"
                          title="Editar usuario"
                        >
                          <Edit className="h-3.5 w-3.5" />
                        </button>
                        {user.id !== currentUser.id && (
                          <>
                            <button
                              onClick={() => onToggleUserActive(user.id)}
                              className="rounded-lg p-1.5 text-[#5d685f] hover:bg-[#eef2ee]"
                              title={user.active ? 'Desactivar acceso' : 'Activar acceso'}
                            >
                              {user.active ? (
                                <ToggleRight className="h-4 w-4 text-[#2f8b3c]" />
                              ) : (
                                <ToggleLeft className="h-4 w-4 text-[#6d766f]" />
                              )}
                            </button>
                            <button
                              onClick={() => onDeleteUser(user.id)}
                              className="rounded-lg p-1.5 text-[#c6292e] hover:bg-[#fde7e7]"
                              title={
                                user.role === 'admin'
                                  ? 'Eliminar administrador (requiere llave maestra institucional)'
                                  : 'Eliminar cuenta'
                              }
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <ResetDatabaseModal
        isOpen={resetDbModalOpen}
        onClose={() => setResetDbModalOpen(false)}
        onConfirm={() => {
          onEmptyDatabase();
          setResetDbModalOpen(false);
        }}
      />

      <PeriodsControlModal
        isOpen={periodsModalOpen}
        periodsConfig={effectivePeriodsConfig}
        data={data}
        currentUser={currentUser}
        onClose={() => setPeriodsModalOpen(false)}
        onStartPeriod={parcialId => {
          onStartPeriod?.(parcialId);
        }}
        onClosePeriod={parcialId => {
          onClosePeriod?.(parcialId);
        }}
        onReopenPeriod={parcialId => {
          onReopenPeriod?.(parcialId);
        }}
      />

      <DownloadCodeModal
        isOpen={downloadCodeModalOpen}
        onClose={() => setDownloadCodeModalOpen(false)}
        data={data}
        periodsConfig={effectivePeriodsConfig}
      />
    </div>
  );
};
