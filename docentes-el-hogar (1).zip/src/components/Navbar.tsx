import React from 'react';
import { Menu, Bell, LogOut, CheckCircle2, UserCheck, Calendar, Lock, Settings, Cloud, CloudCheck, RefreshCw, FileCode } from 'lucide-react';
import { User, ActiveSection, PeriodsConfig, ParcialId } from '../types';
import { getInitials, getActivePeriod } from '../utils/storage';

interface NavbarProps {
  currentUser: User;
  currentSection: ActiveSection;
  onOpenMobileMenu: () => void;
  onOpenNotifications: () => void;
  onLogout: () => void;
  notificationCount: number;
  periodsConfig?: PeriodsConfig;
  onOpenPeriodsControl?: () => void;
  onOpenDownloadCode?: () => void;
  isFirebaseSynced?: boolean;
  isSyncing?: boolean;
}

const SECTION_TITLES: Record<ActiveSection, string> = {
  dashboard: 'Panel principal',
  classes: 'Mis clases',
  students: 'Gestión de alumnos',
  resources: 'Biblioteca de recursos',
  planning: 'Planificación docente',
  activities: 'Actividades y tareas',
  forum: 'Foro escolar y debates',
  grades: 'Registro de calificaciones',
  attendance: 'Control de asistencia',
  reports: 'Reportes académicos',
  calendar: 'Calendario escolar',
  admin: 'Panel de administración'
};

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  currentSection,
  onOpenMobileMenu,
  onOpenNotifications,
  onLogout,
  notificationCount,
  periodsConfig,
  onOpenPeriodsControl,
  onOpenDownloadCode,
  isFirebaseSynced = true,
  isSyncing = false
}) => {
  const activePeriod = getActivePeriod(periodsConfig);
  const isPeriodOpen = activePeriod.status === 'active';

  const roleLabel =
    currentUser.role === 'admin'
      ? 'Administrador'
      : currentUser.role === 'teacher'
      ? 'Docente'
      : 'Alumno';

  const getSectionTitle = () => {
    if (currentSection === 'classes' && currentUser.role === 'admin') {
      return 'Clases de maestros';
    }
    if (currentSection === 'planning' && currentUser.role === 'admin') {
      return 'Coordinación académica';
    }
    return SECTION_TITLES[currentSection] || 'Docentes El Hogar';
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-[#dfe6df] bg-white/95 px-4 backdrop-blur md:px-7">
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobileMenu}
          className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#eef2ee] text-[#26302b] transition hover:bg-[#dfe6df] md:hidden"
          title="Abrir menú"
          aria-label="Abrir menú"
        >
          <Menu className="h-5 w-5" />
        </button>

        <div>
          <h1 className="text-base font-extrabold tracking-tight text-[#26302b] md:text-lg">
            {getSectionTitle()}
          </h1>
          <div className="hidden items-center gap-2 text-[11px] sm:flex">
            {isSyncing ? (
              <span className="flex items-center gap-1 font-medium text-[#c6292e]">
                <RefreshCw className="h-3 w-3 animate-spin" />
                <span>Sincronizando con Firebase...</span>
              </span>
            ) : isFirebaseSynced ? (
              <span className="flex items-center gap-1 font-medium text-[#2f8b3c]">
                <Cloud className="h-3 w-3" />
                <span>Firestore & Cloud Storage Conectados</span>
              </span>
            ) : (
              <span className="flex items-center gap-1 font-medium text-[#6d766f]">
                <CheckCircle2 className="h-3 w-3" />
                <span>Modo Local Offline</span>
              </span>
            )}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        {/* Academic Period Indicator & Coordination Controller */}
        {periodsConfig && (
          currentUser.role === 'admin' && onOpenPeriodsControl ? (
            <button
              onClick={onOpenPeriodsControl}
              className={`flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-bold transition shadow-xs ${
                isPeriodOpen
                  ? 'border-[#2f8b3c]/40 bg-[#eaf6ec] text-[#236a2d] hover:bg-[#d8eedb]'
                  : 'border-[#dfe6df] bg-[#f7f8f6] text-[#6d766f] hover:bg-[#edf1ed]'
              }`}
              title="Panel de Coordinación: Iniciar o Cerrar Parciales"
            >
              <span
                className={`flex h-2 w-2 rounded-full ${
                  isPeriodOpen ? 'bg-[#2f8b3c] animate-pulse' : 'bg-[#6d766f]'
                }`}
              />
              <span className="font-black text-[#26302b]">{activePeriod.name}</span>
              <span
                className={`rounded px-1.5 py-0.2 text-[9px] font-extrabold uppercase ${
                  isPeriodOpen ? 'bg-[#2f8b3c] text-white' : 'bg-[#6d766f] text-white'
                }`}
              >
                {isPeriodOpen ? 'Activo' : 'Cerrado'}
              </span>
              <Settings className="h-3.5 w-3.5 ml-0.5 text-[#236a2d]" />
            </button>
          ) : (
            <div
              className={`flex items-center gap-1.5 rounded-xl border px-2.5 py-1.5 text-xs ${
                isPeriodOpen
                  ? 'border-[#2f8b3c]/30 bg-[#eaf6ec] text-[#236a2d]'
                  : 'border-[#dfe6df] bg-[#f7f8f6] text-[#6d766f]'
              }`}
              title={`Año escolar: Actualmente en ${activePeriod.name} (${isPeriodOpen ? 'Abierto para trabajar' : 'Cerrado por Coordinación'})`}
            >
              <span
                className={`flex h-2 w-2 rounded-full ${
                  isPeriodOpen ? 'bg-[#2f8b3c] animate-pulse' : 'bg-[#6d766f]'
                }`}
              />
              <span className="hidden sm:inline text-[11px] font-bold text-[#6d766f]">Parcial:</span>
              <strong className="text-[#26302b]">{activePeriod.name}</strong>
              <span
                className={`rounded px-1.5 py-0.2 text-[9px] font-extrabold ${
                  isPeriodOpen ? 'bg-[#2f8b3c] text-white' : 'bg-[#6d766f] text-white'
                }`}
              >
                {isPeriodOpen ? 'En Curso' : 'Cerrado'}
              </span>
            </div>
          )
        )}

        {onOpenDownloadCode && (
          <button
            onClick={onOpenDownloadCode}
            className="flex h-10 items-center gap-1.5 rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 text-xs font-bold text-[#26302b] transition hover:bg-[#eef2ee] hover:text-[#2f8b3c]"
            title="Descargar código en HTML o aplicación autónoma"
            aria-label="Descargar código en HTML"
          >
            <FileCode className="h-4 w-4 text-[#2f8b3c]" />
            <span className="hidden lg:inline">Descargar HTML</span>
          </button>
        )}

        <button
          onClick={onOpenNotifications}
          className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-[#dfe6df] bg-[#f7f8f6] text-[#26302b] transition hover:bg-[#eef2ee]"
          title="Notificaciones"
          aria-label="Notificaciones"
        >
          <Bell className="h-4 w-4" />
          {notificationCount > 0 && (
            <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#c6292e] px-1 text-[10px] font-bold text-white shadow-sm">
              {notificationCount}
            </span>
          )}
        </button>

        <div className="hidden items-center gap-2 rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-2.5 py-1.5 lg:flex">
          <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#2f8b3c]/15 text-xs font-bold text-[#2f8b3c]">
            {getInitials(currentUser.name)}
          </div>
          <div className="text-left leading-tight">
            <div className="text-xs font-bold text-[#26302b]">{currentUser.name}</div>
            <div className="flex items-center gap-1 text-[10px] font-medium text-[#6d766f]">
              <UserCheck className="h-2.5 w-2.5 text-[#2f8b3c]" />
              <span>{roleLabel}</span>
            </div>
          </div>
        </div>

        <button
          onClick={onLogout}
          className="flex h-10 items-center gap-1.5 rounded-xl border border-[#fde7e7] bg-[#fde7e7]/60 px-3 text-xs font-bold text-[#c6292e] transition hover:bg-[#fde7e7] hover:text-[#9f1d24]"
          title="Cerrar sesión (Tus datos quedan guardados y nada se borrará)"
        >
          <LogOut className="h-4 w-4" />
          <span className="hidden sm:inline">Cerrar sesión</span>
        </button>
      </div>
    </header>
  );
};
