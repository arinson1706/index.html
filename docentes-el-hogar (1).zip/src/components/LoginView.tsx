import React, { useState } from 'react';
import { Lock, UserCheck, Shield, UserPlus, LogIn, Eye, EyeOff, CheckCircle2, Clock } from 'lucide-react';
import { User, UserRole } from '../types';
import { HOGAR_LOGO, ADMIN_MASTER_KEY } from '../constants/initialData';

interface LoginViewProps {
  users: User[];
  onLogin: (user: User) => void;
  onRegisterAdmin?: (name: string, username: string, pass: string) => { success: boolean; message?: string } | void;
  inactivityMessage?: string | null;
}

export const LoginView: React.FC<LoginViewProps> = ({ users, onLogin, onRegisterAdmin, inactivityMessage }) => {
  const [mode, setMode] = useState<'login' | 'register-admin'>('login');
  const [selectedRole, setSelectedRole] = useState<UserRole>('student');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  // Admin registration form state
  const [adminName, setAdminName] = useState('');
  const [adminUsername, setAdminUsername] = useState('');
  const [adminRegKey, setAdminRegKey] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminPasswordConfirm, setAdminPasswordConfirm] = useState('');
  const [showAdminPassword, setShowAdminPassword] = useState(false);

  const handleSubmitLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanUser = username.trim().toLowerCase();
    const cleanPass = password.trim();

    const matchedUser = users.find(
      u =>
        u.role === selectedRole &&
        u.active &&
        u.username.toLowerCase() === cleanUser &&
        u.password === cleanPass
    );

    if (matchedUser) {
      onLogin(matchedUser);
    } else {
      const existsWithOtherRole = users.find(
        u => u.username.toLowerCase() === cleanUser && u.password === cleanPass
      );
      if (existsWithOtherRole) {
        const roleName =
          existsWithOtherRole.role === 'admin'
            ? 'Administración'
            : existsWithOtherRole.role === 'teacher'
            ? 'Docentes'
            : 'Alumnos';
        setError(
          `Este usuario está registrado con el perfil "${roleName}". Selecciona la pestaña correspondiente arriba.`
        );
      } else {
        setError('Usuario o contraseña incorrectos.');
      }
    }
  };

  const handleRegisterAdminSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const name = adminName.trim();
    const user = adminUsername.trim().toLowerCase();
    const regKey = adminRegKey.trim().toUpperCase();
    const pass = adminPassword.trim();
    const passConfirm = adminPasswordConfirm.trim();

    if (!name || !user || !pass || !regKey) {
      setError('Por favor completa todos los campos requeridos.');
      return;
    }

    if (regKey !== ADMIN_MASTER_KEY) {
      setError('Clave de registro institucional inválida. Se requiere la llave maestra autorizada para crear cuentas de Administrador.');
      return;
    }

    if (pass.length < 3) {
      setError('La contraseña debe tener al menos 3 caracteres.');
      return;
    }

    if (pass !== passConfirm) {
      setError('Las contraseñas no coinciden.');
      return;
    }

    const duplicate = users.find(u => u.username.toLowerCase() === user);
    if (duplicate) {
      setError(`El nombre de usuario "${user}" ya está registrado.`);
      return;
    }

    if (onRegisterAdmin) {
      const res = onRegisterAdmin(name, user, pass);
      if (res && !res.success) {
        setError(res.message || 'Error al registrar administrador.');
      }
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center p-4 md:p-8 bg-[#f4f7f4]">
      <div className="w-full max-w-md overflow-hidden rounded-3xl border border-[#dfe6df] bg-white p-7 sm:p-9 shadow-xl">
        {/* Institutional Identity */}
        <div className="text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl border border-[#dfe6df] bg-white p-2 shadow-xs">
            <img src={HOGAR_LOGO} alt="Docentes El Hogar" className="h-full w-full object-contain" />
          </div>

          <h2 className="mt-3 text-xl font-black tracking-tight text-[#26302b]">
            Docentes El Hogar.
          </h2>
          <p className="text-xs font-medium text-[#6d766f]">
            Hogar de Amor y Esperanza · Sistema Académico
          </p>

          <div
            className="mx-auto mt-3 h-1.5 w-28 rounded-full"
            style={{
              background: 'linear-gradient(90deg, #c6292e 0% 46%, #f5c400 46% 58%, #2f8b3c 58% 100%)'
            }}
          />
        </div>

        {/* Mode Switcher: Iniciar Sesión / Registrar Administrador */}
        <div className="mt-6 flex rounded-2xl bg-[#eef2ee] p-1">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setSelectedRole('student');
              setError('');
            }}
            className={`flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2 text-xs font-bold transition ${
              mode === 'login'
                ? 'bg-white text-[#26302b] shadow-xs'
                : 'text-[#5d685f] hover:text-[#26302b]'
            }`}
          >
            <LogIn className="h-3.5 w-3.5 text-[#2f8b3c]" />
            <span>Iniciar Sesión</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setMode('register-admin');
              setError('');
            }}
            className={`flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2 text-xs font-bold transition ${
              mode === 'register-admin'
                ? 'bg-white text-[#c6292e] shadow-xs'
                : 'text-[#5d685f] hover:text-[#26302b]'
            }`}
          >
            <UserPlus className="h-3.5 w-3.5 text-[#c6292e]" />
            <span>Registrar Admin</span>
          </button>
        </div>

        {inactivityMessage && (
          <div className="mt-4 flex items-start gap-2.5 rounded-2xl border border-amber-300 bg-amber-50 p-3 text-xs font-semibold text-amber-900 shadow-xs">
            <Clock className="h-4 w-4 shrink-0 text-amber-600 mt-0.5" />
            <div className="flex-1">
              <span className="font-bold block text-amber-950">Protección por inactividad</span>
              <span className="text-[11px] font-medium text-amber-800 leading-relaxed block mt-0.5">
                {inactivityMessage}
              </span>
            </div>
          </div>
        )}

        {error && (
          <div className="mt-4 rounded-xl border border-[#fde7e7] bg-[#fde7e7] p-3 text-xs font-medium text-[#a92028]">
            {error}
          </div>
        )}

        {mode === 'login' ? (
          <div>
            {/* Role selector tabs */}
            <div className="mt-5">
              <label className="block text-[11px] font-extrabold uppercase tracking-wider text-[#6d766f] mb-1.5">
                Selecciona tu perfil
              </label>
              <div className="grid grid-cols-3 gap-1.5 rounded-2xl bg-[#f7f8f6] p-1 border border-[#dfe6df]">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedRole('student');
                    setError('');
                  }}
                  className={`rounded-xl py-2 text-xs font-bold transition ${
                    selectedRole === 'student'
                      ? 'bg-[#2f8b3c] text-white shadow-xs'
                      : 'text-[#5d685f] hover:text-[#26302b]'
                  }`}
                >
                  Alumnos
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedRole('teacher');
                    setError('');
                  }}
                  className={`rounded-xl py-2 text-xs font-bold transition ${
                    selectedRole === 'teacher'
                      ? 'bg-[#2f8b3c] text-white shadow-xs'
                      : 'text-[#5d685f] hover:text-[#26302b]'
                  }`}
                >
                  Docentes
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedRole('admin');
                    setError('');
                  }}
                  className={`rounded-xl py-2 text-xs font-bold transition ${
                    selectedRole === 'admin'
                      ? 'bg-[#2f8b3c] text-white shadow-xs'
                      : 'text-[#5d685f] hover:text-[#26302b]'
                  }`}
                >
                  Administración
                </button>
              </div>

              {selectedRole !== 'admin' && users.filter(u => u.role === selectedRole).length === 0 && (
                <div className="mt-2.5 rounded-xl border border-[#f5b300]/30 bg-[#fff7cc] px-3 py-2 text-[11px] text-[#735f00]">
                  <span>Aún no hay {selectedRole === 'teacher' ? 'docentes' : 'alumnos'} registrados. Accede con <strong>Administración</strong> para agregarlos.</span>
                </div>
              )}
            </div>

            {/* Credentials Form */}
            <form onSubmit={handleSubmitLogin} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-[#465249] mb-1">Nombre de usuario</label>
                <input
                  type="text"
                  required
                  placeholder={
                    selectedRole === 'student'
                      ? 'ej: tu_usuario_alumno'
                      : selectedRole === 'teacher'
                      ? 'ej: tu_usuario_docente'
                      : 'ej: tu_usuario_admin'
                  }
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3.5 py-2.5 text-xs font-bold text-[#26302b] outline-none transition focus:border-[#2f8b3c] focus:bg-white focus:ring-2 focus:ring-[#2f8b3c]/20"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-[#465249]">Contraseña</label>
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3.5 py-2.5 pr-10 text-xs font-bold text-[#26302b] outline-none transition focus:border-[#2f8b3c] focus:bg-white focus:ring-2 focus:ring-[#2f8b3c]/20"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-[#6d766f] hover:text-[#26302b]"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="mt-2 w-full rounded-xl bg-[#c6292e] py-3 text-xs font-black uppercase tracking-wider text-white shadow-md transition hover:bg-[#9f1d24] active:scale-[0.99]"
              >
                Ingresar a la plataforma
              </button>
            </form>
          </div>
        ) : (
          /* Admin Registration Form */
          <form onSubmit={handleRegisterAdminSubmit} className="mt-5 space-y-3.5">
            <div className="rounded-2xl bg-[#fde7e7]/60 p-3 text-xs text-[#a92028] border border-[#c6292e]/20">
              <div className="flex items-center gap-1.5 font-bold">
                <Shield className="h-4 w-4 text-[#c6292e]" />
                <span>Registro de nuevo Administrador</span>
              </div>
              <p className="mt-1 text-[11px] text-[#6d766f]">
                Como administrador tendrás acceso completo para dar de alta docentes, asignar grados y materias, gestionar alumnos y ver credenciales.
              </p>
            </div>

            {/* Clave de Registro Autorizada HAYE */}
            <div className="rounded-2xl border border-[#c6292e]/30 bg-[#fff5f5] p-3">
              <label className="block text-xs font-black text-[#a92028] mb-1">
                Clave de registro institucional *
              </label>
              <input
                type="password"
                required
                placeholder="Ingresa la clave única de registro"
                value={adminRegKey}
                onChange={e => setAdminRegKey(e.target.value)}
                className="w-full rounded-xl border border-[#c6292e]/30 bg-white px-3.5 py-2.5 text-xs font-mono font-bold text-[#26302b] outline-none focus:border-[#c6292e] focus:ring-2 focus:ring-[#c6292e]/20 uppercase"
              />
              <span className="mt-1 block text-[10px] text-[#6d766f]">
                Clave requerida para autorizar la creación de administradores.
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#465249] mb-1">Nombre completo *</label>
              <input
                type="text"
                required
                placeholder="Ej. Lic. Dirección Académica"
                value={adminName}
                onChange={e => setAdminName(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3.5 py-2.5 text-xs font-bold text-[#26302b] outline-none focus:border-[#2f8b3c] focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#465249] mb-1">Nombre de usuario (Login) *</label>
              <input
                type="text"
                required
                placeholder="ej: admin_titular"
                value={adminUsername}
                onChange={e => setAdminUsername(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3.5 py-2.5 text-xs font-bold text-[#26302b] outline-none focus:border-[#2f8b3c] focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#465249] mb-1">Contraseña *</label>
              <div className="relative">
                <input
                  type={showAdminPassword ? 'text' : 'password'}
                  required
                  placeholder="••••••••"
                  value={adminPassword}
                  onChange={e => setAdminPassword(e.target.value)}
                  className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3.5 py-2.5 pr-10 text-xs font-bold text-[#26302b] outline-none focus:border-[#2f8b3c] focus:bg-white"
                />
                <button
                  type="button"
                  onClick={() => setShowAdminPassword(!showAdminPassword)}
                  className="absolute right-3 top-2.5 text-[#6d766f] hover:text-[#26302b]"
                >
                  {showAdminPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#465249] mb-1">Confirmar contraseña *</label>
              <input
                type={showAdminPassword ? 'text' : 'password'}
                required
                placeholder="••••••••"
                value={adminPasswordConfirm}
                onChange={e => setAdminPasswordConfirm(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3.5 py-2.5 text-xs font-bold text-[#26302b] outline-none focus:border-[#2f8b3c] focus:bg-white"
              />
            </div>

            <button
              type="submit"
              className="mt-2 w-full rounded-xl bg-[#c6292e] py-3 text-xs font-black uppercase tracking-wider text-white shadow-md transition hover:bg-[#9f1d24] active:scale-[0.99]"
            >
              Registrar cuenta e ingresar
            </button>
          </form>
        )}

        <div className="mt-6 border-t border-[#dfe6df] pt-4 text-center text-[11px] text-[#6d766f]">
          <div className="flex items-center justify-center gap-1.5 text-[#2f8b3c] font-semibold mb-1">
            <CheckCircle2 className="h-3.5 w-3.5" />
            <span>Datos guardados de forma permanente</span>
          </div>
          Docentes El Hogar · Edición 2026
        </div>
      </div>
    </div>
  );
};
