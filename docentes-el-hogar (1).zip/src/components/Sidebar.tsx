import React from 'react';
import {
  Home,
  LayoutGrid,
  Users,
  FileText,
  PenTool,
  CheckSquare,
  BarChart3,
  Clock,
  FileSpreadsheet,
  Calendar,
  Shield,
  X,
  LogOut,
  MessagesSquare
} from 'lucide-react';
import { User, ActiveSection } from '../types';
import { HOGAR_LOGO } from '../constants/initialData';
import { getInitials } from '../utils/storage';

interface SidebarProps {
  currentUser: User;
  currentSection: ActiveSection;
  onSelectSection: (section: ActiveSection) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  onLogout: () => void;
}

interface NavItem {
  id: ActiveSection;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  roles: ('admin' | 'teacher' | 'student')[];
}

const NAV_ITEMS: NavItem[] = [
  { id: 'admin', label: 'Administración', icon: Shield, roles: ['admin'] },
  { id: 'dashboard', label: 'Panel principal', icon: Home, roles: ['admin', 'teacher', 'student'] },
  { id: 'classes', label: 'Mis clases', icon: LayoutGrid, roles: ['admin', 'teacher'] },
  { id: 'students', label: 'Alumnos', icon: Users, roles: ['admin', 'teacher'] },
  { id: 'resources', label: 'Mis recursos', icon: FileText, roles: ['admin', 'teacher', 'student'] },
  { id: 'planning', label: 'Planificación', icon: PenTool, roles: ['admin', 'teacher'] },
  { id: 'activities', label: 'Actividades', icon: CheckSquare, roles: ['admin', 'teacher', 'student'] },
  { id: 'forum', label: 'Foro escolar', icon: MessagesSquare, roles: ['admin', 'teacher', 'student'] },
  { id: 'grades', label: 'Calificaciones', icon: BarChart3, roles: ['admin', 'teacher', 'student'] },
  { id: 'attendance', label: 'Asistencia', icon: Clock, roles: ['admin', 'teacher', 'student'] },
  { id: 'reports', label: 'Reportes', icon: FileSpreadsheet, roles: ['admin', 'teacher', 'student'] },
  { id: 'calendar', label: 'Calendario', icon: Calendar, roles: ['admin', 'teacher', 'student'] }
];

export const Sidebar: React.FC<SidebarProps> = ({
  currentUser,
  currentSection,
  onSelectSection,
  isOpenMobile,
  onCloseMobile,
  onLogout
}) => {
  const allowedItems = NAV_ITEMS.filter(item => item.roles.includes(currentUser.role)).map(item => {
    if (item.id === 'classes' && currentUser.role === 'admin') {
      return { ...item, label: 'Clases de maestros' };
    }
    if (item.id === 'planning' && currentUser.role === 'admin') {
      return { ...item, label: 'Coordinación' };
    }
    return item;
  });

  const roleLabel =
    currentUser.role === 'admin'
      ? 'Administrador'
      : currentUser.role === 'teacher'
      ? 'Docente'
      : 'Alumno';

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-black/40 backdrop-blur-xs transition-opacity md:hidden"
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-72 flex-col border-r border-[#dfe6df] bg-white transition-transform duration-200 ease-in-out md:static md:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand header */}
        <div className="p-5 pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img
                src={HOGAR_LOGO}
                alt="Docentes El Hogar"
                className="h-12 w-12 rounded-xl object-contain p-1 border border-[#dfe6df] bg-white shadow-xs"
              />
              <div className="leading-tight">
                <strong className="block text-base font-extrabold text-[#26302b]">Docentes El Hogar.</strong>
                <span className="block text-[11px] font-medium text-[#6d766f]">
                  Espacio de {currentUser.name.split(' ')[0]}
                </span>
              </div>
            </div>

            <button
              onClick={onCloseMobile}
              className="flex h-8 w-8 items-center justify-center rounded-lg text-[#6d766f] hover:bg-[#eef2ee] md:hidden"
              title="Cerrar menú"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Signature tricolor line: Red, Yellow, Green */}
          <div
            className="mt-3.5 h-1.5 w-full rounded-full"
            style={{
              background: 'linear-gradient(90deg, #c6292e 0% 46%, #f5c400 46% 58%, #2f8b3c 58% 100%)'
            }}
          />
        </div>

        {/* Navigation list */}
        <nav className="flex-1 space-y-1 overflow-y-auto px-3.5 py-3">
          {allowedItems.map(item => {
            const Icon = item.icon;
            const isActive = currentSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectSection(item.id);
                  onCloseMobile();
                }}
                className={`group flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-xs font-bold transition ${
                  isActive
                    ? 'bg-[#eaf6ec] text-[#236a2d] shadow-xs'
                    : 'text-[#5d685f] hover:bg-[#f1f5f1] hover:text-[#26302b]'
                }`}
              >
                <Icon
                  className={`h-4 w-4 transition-transform group-hover:scale-110 ${
                    isActive ? 'text-[#236a2d]' : 'text-[#6d766f]'
                  }`}
                />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* User profile footer */}
        <div className="border-t border-[#dfe6df] p-3.5">
          <div className="flex items-center justify-between rounded-xl bg-[#f7f8f6] p-2.5 border border-[#dfe6df]/80">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#2f8b3c]/20 text-xs font-bold text-[#236a2d]">
                {getInitials(currentUser.name)}
              </div>
              <div className="min-w-0">
                <div className="truncate text-xs font-extrabold text-[#26302b]">{currentUser.name}</div>
                <div className="truncate text-[10px] text-[#6d766f]">{roleLabel}</div>
              </div>
            </div>

            <button
              onClick={onLogout}
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-[#c6292e] transition hover:bg-[#fde7e7]"
              title="Cerrar sesión (Sin borrar datos)"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
