import React, { useState, useEffect } from 'react';
import { Search, X, LayoutGrid, Users, FileText, PenTool, CheckSquare, Calendar, ArrowRight } from 'lucide-react';
import { AppData, ActiveSection } from '../../types';

interface GlobalSearchModalProps {
  data: AppData;
  onClose: () => void;
  onNavigate: (section: ActiveSection) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({ data, onClose, onNavigate }) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  const q = query.trim().toLowerCase();

  const results: {
    id: string;
    category: string;
    title: string;
    subtitle: string;
    icon: React.ComponentType<{ className?: string }>;
    section: ActiveSection;
  }[] = [];

  if (q) {
    // Classes
    data.classes
      .filter(c => c.name.toLowerCase().includes(q) || c.subject.toLowerCase().includes(q))
      .slice(0, 4)
      .forEach(c => {
        results.push({
          id: c.id,
          category: 'Clase',
          title: c.name,
          subtitle: `${c.subject} · Grado ${c.grade}`,
          icon: LayoutGrid,
          section: 'classes'
        });
      });

    // Students
    data.students
      .filter(s => s.name.toLowerCase().includes(q) || s.code.toLowerCase().includes(q))
      .slice(0, 4)
      .forEach(s => {
        results.push({
          id: s.id,
          category: 'Alumno',
          title: s.name,
          subtitle: `Código: ${s.code || 'S/C'} · ${s.grade || ''}`,
          icon: Users,
          section: 'students'
        });
      });

    // Resources
    data.resources
      .filter(r => r.name.toLowerCase().includes(q) || (r.topic || '').toLowerCase().includes(q))
      .slice(0, 4)
      .forEach(r => {
        results.push({
          id: r.id,
          category: 'Recurso',
          title: r.name,
          subtitle: `${r.type} · ${r.subject || 'Material'}`,
          icon: FileText,
          section: 'resources'
        });
      });

    // Plans
    data.plans
      .filter(p => p.title.toLowerCase().includes(q) || (p.topic || '').toLowerCase().includes(q))
      .slice(0, 4)
      .forEach(p => {
        results.push({
          id: p.id,
          category: 'Planificación',
          title: p.title,
          subtitle: `${p.subject} · ${p.grade}`,
          icon: PenTool,
          section: 'planning'
        });
      });

    // Activities
    data.activities
      .filter(a => a.title.toLowerCase().includes(q) || (a.description || '').toLowerCase().includes(q))
      .slice(0, 4)
      .forEach(a => {
        results.push({
          id: a.id,
          category: 'Actividad',
          title: a.title,
          subtitle: `Valor: ${a.value} pts · ${a.status}`,
          icon: CheckSquare,
          section: 'activities'
        });
      });

    // Calendar
    data.events
      .filter(e => e.title.toLowerCase().includes(q))
      .slice(0, 3)
      .forEach(e => {
        results.push({
          id: e.id,
          category: 'Evento',
          title: e.title,
          subtitle: `${e.type} · ${e.date}`,
          icon: Calendar,
          section: 'calendar'
        });
      });
  }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/50 p-4 pt-16 backdrop-blur-xs">
      <div className="relative flex max-h-[85vh] w-full max-w-2xl flex-col rounded-3xl border border-[#dfe6df] bg-white shadow-2xl overflow-hidden">
        {/* Search Input Bar */}
        <div className="flex items-center gap-3 border-b border-[#dfe6df] px-5 py-4">
          <Search className="h-5 w-5 text-[#6d766f]" />
          <input
            type="text"
            autoFocus
            placeholder="Buscar clases, alumnos, recursos, planificaciones, notas..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="flex-1 text-sm font-semibold text-[#26302b] outline-none placeholder:text-[#6d766f]"
          />
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-[#6d766f] hover:bg-[#eef2ee]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Results Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {!q ? (
            <div className="p-10 text-center text-xs text-[#6d766f]">
              <Search className="mx-auto h-10 w-10 text-[#cad4cb] mb-2" />
              <strong className="block text-sm font-bold text-[#26302b]">Búsqueda global</strong>
              <span>Escribe cualquier palabra clave para localizar información rápidamente.</span>
            </div>
          ) : results.length === 0 ? (
            <div className="p-10 text-center text-xs text-[#6d766f]">
              <span className="block text-sm font-bold text-[#26302b]">Sin resultados</span>
              <span>No encontramos coincidencias para "{query}".</span>
            </div>
          ) : (
            results.map(item => {
              const Icon = item.icon;
              return (
                <button
                  key={`${item.category}-${item.id}`}
                  onClick={() => {
                    onNavigate(item.section);
                    onClose();
                  }}
                  className="flex w-full items-center justify-between rounded-2xl p-3 text-left transition hover:bg-[#f1f5f1]"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#eef2ee] text-[#26302b]">
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-extrabold uppercase text-[#2f8b3c]">
                          {item.category}
                        </span>
                      </div>
                      <strong className="block truncate text-xs font-bold text-[#26302b]">{item.title}</strong>
                      <span className="block truncate text-[11px] text-[#6d766f]">{item.subtitle}</span>
                    </div>
                  </div>
                  <ArrowRight className="h-4 w-4 text-[#6d766f]" />
                </button>
              );
            })
          )}
        </div>

        {/* Modal Footer */}
        <div className="border-t border-[#dfe6df] bg-[#f7f8f6] px-5 py-2.5 text-right text-[11px] text-[#6d766f]">
          Presiona <kbd className="rounded bg-white px-1.5 py-0.5 border border-[#dfe6df]">Esc</kbd> para cerrar
        </div>
      </div>
    </div>
  );
};
