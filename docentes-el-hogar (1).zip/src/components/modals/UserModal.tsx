import React, { useState, useEffect } from 'react';
import { X, Shield, Eye, EyeOff, Key } from 'lucide-react';
import { User } from '../../types';

interface UserModalProps {
  isOpen: boolean;
  user?: User | null;
  onClose: () => void;
  onSave: (userData: Omit<User, 'id'> & { id?: string }) => void;
}

export const UserModal: React.FC<UserModalProps> = ({ isOpen, user, onClose, onSave }) => {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(true);
  const [role, setRole] = useState<User['role']>('teacher');
  const [active, setActive] = useState(true);

  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setUsername(user.username || '');
      setPassword(user.password || '');
      setRole(user.role || 'teacher');
      setActive(user.active !== false);
    } else {
      setName('');
      setUsername('');
      setPassword('');
      setRole('teacher');
      setActive(true);
    }
  }, [user, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !username.trim()) return;

    onSave({
      id: user ? user.id : undefined,
      name: name.trim(),
      username: username.trim().toLowerCase(),
      password: password.trim() || user?.password || '',
      role,
      active
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-md rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#dfe6df] pb-4 mb-5">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-[#c6292e]" />
            <h3 className="text-base font-black text-[#26302b]">
              {user ? 'Editar usuario' : 'Crear nuevo usuario'}
            </h3>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-[#6d766f] hover:bg-[#eef2ee]">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-[#26302b] mb-1">Nombre completo *</label>
            <input
              type="text"
              required
              placeholder="Ej: Lic. Carlos Mendoza"
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-bold text-[#26302b] mb-1">Nombre de usuario (Login) *</label>
            <input
              type="text"
              required
              placeholder="cmendoza"
              value={username}
              onChange={e => setUsername(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-bold text-[#26302b] mb-1">
              Contraseña {user ? '(visible para administración)' : '*'}
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                placeholder="Contraseña"
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 pr-10 outline-none focus:border-[#2f8b3c] focus:bg-white font-mono"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-[#6d766f] hover:text-[#26302b]"
                title={showPassword ? 'Ocultar contraseña' : 'Ver contraseña'}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            <span className="mt-1 block text-[10px] text-[#6d766f]">
              Los administradores pueden ver y reasignar las contraseñas en cualquier momento.
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-[#26302b] mb-1">Rol / Perfil</label>
              <select
                value={role}
                onChange={e => setRole(e.target.value as User['role'])}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              >
                <option value="teacher">Docente</option>
                <option value="student">Alumno</option>
                <option value="admin">Administrador</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-[#26302b] mb-1">Estado de cuenta</label>
              <select
                value={active ? 'true' : 'false'}
                onChange={e => setActive(e.target.value === 'true')}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              >
                <option value="true">Activa</option>
                <option value="false">Desactivada</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#dfe6df]">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2 font-bold text-[#6d766f] hover:bg-[#eef2ee]"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2 font-bold text-white shadow-sm hover:bg-[#9f1d24]"
            >
              <Key className="h-4 w-4" />
              <span>{user ? 'Guardar cambios' : 'Crear usuario'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
