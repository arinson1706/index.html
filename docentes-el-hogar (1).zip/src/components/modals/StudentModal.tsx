import React, { useState, useEffect } from 'react';
import { X, Users, BookOpen, Sparkles, CheckCircle2, Info, GraduationCap } from 'lucide-react';
import { Student, ClassRoom, User } from '../../types';
import { isStudentInClass, matchGrade } from '../../utils/storage';
import { STANDARD_GRADES } from '../../constants/initialData';

interface StudentModalProps {
  isOpen: boolean;
  student?: Student | null;
  classes: ClassRoom[];
  defaultClassId?: string;
  defaultGrade?: string;
  currentUser?: User | null;
  onClose: () => void;
  onSave: (studentData: Omit<Student, 'id'> & { id?: string }) => void;
}

export const StudentModal: React.FC<StudentModalProps> = ({
  isOpen,
  student,
  classes,
  defaultClassId = '',
  defaultGrade = '',
  currentUser,
  onClose,
  onSave
}) => {
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [grade, setGrade] = useState('7mo');
  const [customGrade, setCustomGrade] = useState('');
  const [isCustomGrade, setIsCustomGrade] = useState(false);
  const [section, setSection] = useState('A');
  const [birth, setBirth] = useState('');
  const [guardianName, setGuardianName] = useState('');
  const [guardianPhone, setGuardianPhone] = useState('');
  const [contact, setContact] = useState('');
  const [status, setStatus] = useState<Student['status']>('Activo');
  const [notes, setNotes] = useState('');

  // Collect teacher's assigned grades and classes
  const isTeacher = currentUser?.role === 'teacher';
  const teacherClasses = isTeacher ? classes.filter(c => c.teacherId === currentUser.id) : [];
  const teacherGrades = Array.from(new Set(teacherClasses.map(c => c.grade).filter(Boolean)));

  // Collect distinct grades existing in classes that might not be in standard list
  const existingGradesInClasses = Array.from(
    new Set(classes.map(c => c.grade).filter(Boolean))
  );

  useEffect(() => {
    if (student) {
      setName(student.name || '');
      setCode(student.code || '');

      const stGrade = student.grade || '7mo';
      const isKnown = STANDARD_GRADES.some(g => g.value.toLowerCase() === stGrade.toLowerCase()) ||
        existingGradesInClasses.some(g => g.toLowerCase() === stGrade.toLowerCase());

      if (isKnown) {
        setGrade(stGrade);
        setIsCustomGrade(false);
        setCustomGrade('');
      } else {
        setGrade('custom');
        setIsCustomGrade(true);
        setCustomGrade(stGrade);
      }

      setSection(student.section || 'A');
      setBirth(student.birth || '');
      setGuardianName(student.guardianName || '');
      setGuardianPhone(student.guardianPhone || student.contact || '');
      setContact(student.contact || '');
      setStatus(student.status || 'Activo');
      setNotes(student.notes || '');
    } else {
      setName('');
      setCode(`AL-${Math.floor(1000 + Math.random() * 9000)}`);

      // Determine initial grade & section from defaultGrade, defaultClassId, or teacher's assigned grade
      const initialClass = classes.find(c => c.id === defaultClassId);
      const initialGrade = defaultGrade || initialClass?.grade || (teacherGrades.length > 0 ? teacherGrades[0] : (classes[0]?.grade || '7mo'));
      
      const isKnown = STANDARD_GRADES.some(g => g.value.toLowerCase() === initialGrade.toLowerCase()) ||
        existingGradesInClasses.some(g => g.toLowerCase() === initialGrade.toLowerCase());

      if (isKnown) {
        setGrade(initialGrade);
        setIsCustomGrade(false);
        setCustomGrade('');
      } else if (initialGrade) {
        setGrade('custom');
        setIsCustomGrade(true);
        setCustomGrade(initialGrade);
      } else {
        setGrade('7mo');
        setIsCustomGrade(false);
        setCustomGrade('');
      }

      setSection(initialClass?.section || 'A');
      setBirth('');
      setGuardianName('');
      setGuardianPhone('');
      setContact('');
      setStatus('Activo');
      setNotes('');
    }
  }, [student, defaultClassId, defaultGrade, classes, isOpen]);

  if (!isOpen) return null;

  const activeGradeValue = isCustomGrade ? customGrade.trim() : grade;

  // Matching classes for the selected grade (all classes assigned to this grade)
  const matchingClasses = classes.filter(c => matchGrade(activeGradeValue, c.grade));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const finalGrade = activeGradeValue || '7mo';
    const finalSection = section.trim() || 'A';

    // Auto-resolve all enrolledClassIds: all classes assigned to this grade
    const matching = classes.filter(c => matchGrade(finalGrade, c.grade));
    const enrolledClassIds = matching.map(c => c.id);
    const primaryClassId = matching[0]?.id || student?.classId || classes[0]?.id || '';

    onSave({
      id: student ? student.id : undefined,
      name: name.trim(),
      code: code.trim(),
      classId: primaryClassId,
      enrolledClassIds,
      grade: finalGrade,
      section: finalSection,
      birth,
      guardianName: guardianName.trim(),
      guardianPhone: guardianPhone.trim(),
      contact: guardianPhone.trim() || contact.trim(),
      status,
      notes: notes.trim()
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
      <div className="relative max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#dfe6df] pb-4 mb-5">
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5 text-[#c6292e]" />
            <div>
              <h3 className="text-base font-black text-[#26302b]">
                {student ? 'Editar alumno' : 'Nuevo alumno'}
              </h3>
              <p className="text-[11px] font-semibold text-[#2f8b3c]">
                Asignación automática a todas las clases del grado
              </p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-[#6d766f] hover:bg-[#eef2ee]">
            <X className="h-4 w-4" />
          </button>
        </div>

        {isTeacher && (
          <div className="mb-4 flex items-center gap-2 rounded-2xl bg-[#eaf6ec] p-3 text-xs font-semibold text-[#236a2d] border border-[#2f8b3c]/20">
            <GraduationCap className="h-4 w-4 shrink-0 text-[#2f8b3c]" />
            <span>
              Registrando como docente: el alumno se matriculará en tus asignaturas y formará parte de tus listas de calificaciones.
            </span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-[#26302b] mb-1">Nombre completo del alumno *</label>
            <input
              type="text"
              required
              placeholder="Nombre y apellidos del estudiante"
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] focus:bg-white font-medium text-[#26302b]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-[#26302b] mb-1">Código / Carnet</label>
              <input
                type="text"
                placeholder="AL-0000"
                value={code}
                onChange={e => setCode(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] focus:bg-white font-mono text-[#26302b]"
              />
            </div>

            <div>
              <label className="block font-bold text-[#26302b] mb-1">Estado</label>
              <select
                value={status}
                onChange={e => setStatus(e.target.value as Student['status'])}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] font-bold text-[#26302b]"
              >
                <option value="Activo">Activo</option>
                <option value="Inactivo">Inactivo</option>
                <option value="Suspendido">Suspendido</option>
              </select>
            </div>
          </div>

          {/* Grado y Sección */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-[#26302b] mb-1 flex items-center justify-between">
                <span>Grado escolar *</span>
                {isCustomGrade && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsCustomGrade(false);
                      setGrade('7mo');
                    }}
                    className="text-[10px] text-[#2f8b3c] hover:underline"
                  >
                    Ver lista
                  </button>
                )}
              </label>

              {!isCustomGrade ? (
                <select
                  value={grade}
                  onChange={e => {
                    if (e.target.value === 'custom') {
                      setIsCustomGrade(true);
                      setCustomGrade('');
                    } else {
                      setGrade(e.target.value);
                    }
                  }}
                  className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] font-bold text-[#26302b]"
                >
                  {isTeacher && teacherGrades.length > 0 && (
                    <optgroup label="⭐ Tus Grados Asignados (Recomendado)">
                      {teacherGrades.map(tg => {
                        const std = STANDARD_GRADES.find(g => g.value.toLowerCase() === tg.toLowerCase());
                        return (
                          <option key={tg} value={tg}>
                            {std ? std.label : tg} (Tu grado)
                          </option>
                        );
                      })}
                    </optgroup>
                  )}
                  <optgroup label="Todos los Grados Oficiales">
                    {STANDARD_GRADES.map(g => (
                      <option key={g.value} value={g.value}>
                        {g.label}
                      </option>
                    ))}
                  </optgroup>
                  {existingGradesInClasses.filter(
                    eg => !STANDARD_GRADES.some(sg => sg.value.toLowerCase() === eg.toLowerCase())
                  ).length > 0 && (
                    <optgroup label="Otros grados en el sistema">
                      {existingGradesInClasses
                        .filter(eg => !STANDARD_GRADES.some(sg => sg.value.toLowerCase() === eg.toLowerCase()))
                        .map(eg => (
                          <option key={eg} value={eg}>
                            {eg}
                          </option>
                        ))}
                    </optgroup>
                  )}
                  <option value="custom">+ Escribir otro grado...</option>
                </select>
              ) : (
                <input
                  type="text"
                  required
                  placeholder="Ej: 7mo, 8vo, Bachillerato..."
                  value={customGrade}
                  onChange={e => setCustomGrade(e.target.value)}
                  className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] focus:bg-white font-bold text-[#26302b]"
                />
              )}
            </div>

            <div>
              <label className="block font-bold text-[#26302b] mb-1">Sección *</label>
              <input
                type="text"
                required
                placeholder="A, B, C, Única..."
                value={section}
                onChange={e => setSection(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] focus:bg-white font-bold text-[#26302b]"
              />
            </div>
          </div>

          {/* Automatic Class Enrollment Banner */}
          <div className="rounded-2xl border border-[#dfe6df] bg-[#f7f8f6] p-3.5 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 font-bold text-[#26302b] text-[11px] uppercase tracking-wider">
                <Sparkles className="h-3.5 w-3.5 text-[#2f8b3c]" />
                <span className="text-[#236a2d]">Inscripción automática por grado</span>
              </div>
              <span className="rounded-full bg-[#eaf6ec] px-2.5 py-0.5 text-[10px] font-black text-[#236a2d]">
                {matchingClasses.length} {matchingClasses.length === 1 ? 'materia vinculada' : 'materias vinculadas'}
              </span>
            </div>

            {matchingClasses.length > 0 ? (
              <div>
                <p className="text-[11px] text-[#546057] mb-2 leading-relaxed">
                  Este alumno se inscribirá automáticamente a <strong>todas las clases asignadas al grado {activeGradeValue}</strong>:
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {matchingClasses.map(c => (
                    <span
                      key={c.id}
                      className="inline-flex items-center gap-1 rounded-xl bg-white px-2.5 py-1 text-[11px] font-bold text-[#26302b] border border-[#dfe6df] shadow-2xs"
                    >
                      <BookOpen className="h-3 w-3 text-[#2f8b3c]" />
                      <span>{c.name}</span>
                    </span>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex items-start gap-2 text-[11px] text-[#6d766f]">
                <Info className="h-4 w-4 shrink-0 text-[#2f8b3c] mt-0.5" />
                <span>
                  No hay clases creadas aún para <strong>{activeGradeValue}</strong>. Al guardar al alumno quedará registrado en el grado, y en cuanto crees cualquier clase para este grado, se inscribirá a ellas de manera automática.
                </span>
              </div>
            )}
          </div>

          <div>
            <label className="block font-bold text-[#26302b] mb-1">Fecha de nacimiento</label>
            <input
              type="date"
              value={birth}
              onChange={e => setBirth(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] text-[#26302b]"
            />
          </div>

          {/* Información del Encargado / Tutor */}
          <div className="rounded-2xl border border-[#dfe6df] bg-[#f7f8f6] p-3.5 space-y-3">
            <div className="font-bold text-[11px] uppercase tracking-wider text-[#c6292e]">
              Información del Encargado / Tutor
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="block font-bold text-[#26302b] mb-1">Nombre del encargado *</label>
                <input
                  type="text"
                  placeholder="Nombre del padre, madre o tutor"
                  value={guardianName}
                  onChange={e => setGuardianName(e.target.value)}
                  className="w-full rounded-xl border border-[#dfe6df] bg-white p-2.5 outline-none focus:border-[#2f8b3c] text-[#26302b]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#26302b] mb-1">Teléfono / contacto del encargado *</label>
                <input
                  type="text"
                  placeholder="Teléfono o celular del tutor"
                  value={guardianPhone}
                  onChange={e => setGuardianPhone(e.target.value)}
                  className="w-full rounded-xl border border-[#dfe6df] bg-white p-2.5 outline-none focus:border-[#2f8b3c] text-[#26302b]"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block font-bold text-[#26302b] mb-1">Observaciones o notas</label>
            <textarea
              rows={2}
              placeholder="Anotaciones médicas, pedagógicas o de conducta..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] text-[#26302b]"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#dfe6df]">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2 font-bold text-[#6d766f] hover:bg-[#eef2ee] transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2 font-bold text-white shadow-sm hover:bg-[#9f1d24] transition active:scale-[0.98]"
            >
              <CheckCircle2 className="h-4 w-4" />
              <span>{student ? 'Guardar cambios' : 'Registrar alumno'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
