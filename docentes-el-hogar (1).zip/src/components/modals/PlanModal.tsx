import React, { useState, useEffect } from 'react';
import { X, Calendar, BookOpen, Layers, CheckCircle2, Sparkles, FileText } from 'lucide-react';
import { LessonPlan, ClassRoom } from '../../types';
import { getTodayDateString } from '../../utils/storage';

interface PlanModalProps {
  isOpen: boolean;
  plan?: LessonPlan | null;
  classes?: ClassRoom[];
  onClose: () => void;
  onSave: (planData: Omit<LessonPlan, 'id'> & { id?: string }) => void;
}

export const PlanModal: React.FC<PlanModalProps> = ({
  isOpen,
  plan,
  classes = [],
  onClose,
  onSave
}) => {
  // Selectors
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [date, setDate] = useState<string>(getTodayDateString());

  // Formato oficial de la Escuela Hogar de Amor y Esperanza
  const [subject, setSubject] = useState<string>(''); // Espacio Curricular
  const [topic, setTopic] = useState<string>(''); // Tema
  const [level, setLevel] = useState<string>('Educación Básica'); // Nivel
  const [grade, setGrade] = useState<string>(''); // Grado
  const [title, setTitle] = useState<string>('');

  const [expectations, setExpectations] = useState<string>(''); // Expectativas de Logro
  const [standard, setStandard] = useState<string>(''); // Estándar

  const [conceptualContent, setConceptualContent] = useState<string>(''); // 1. Contenido Conceptual
  const [attitudinalContent, setAttitudinalContent] = useState<string>(''); // 2. Contenido Actitudinal

  const [methodology, setMethodology] = useState<string>(''); // 2. Metodología
  const [teachingStrategies, setTeachingStrategies] = useState<string>(''); // 3. Estrategias de Enseñanza
  const [resources, setResources] = useState<string>(''); // 4. Recursos

  const [knowledgeReactivation, setKnowledgeReactivation] = useState<string>(''); // 5. Reactivación de los conocimientos
  const [knowledgeApplication, setKnowledgeApplication] = useState<string>(''); // 6. Aplicación de los Conocimientos
  const [knowledgeOrganization, setKnowledgeOrganization] = useState<string>(''); // 7. Organización del Conocimiento

  const [evaluationStrategies, setEvaluationStrategies] = useState<string>(''); // 8. Estrategias de Evaluación
  const [template, setTemplate] = useState<boolean>(false);

  // Helper to determine educational level from grade
  const deduceLevel = (gradeStr: string) => {
    const g = gradeStr.toLowerCase();
    if (g.includes('kinder') || g.includes('prebásica') || g.includes('preparatoria')) {
      return 'Educación Prebásica';
    }
    if (g.includes('1') || g.includes('2') || g.includes('3') || g.includes('4') || g.includes('5') || g.includes('6') || g.includes('primaria')) {
      return 'Educación Básica (I y II Ciclo)';
    }
    if (g.includes('7') || g.includes('8') || g.includes('9') || g.includes('tercer ciclo')) {
      return 'Educación Básica (III Ciclo)';
    }
    if (g.includes('10') || g.includes('11') || g.includes('12') || g.includes('media') || g.includes('diversificado')) {
      return 'Educación Media';
    }
    return 'Educación Básica';
  };

  useEffect(() => {
    if (plan) {
      setSelectedClassId(plan.classId || '');
      setDate(plan.date || getTodayDateString());
      setSubject(plan.subject || '');
      setTopic(plan.topic || '');
      setLevel(plan.level || deduceLevel(plan.grade || ''));
      setGrade(plan.grade || '');
      setTitle(plan.title || '');

      setExpectations(plan.expectations || plan.objective || '');
      setStandard(plan.standard || plan.competency || '');

      setConceptualContent(plan.conceptualContent || plan.content || '');
      setAttitudinalContent(plan.attitudinalContent || '');

      setMethodology(plan.methodology || plan.strategies || 'Activa, participativa y constructivista');
      setTeachingStrategies(plan.teachingStrategies || plan.activities || '');
      setResources(plan.resources || '- Cuaderno de trabajo\n- Pizarra y marcadores\n- Libros de texto');

      setKnowledgeReactivation(plan.knowledgeReactivation || '');
      setKnowledgeApplication(plan.knowledgeApplication || '');
      setKnowledgeOrganization(plan.knowledgeOrganization || '');

      setEvaluationStrategies(plan.evaluationStrategies || plan.evaluation || '');
      setTemplate(plan.template || false);
    } else {
      // Default new plan
      const defaultClass = classes.length > 0 ? classes[0] : null;
      if (defaultClass) {
        setSelectedClassId(defaultClass.id);
        setSubject(defaultClass.subject || '');
        setGrade(defaultClass.grade || '');
        setLevel(deduceLevel(defaultClass.grade || ''));
      } else {
        setSelectedClassId('');
        setSubject('Matemáticas');
        setGrade('7mo');
        setLevel('Educación Básica (III Ciclo)');
      }

      setDate(getTodayDateString());
      setTopic('');
      setTitle('');
      setExpectations('');
      setStandard('');
      setConceptualContent('');
      setAttitudinalContent('');
      setMethodology('Metodología activa y reflexiva');
      setTeachingStrategies('');
      setResources('- Cuaderno de tareas\n- Libro de texto escolar\n- Pizarra interactiva / digital');
      setKnowledgeReactivation('');
      setKnowledgeApplication('');
      setKnowledgeOrganization('');
      setEvaluationStrategies('');
      setTemplate(false);
    }
  }, [plan, isOpen, classes]);

  if (!isOpen) return null;

  // Handler for class selection change
  const handleClassChange = (classId: string) => {
    setSelectedClassId(classId);
    const found = classes.find(c => c.id === classId);
    if (found) {
      setSubject(found.subject || subject);
      setGrade(found.grade || grade);
      setLevel(deduceLevel(found.grade || grade));
    }
  };

  const handleFillExample = () => {
    setTopic('Operaciones con Números Enteros y Resolución de Problemas');
    setExpectations('Resuelven operaciones combinadas de adición y sustracción con números enteros en situaciones cotidianas.');
    setStandard('Utilizan los números enteros para resolver problemas prácticos del entorno institucional y social.');
    setConceptualContent('1. Concepto y valor absoluto de números enteros.\n2. Reglas de adición y sustracción de signos iguales y diferentes.');
    setAttitudinalContent('1. Valoración del razonamiento lógico en la toma de decisiones.\n2. Colaboración respetuosa y perseverancia en el trabajo grupal.');
    setMethodology('Aprendizaje basado en problemas (ABP) y diálogo guiado.');
    setTeachingStrategies('Explicación modelada paso a paso, ejercicios grupales en pizarra y análisis de casos prácticos.');
    setResources('- Cuaderno de trabajo y guía de ejercicios\n- Recta numérica gráfica\n- Fichas pedagógicas');
    setKnowledgeReactivation('Lluvia de ideas guiada sobre temperaturas sobre/bajo cero y saldos monetarios.');
    setKnowledgeApplication('Resolución de problemas en parejas y socialización de procedimientos en plenaria.');
    setKnowledgeOrganization('Elaboración de un mapa conceptual sobre la recta numérica y resumen de la ley de los signos.');
    setEvaluationStrategies('Revisión formativa del cuaderno, lista de cotejo de participación activa y rúbrica de resolución.');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const planTitle = title.trim() || `${topic.trim() || 'Plan de Clase'} - ${subject.trim()} (${grade.trim() || 'General'})`;

    onSave({
      id: plan ? plan.id : undefined,
      title: planTitle,
      classId: selectedClassId || undefined,
      date: date || getTodayDateString(),
      subject: subject.trim(),
      topic: topic.trim(),
      level: level.trim(),
      grade: grade.trim(),
      year: plan?.year || new Date().getFullYear().toString(),
      expectations: expectations.trim(),
      standard: standard.trim(),
      conceptualContent: conceptualContent.trim(),
      attitudinalContent: attitudinalContent.trim(),
      methodology: methodology.trim(),
      teachingStrategies: teachingStrategies.trim(),
      resources: resources.trim(),
      knowledgeReactivation: knowledgeReactivation.trim(),
      knowledgeApplication: knowledgeApplication.trim(),
      knowledgeOrganization: knowledgeOrganization.trim(),
      evaluationStrategies: evaluationStrategies.trim(),
      // Legacy compatibility fields
      competency: standard.trim(),
      objective: expectations.trim(),
      content: conceptualContent.trim(),
      activities: teachingStrategies.trim(),
      strategies: methodology.trim(),
      evaluation: evaluationStrategies.trim(),
      template
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-2 sm:p-4 backdrop-blur-xs overflow-y-auto">
      <div className="relative my-6 max-h-[94vh] w-full max-w-5xl flex flex-col rounded-3xl border border-[#dfe6df] bg-white shadow-2xl overflow-hidden">
        
        {/* Top Header Bar */}
        <div className="flex items-center justify-between border-b border-[#dfe6df] bg-[#f8faf8] px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#c6292e] text-white shadow-xs">
              <FileText className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-[#26302b]">
                {plan ? 'Editar Planificación de Clases' : 'Nueva Planificación de Clases'}
              </h3>
              <p className="text-xs font-semibold text-[#2f8b3c]">
                Formato Oficial · Escuela Hogar de Amor y Esperanza
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleFillExample}
              className="hidden sm:flex items-center gap-1.5 rounded-xl border border-[#dfe6df] bg-white px-3 py-1.5 text-xs font-bold text-[#2f8b3c] hover:bg-[#eaf6ec] transition"
              title="Completar con contenido pedagógico de ejemplo"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>Ejemplo didáctico</span>
            </button>
            <button
              onClick={onClose}
              className="rounded-xl p-1.5 text-[#6d766f] hover:bg-[#eef2ee] transition"
              title="Cerrar ventana"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Modal Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 text-xs">
          
          {/* Quick Selectors Bar: Clase & Fecha (as requested by user) */}
          <div className="rounded-2xl border-2 border-[#2f8b3c]/30 bg-[#f4faf5] p-4 shadow-xs">
            <div className="flex items-center gap-2 mb-3">
              <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-[#2f8b3c] text-white text-[11px] font-black">
                ✓
              </span>
              <h4 className="text-xs font-extrabold uppercase tracking-wide text-[#236a2d]">
                1. Selección de Clase y Fecha de Planificación
              </h4>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3">
              {/* Selector de Clase */}
              <div className="sm:col-span-2">
                <label className="block font-black text-[#26302b] mb-1.5 flex items-center gap-1.5">
                  <BookOpen className="h-3.5 w-3.5 text-[#2f8b3c]" />
                  <span>Clase que está planificando *</span>
                </label>
                <select
                  value={selectedClassId}
                  onChange={e => handleClassChange(e.target.value)}
                  className="w-full rounded-xl border border-[#cad4cb] bg-white p-2.5 text-xs font-bold text-[#26302b] outline-none shadow-xs focus:border-[#2f8b3c] focus:ring-1 focus:ring-[#2f8b3c]"
                >
                  <option value="">-- Seleccionar clase asignada o personalizada --</option>
                  {classes.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} · {c.grade} {c.section ? `"${c.section}"` : ''} · {c.subject}
                    </option>
                  ))}
                </select>
                <p className="mt-1 text-[11px] text-[#6d766f]">
                  Al elegir la clase se completan automáticamente el Espacio Curricular, Grado y Nivel.
                </p>
              </div>

              {/* Selector de Fecha */}
              <div>
                <label className="block font-black text-[#26302b] mb-1.5 flex items-center gap-1.5">
                  <Calendar className="h-3.5 w-3.5 text-[#c6292e]" />
                  <span>Fecha de la clase *</span>
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  className="w-full rounded-xl border border-[#cad4cb] bg-white p-2.5 text-xs font-bold text-[#26302b] outline-none shadow-xs focus:border-[#2f8b3c] focus:ring-1 focus:ring-[#2f8b3c]"
                />
              </div>
            </div>
          </div>

          {/* Official Document Sheet Form (Exact format from user image) */}
          <div className="rounded-2xl border-2 border-black bg-white shadow-md p-3 sm:p-5 overflow-x-auto">
            
            {/* Header Titles matching Image */}
            <div className="text-center py-2 mb-3">
              <h2 className="text-sm sm:text-base font-black tracking-wider text-[#006680] uppercase">
                ESCUELA HOGAR DE AMOR Y ESPERANZA
              </h2>
              <h1 className="text-base sm:text-lg font-black tracking-tight text-black underline underline-offset-4 uppercase mt-0.5">
                PLANIFICACIÓN DE CLASES
              </h1>
            </div>

            {/* Official Table Grid */}
            <div className="border border-black divide-y divide-black text-black">
              
              {/* Row 1: Espacio Curricular | Tema | Nivel | Grado | Fecha */}
              <div className="grid grid-cols-1 sm:grid-cols-12 divide-y sm:divide-y-0 sm:divide-x divide-black bg-white">
                <div className="sm:col-span-1 flex items-center justify-center p-2 bg-[#fafafa]">
                  <span className="text-[10px] font-bold text-[#6d766f]">#</span>
                </div>
                <div className="sm:col-span-3 p-2">
                  <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                    Espacio Curricular
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ej: Matemáticas, Ciencias..."
                    value={subject}
                    onChange={e => setSubject(e.target.value)}
                    className="w-full rounded border border-gray-300 p-1.5 text-xs outline-none focus:border-black font-semibold"
                  />
                </div>
                <div className="sm:col-span-3 p-2">
                  <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                    Tema
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ej: Suma de fracciones, La célula..."
                    value={topic}
                    onChange={e => setTopic(e.target.value)}
                    className="w-full rounded border border-gray-300 p-1.5 text-xs outline-none focus:border-black font-semibold"
                  />
                </div>
                <div className="sm:col-span-2 p-2">
                  <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                    Nivel
                  </label>
                  <input
                    type="text"
                    placeholder="Ej: Básica"
                    value={level}
                    onChange={e => setLevel(e.target.value)}
                    className="w-full rounded border border-gray-300 p-1.5 text-xs outline-none focus:border-black font-semibold"
                  />
                </div>
                <div className="sm:col-span-1 p-2">
                  <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                    Grado
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="7mo"
                    value={grade}
                    onChange={e => setGrade(e.target.value)}
                    className="w-full rounded border border-gray-300 p-1.5 text-xs outline-none focus:border-black font-semibold"
                  />
                </div>
                <div className="sm:col-span-2 p-2">
                  <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                    Fecha
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full rounded border border-gray-300 p-1.5 text-xs outline-none focus:border-black font-semibold"
                  />
                </div>
              </div>

              {/* Row 2: Expectativas de Logro | Estándar */}
              <div className="grid grid-cols-1 sm:grid-cols-12 divide-y sm:divide-y-0 sm:divide-x divide-black">
                <div className="sm:col-span-5 p-2.5">
                  <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                    Expectativas de Logro
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Expectativas de logro que se alcanzarán en la sesión..."
                    value={expectations}
                    onChange={e => setExpectations(e.target.value)}
                    className="w-full rounded border border-gray-300 p-2 text-xs outline-none focus:border-black leading-relaxed"
                  />
                </div>
                <div className="sm:col-span-7 p-2.5">
                  <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                    Estándar
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Estándar educativo nacional o curricular correspondiente..."
                    value={standard}
                    onChange={e => setStandard(e.target.value)}
                    className="w-full rounded border border-gray-300 p-2 text-xs outline-none focus:border-black leading-relaxed"
                  />
                </div>
              </div>

              {/* Row 3: 1. Contenido Conceptual | 2. Contenido Actitudinal */}
              <div className="p-2.5 space-y-3">
                <div>
                  <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                    1. Contenido Conceptual
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Definiciones, hechos, datos, conceptos y principios de aprendizaje..."
                    value={conceptualContent}
                    onChange={e => setConceptualContent(e.target.value)}
                    className="w-full rounded border border-gray-300 p-2 text-xs outline-none focus:border-black leading-relaxed"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                    2. Contenido Actitudinal
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Valores, normas, actitudes y hábitos a fomentar..."
                    value={attitudinalContent}
                    onChange={e => setAttitudinalContent(e.target.value)}
                    className="w-full rounded border border-gray-300 p-2 text-xs outline-none focus:border-black leading-relaxed"
                  />
                </div>
              </div>

              {/* Row 4: 2. Metodología | 3. Estrategias de Enseñanza | 4. Recursos */}
              <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-black">
                <div className="p-2.5">
                  <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                    2. Metodología
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Metodología activa, participativa, deductiva..."
                    value={methodology}
                    onChange={e => setMethodology(e.target.value)}
                    className="w-full rounded border border-gray-300 p-2 text-xs outline-none focus:border-black leading-relaxed"
                  />
                </div>
                <div className="p-2.5">
                  <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                    3. Estrategias de Enseñanza
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Estrategias y acciones docentes para facilitar el aprendizaje..."
                    value={teachingStrategies}
                    onChange={e => setTeachingStrategies(e.target.value)}
                    className="w-full rounded border border-gray-300 p-2 text-xs outline-none focus:border-black leading-relaxed"
                  />
                </div>
                <div className="p-2.5">
                  <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                    4. Recursos
                  </label>
                  <textarea
                    rows={4}
                    placeholder="- Pizarra y marcadores&#10;- Cuaderno de trabajo&#10;- Material impreso"
                    value={resources}
                    onChange={e => setResources(e.target.value)}
                    className="w-full rounded border border-gray-300 p-2 text-xs outline-none focus:border-black leading-relaxed"
                  />
                </div>
              </div>

              {/* Row 5: 5. Reactivación de los conocimientos | 6. Aplicación de los Conocimientos | 7. Organización del Conocimiento */}
              <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-black">
                <div className="p-2.5">
                  <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                    5. Reactivación de los conocimientos
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Preguntas exploratorias, dinámicas de inicio, saberes previos..."
                    value={knowledgeReactivation}
                    onChange={e => setKnowledgeReactivation(e.target.value)}
                    className="w-full rounded border border-gray-300 p-2 text-xs outline-none focus:border-black leading-relaxed"
                  />
                </div>
                <div className="p-2.5">
                  <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                    6. Aplicación de los Conocimientos
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Práctica guiada, ejercicios prácticos, actividades grupales..."
                    value={knowledgeApplication}
                    onChange={e => setKnowledgeApplication(e.target.value)}
                    className="w-full rounded border border-gray-300 p-2 text-xs outline-none focus:border-black leading-relaxed"
                  />
                </div>
                <div className="p-2.5">
                  <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                    7. Organización del Conocimiento
                  </label>
                  <textarea
                    rows={4}
                    placeholder="- Síntesis en cuaderno&#10;- Esquema o mapa mental&#10;- Conclusiones conjuntas"
                    value={knowledgeOrganization}
                    onChange={e => setKnowledgeOrganization(e.target.value)}
                    className="w-full rounded border border-gray-300 p-2 text-xs outline-none focus:border-black leading-relaxed"
                  />
                </div>
              </div>

              {/* Row 6: 8. Estrategias de Evaluación */}
              <div className="p-2.5">
                <label className="block text-[11px] font-bold text-[#b30000] mb-1">
                  8. Estrategias de Evaluación
                </label>
                <textarea
                  rows={3}
                  placeholder="Criterios e instrumentos de evaluación (formativa, diagnóstica, sumativa, rúbricas, listas de cotejo)..."
                  value={evaluationStrategies}
                  onChange={e => setEvaluationStrategies(e.target.value)}
                  className="w-full rounded border border-gray-300 p-2 text-xs outline-none focus:border-black leading-relaxed"
                />
              </div>

            </div>
          </div>

          {/* Plantilla option */}
          <div className="flex items-center justify-between rounded-xl border border-[#dfe6df] bg-[#f8faf8] p-3">
            <div>
              <span className="font-bold text-[#26302b] block">Guardar como Plantilla Reutilizable</span>
              <span className="text-[11px] text-[#6d766f]">
                Permitirá clonar rápidamente esta estructura didáctica para otras sesiones.
              </span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={template}
                onChange={e => setTemplate(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#2f8b3c]"></div>
            </label>
          </div>

          {/* Footer Buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#dfe6df]">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-[#dfe6df] bg-white px-4 py-2.5 text-xs font-bold text-[#5d685f] hover:bg-[#f7f8f6] transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 rounded-xl bg-[#c6292e] px-6 py-2.5 text-xs font-black text-white shadow-md hover:bg-[#9f1d24] transition"
            >
              <CheckCircle2 className="h-4 w-4" />
              <span>{plan ? 'Guardar Cambios' : 'Crear Planificación'}</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
