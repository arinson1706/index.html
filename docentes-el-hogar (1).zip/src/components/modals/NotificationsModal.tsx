import React from 'react';
import { Bell, X, CheckSquare, Calendar, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { AppData, ActiveSection } from '../../types';

interface NotificationsModalProps {
  data: AppData;
  onClose: () => void;
  onNavigate: (section: ActiveSection) => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({ data, onClose, onNavigate }) => {
  const pendingActivities = data.activities.filter(a => a.status === 'Pendiente');
  const upcomingEvents = data.events.slice(0, 3);

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/50 p-4 pt-16 backdrop-blur-xs">
      <div className="relative flex max-h-[85vh] w-full max-w-lg flex-col rounded-3xl border border-[#dfe6df] bg-white shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#dfe6df] px-6 py-4">
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-[#c6292e]" />
            <h3 className="text-base font-black text-[#26302b]">Notificaciones y avisos</h3>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-[#6d766f] hover:bg-[#eef2ee]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {/* Pending tasks alert */}
          <div className="rounded-2xl border border-[#dfe6df] bg-[#f7f8f6] p-4">
            <div className="flex items-start gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-[#c6292e]/10 text-[#c6292e]">
                <AlertTriangle className="h-4 w-4" />
              </div>
              <div className="flex-1">
                <strong className="block text-xs font-bold text-[#26302b]">
                  {pendingActivities.length} actividades pendientes de calificación
                </strong>
                <p className="mt-0.5 text-[11px] text-[#6d766f]">
                  Hay actividades escolares que aún no han sido calificadas o entregadas.
                </p>
                <button
                  onClick={() => {
                    onNavigate('activities');
                    onClose();
                  }}
                  className="mt-2 text-xs font-bold text-[#c6292e] hover:underline"
                >
                  Ver actividades →
                </button>
              </div>
            </div>
          </div>

          {/* Calendar reminders */}
          <div className="rounded-2xl border border-[#dfe6df] bg-white p-4">
            <strong className="block text-xs font-bold text-[#26302b] mb-2">Próximos eventos en agenda</strong>
            {upcomingEvents.length === 0 ? (
              <p className="text-xs text-[#6d766f]">No hay eventos programados para los próximos días.</p>
            ) : (
              <div className="space-y-2">
                {upcomingEvents.map(e => (
                  <div key={e.id} className="flex items-center justify-between rounded-xl bg-[#f7f8f6] p-2.5 text-xs">
                    <div>
                      <strong className="block text-xs text-[#26302b]">{e.title}</strong>
                      <span className="text-[10px] text-[#6d766f]">
                        {e.type} · Fecha: {e.date}
                      </span>
                    </div>
                    <button
                      onClick={() => {
                        onNavigate('calendar');
                        onClose();
                      }}
                      className="rounded-lg bg-[#eaf6ec] px-2.5 py-1 text-[11px] font-bold text-[#236a2d] hover:bg-[#2f8b3c] hover:text-white"
                    >
                      Ver
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* System storage alert */}
          <div className="rounded-2xl border border-[#2f8b3c]/20 bg-[#eaf6ec]/50 p-4">
            <div className="flex items-center gap-2 text-xs font-bold text-[#236a2d]">
              <CheckCircle2 className="h-4 w-4" />
              <span>Persistencia local activada</span>
            </div>
            <p className="mt-1 text-[11px] text-[#546057]">
              Todos tus cambios se sincronizan en tu navegador. Puedes cerrar sesión y volver a entrar sin perder datos.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-[#dfe6df] bg-[#f7f8f6] px-6 py-3 text-right">
          <button
            onClick={onClose}
            className="rounded-xl bg-[#26302b] px-4 py-2 text-xs font-bold text-white hover:bg-black"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
