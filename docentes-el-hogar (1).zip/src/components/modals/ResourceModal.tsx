import React, { useState, useEffect } from 'react';
import { X, FileText, Upload, Star, Cloud, Loader2 } from 'lucide-react';
import { ClassRoom, Resource, User } from '../../types';
import { getTodayDateString, saveFileBlob } from '../../utils/storage';
import { uploadFileToStorage } from '../../services/firebase';

interface ResourceModalProps {
  isOpen: boolean;
  resource?: Resource | null;
  classes: ClassRoom[];
  currentUser?: User | null;
  onClose: () => void;
  onSave: (resData: Omit<Resource, 'id'> & { id?: string; storageUrl?: string; storagePath?: string }, fileBlob?: Blob) => void | Promise<void>;
}

export const ResourceModal: React.FC<ResourceModalProps> = ({
  isOpen,
  resource,
  classes,
  currentUser,
  onClose,
  onSave
}) => {
  const isAdmin = currentUser?.role === 'admin';
  const defaultClass = isAdmin ? 'admin' : (classes[0]?.id || 'admin');

  const [name, setName] = useState('');
  const [type, setType] = useState('PDF');
  const [classId, setClassId] = useState(defaultClass);
  const [grade, setGrade] = useState('Todos');
  const [subject, setSubject] = useState('');
  const [topic, setTopic] = useState('');
  const [unit, setUnit] = useState('');
  const [size, setSize] = useState(1024 * 500); // 500 KB default
  const [favorite, setFavorite] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadPercent, setUploadPercent] = useState<number>(0);

  useEffect(() => {
    if (resource) {
      setName(resource.name || '');
      setType(resource.type || 'PDF');
      setClassId(resource.classId || defaultClass);
      setGrade(resource.grade || 'Todos');
      setSubject(resource.subject || '');
      setTopic(resource.topic || '');
      setUnit(resource.unit || '');
      setSize(resource.size || 1024 * 500);
      setFavorite(resource.favorite || false);
      setSelectedFile(null);
      setIsUploading(false);
      setUploadPercent(0);
    } else {
      setName('');
      setType('PDF');
      setClassId(defaultClass);
      setGrade('Todos');
      setSubject(isAdmin ? 'Institucional / Dirección' : 'Matemáticas');
      setTopic('');
      setUnit('General');
      setSize(1024 * 350);
      setFavorite(false);
      setSelectedFile(null);
      setIsUploading(false);
      setUploadPercent(0);
    }
  }, [resource, classes, isOpen, isAdmin, defaultClass]);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    setName(file.name);
    setSize(file.size);

    const ext = file.name.split('.').pop()?.toUpperCase();
    if (ext === 'PDF') setType('PDF');
    else if (['DOC', 'DOCX'].includes(ext || '')) setType('DOCX');
    else if (['XLS', 'XLSX', 'CSV'].includes(ext || '')) setType('XLSX');
    else if (['PPT', 'PPTX'].includes(ext || '')) setType('PPTX');
    else if (['JPG', 'JPEG', 'PNG', 'WEBP', 'SVG'].includes(ext || '')) setType('Imagen');
    else if (['MP4', 'WEBM', 'MKV'].includes(ext || '')) setType('Video');
    else setType('Otro');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const selectedClass = classes.find(c => c.id === classId);
    const finalGrade = classId === 'admin' ? grade : (selectedClass?.grade || grade || 'General');

    const isUploaderAdmin = currentUser?.role === 'admin' || isAdmin;
    const finalRole: 'admin' | 'teacher' = isUploaderAdmin ? 'admin' : (resource?.uploadedByRole || 'teacher');
    const finalUploaderName = isUploaderAdmin ? 'Administración' : (currentUser?.name || resource?.uploadedByName || 'Docente');

    let storageUrl = resource?.storageUrl;
    let storagePath = resource?.storagePath;

    // If new file is selected, upload to Firebase Cloud Storage with progress
    if (selectedFile) {
      setIsUploading(true);
      setUploadPercent(0);
      const resId = resource?.id || `res-${Date.now()}`;
      const cleanName = selectedFile.name.replace(/[^a-zA-Z0-9._-]/g, '_');
      const targetPath = `resources/${resId}/${cleanName}`;

      try {
        const uploadResult = await uploadFileToStorage(selectedFile, targetPath, (pct) => {
          setUploadPercent(pct);
        });
        storageUrl = uploadResult.downloadUrl;
        storagePath = uploadResult.storagePath;
      } catch (err) {
        console.warn('Could not upload to Firebase Cloud Storage, continuing with local storage:', err);
      } finally {
        setIsUploading(false);
      }
    }

    await onSave(
      {
        id: resource ? resource.id : undefined,
        name: name.trim(),
        type,
        size,
        classId: isUploaderAdmin && (!classId || classId === '') ? 'admin' : classId,
        grade: finalGrade,
        subject: subject.trim(),
        topic: topic.trim(),
        unit: unit.trim(),
        favorite,
        date: resource?.date || getTodayDateString(),
        uploadedByRole: finalRole,
        uploadedByName: finalUploaderName,
        storageUrl,
        storagePath
      },
      selectedFile || undefined
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
      <div className="relative max-h-[90vh] w-full max-w-md overflow-y-auto rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#dfe6df] pb-4 mb-5">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-[#c6292e]" />
            <h3 className="text-base font-black text-[#26302b]">
              {resource ? 'Editar recurso' : (isAdmin ? 'Subir recurso institucional (Administración)' : 'Subir recurso docente')}
            </h3>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-[#6d766f] hover:bg-[#eef2ee]">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-[#26302b] mb-1">Seleccionar archivo</label>
            <input
              type="file"
              onChange={handleFileChange}
              disabled={isUploading}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2 file:mr-3 file:rounded-lg file:border-0 file:bg-[#2f8b3c] file:px-3 file:py-1 file:text-xs file:font-bold file:text-white hover:file:bg-[#236a2d] disabled:opacity-60"
            />
            {selectedFile && (
              <div className="mt-2 flex items-center justify-between rounded-xl bg-[#eaf6ec] p-2 text-[11px] text-[#236a2d]">
                <span className="flex items-center gap-1.5 font-bold">
                  <Cloud className="h-3.5 w-3.5" />
                  <span>Se subirá a Firebase Cloud Storage</span>
                </span>
                <span className="font-semibold">{(selectedFile.size / 1024).toFixed(1)} KB</span>
              </div>
            )}
            {!selectedFile && resource?.storageUrl && (
              <div className="mt-2 flex items-center gap-1.5 rounded-xl bg-[#eaf6ec] p-2 text-[11px] font-bold text-[#236a2d]">
                <Cloud className="h-3.5 w-3.5" />
                <span>Archivo alojado en Firebase Cloud Storage</span>
              </div>
            )}
            {isUploading && (
              <div className="mt-2 space-y-1">
                <div className="flex items-center justify-between text-[11px] font-bold text-[#236a2d]">
                  <span className="flex items-center gap-1">
                    <Loader2 className="h-3 w-3 animate-spin" />
                    Subiendo a Firebase Cloud Storage...
                  </span>
                  <span>{uploadPercent}%</span>
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-[#dfe6df]">
                  <div
                    className="h-full bg-[#2f8b3c] transition-all duration-200"
                    style={{ width: `${uploadPercent}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          <div>
            <label className="block font-bold text-[#26302b] mb-1">Nombre o título del material *</label>
            <input
              type="text"
              required
              placeholder="Ej: Guía de Fracciones y Decimales.pdf"
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] focus:bg-white"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-[#26302b] mb-1">Tipo de formato</label>
              <select
                value={type}
                onChange={e => setType(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              >
                <option value="PDF">PDF</option>
                <option value="DOCX">DOCX</option>
                <option value="PPTX">PPTX</option>
                <option value="XLSX">XLSX</option>
                <option value="Imagen">Imagen</option>
                <option value="Video">Video</option>
                <option value="Otro">Otro</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-[#26302b] mb-1">Ámbito / Asignar</label>
              <select
                value={classId}
                onChange={e => setClassId(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] font-bold text-[#26302b]"
              >
                <option value="admin">🏢 Institucional (Administración)</option>
                {classes.map(c => (
                  <option key={c.id} value={c.id}>
                    Clase: {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-[#26302b] mb-1">Grado destinatario</label>
              <select
                value={grade}
                onChange={e => setGrade(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              >
                <option value="Todos">Todos los grados</option>
                <option value="1ro">1ro Primaria</option>
                <option value="2do">2do Primaria</option>
                <option value="3ro">3ro Primaria</option>
                <option value="4to">4to Primaria</option>
                <option value="5to">5to Primaria</option>
                <option value="6to">6to Primaria</option>
                <option value="7mo">7mo Básica</option>
                <option value="8vo">8vo Básica</option>
                <option value="9no">9no Básica</option>
                <option value="10mo">10mo Básica</option>
                <option value="11mo">11mo Diversificado</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-[#26302b] mb-1">Materia</label>
              <input
                type="text"
                placeholder="Matemáticas"
                value={subject}
                onChange={e => setSubject(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-[#26302b] mb-1">Unidad</label>
              <input
                type="text"
                placeholder="Unidad 1"
                value={unit}
                onChange={e => setUnit(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-[#26302b] mb-1">Tema específico</label>
            <input
              type="text"
              placeholder="Ej: Operaciones con números racionales"
              value={topic}
              onChange={e => setTopic(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
            />
          </div>

          <div className="flex items-center gap-2 pt-2">
            <input
              type="checkbox"
              id="favCheck"
              checked={favorite}
              onChange={e => setFavorite(e.target.checked)}
              className="h-4 w-4 rounded accent-[#2f8b3c]"
            />
            <label htmlFor="favCheck" className="font-bold text-[#26302b] cursor-pointer">
              Marcar como favorito para acceso rápido
            </label>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#dfe6df]">
            <button
              type="button"
              onClick={onClose}
              disabled={isUploading}
              className="rounded-xl px-4 py-2 font-bold text-[#6d766f] hover:bg-[#eef2ee] disabled:opacity-50"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isUploading}
              className="flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2 font-bold text-white shadow-sm hover:bg-[#9f1d24] disabled:opacity-60"
            >
              {isUploading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Subiendo a la nube...</span>
                </>
              ) : (
                <span>{resource ? 'Guardar cambios' : 'Subir recurso'}</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
