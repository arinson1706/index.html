import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  CheckSquare,
  Paperclip,
  Upload,
  FileText,
  FileSpreadsheet,
  Image,
  Video,
  File,
  Trash2,
  Download,
  Loader2,
  Lock,
  CheckCircle2,
  Cloud
} from 'lucide-react';
import { Activity, ClassRoom, AttachedFile, PeriodsConfig, ParcialId } from '../../types';
import { getTodayDateString, formatFileSize, getActivePeriod, isPeriodClosed } from '../../utils/storage';
import { processUploadFile, downloadAttachedFile } from '../../utils/fileHelpers';

interface ActivityModalProps {
  isOpen: boolean;
  activity?: Activity | null;
  classes: ClassRoom[];
  periodsConfig?: PeriodsConfig;
  defaultParcial?: ParcialId;
  onClose: () => void;
  onSave: (actData: Omit<Activity, 'id'> & { id?: string }) => void;
}

export const ActivityModal: React.FC<ActivityModalProps> = ({
  isOpen,
  activity,
  classes,
  periodsConfig,
  defaultParcial,
  onClose,
  onSave
}) => {
  const activePeriod = getActivePeriod(periodsConfig);
  const targetParcial = activity?.parcial || defaultParcial || periodsConfig?.activeParcial || activePeriod.id || 1;
  const isClosed = isPeriodClosed(periodsConfig, targetParcial);
  const periodObj = periodsConfig?.periods?.find(p => p.id === targetParcial) || activePeriod;

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [classId, setClassId] = useState(classes[0]?.id || '');
  const [deadline, setDeadline] = useState(getTodayDateString());
  const [value, setValue] = useState(10);
  const [status, setStatus] = useState<Activity['status']>('Pendiente');
  const [attachments, setAttachments] = useState<AttachedFile[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessingFiles, setIsProcessingFiles] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (activity) {
      setTitle(activity.title || '');
      setDescription(activity.description || '');
      setClassId(activity.classId || classes[0]?.id || '');
      setDeadline(activity.deadline || getTodayDateString());
      setValue(activity.value || 10);
      setStatus(activity.status || 'Pendiente');
      setAttachments(activity.attachments || []);
    } else {
      setTitle('');
      setDescription('');
      setClassId(classes[0]?.id || '');
      setDeadline(getTodayDateString());
      setValue(10);
      setStatus('Pendiente');
      setAttachments([]);
    }
  }, [activity, classes, isOpen]);

  if (!isOpen) return null;

  // Process uploaded files
  const handleUploadFiles = async (files: FileList | File[]) => {
    if (!files || files.length === 0) return;
    setIsProcessingFiles(true);

    try {
      const fileArray = Array.from(files);
      const newAttachments: AttachedFile[] = [];

      for (const file of fileArray) {
        const attached = await processUploadFile(file, 'activities');
        newAttachments.push(attached);
      }

      setAttachments(prev => [...prev, ...newAttachments]);
    } catch (err) {
      console.error('Error processing files:', err);
    } finally {
      setIsProcessingFiles(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      await handleUploadFiles(e.dataTransfer.files);
    }
  };

  const handleRemoveAttachment = (attId: string) => {
    setAttachments(prev => prev.filter(a => a.id !== attId));
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'PDF':
        return <FileText className="h-4 w-4 text-[#c6292e]" />;
      case 'XLSX':
        return <FileSpreadsheet className="h-4 w-4 text-[#2f8b3c]" />;
      case 'DOCX':
        return <FileText className="h-4 w-4 text-[#1a5fb4]" />;
      case 'Imagen':
        return <Image className="h-4 w-4 text-[#e66100]" />;
      case 'Video':
        return <Video className="h-4 w-4 text-[#9141ac]" />;
      default:
        return <File className="h-4 w-4 text-[#5d685f]" />;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || isClosed) return;

    onSave({
      id: activity ? activity.id : undefined,
      title: title.trim(),
      description: description.trim(),
      classId,
      date: activity?.date || getTodayDateString(),
      deadline,
      value: Number(value) || 10,
      status,
      parcial: targetParcial,
      scores: activity?.scores,
      studentGrades: activity?.studentGrades,
      attachments
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-4 backdrop-blur-xs overflow-y-auto">
      <div className="relative my-6 max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#dfe6df] pb-4 mb-5">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#c6292e]/10 text-[#c6292e]">
              <CheckSquare className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-[#26302b]">
                {activity ? 'Editar actividad o tarea' : 'Nueva actividad o tarea escolar'}
              </h3>
              <p className="text-[11px] text-[#6d766f]">
                Asigna tareas a tus clases y adjunta materiales, guías o rúbricas
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl p-1.5 text-[#6d766f] hover:bg-[#eef2ee] transition"
            title="Cerrar"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Parcial Indicator Banner */}
          <div
            className={`rounded-2xl border p-3 flex items-center justify-between ${
              isClosed
                ? 'border-[#c6292e]/30 bg-[#fde7e7] text-[#c6292e]'
                : 'border-[#2f8b3c]/30 bg-[#eaf6ec] text-[#236a2d]'
            }`}
          >
            <div className="flex items-center gap-2">
              {isClosed ? <Lock className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4" />}
              <div>
                <span className="text-[10px] font-bold block uppercase tracking-wider">
                  Asignación por Parcial
                </span>
                <strong className="text-xs font-black">
                  {periodObj.name} ({isClosed ? 'Cerrado por Coordinación' : 'Activo'})
                </strong>
              </div>
            </div>
            <span
              className={`rounded-lg px-2 py-0.5 text-[10px] font-extrabold ${
                isClosed ? 'bg-[#c6292e] text-white' : 'bg-[#2f8b3c] text-white'
              }`}
            >
              {isClosed ? 'Solo lectura' : 'Período en curso'}
            </span>
          </div>

          {isClosed && (
            <p className="text-[11px] text-[#c6292e] font-semibold">
              ⚠️ Este parcial está cerrado por Coordinación. No se puede crear ni modificar contenido en un período cerrado.
            </p>
          )}
          <div>
            <label className="block font-bold text-[#26302b] mb-1">
              Título de la actividad o tarea *
            </label>
            <input
              type="text"
              required
              placeholder="Ej: Guía Práctica #3: Fracciones y Decimales"
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none transition focus:border-[#2f8b3c] focus:bg-white"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-[#26302b] mb-1">Clase asignada</label>
              <select
                value={classId}
                onChange={e => setClassId(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              >
                {classes.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.name} {c.grade ? `(${c.grade})` : ''}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-[#26302b] mb-1">Ponderación / Valor (pts)</label>
              <input
                type="number"
                min="1"
                max="100"
                value={value}
                onChange={e => setValue(Number(e.target.value))}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-[#26302b] mb-1">Fecha límite de entrega</label>
              <input
                type="date"
                value={deadline}
                onChange={e => setDeadline(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              />
            </div>

            <div>
              <label className="block font-bold text-[#26302b] mb-1">Estado</label>
              <select
                value={status}
                onChange={e => setStatus(e.target.value as Activity['status'])}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              >
                <option value="Pendiente">Pendiente</option>
                <option value="Entregada">Entregada</option>
                <option value="Calificada">Calificada</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-bold text-[#26302b] mb-1">
              Instrucciones o descripción
            </label>
            <textarea
              rows={3}
              placeholder="Instrucciones para los alumnos, criterios de evaluación, páginas de libro..."
              value={description}
              onChange={e => setDescription(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] focus:bg-white leading-relaxed"
            />
          </div>

          {/* Section: Archivos y Materiales Adjuntos */}
          <div className="space-y-2 pt-2 border-t border-[#dfe6df]">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-1.5 font-black text-[#26302b]">
                <Paperclip className="h-3.5 w-3.5 text-[#2f8b3c]" />
                <span>Archivos y documentos adjuntos</span>
                {attachments.length > 0 && (
                  <span className="rounded-full bg-[#eaf6ec] px-2 py-0.2 text-[10px] font-black text-[#236a2d]">
                    {attachments.length}
                  </span>
                )}
              </label>
              <span className="text-[10px] text-[#6d766f]">
                Guías, ejercicios, lecturas, imágenes, etc.
              </span>
            </div>

            {/* Drag & Drop Upload Zone */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`relative flex flex-col items-center justify-center rounded-2xl border-2 border-dashed p-4 text-center cursor-pointer transition ${
                isDragging
                  ? 'border-[#2f8b3c] bg-[#eaf6ec]'
                  : 'border-[#cad4cb] bg-[#fbfdfb] hover:border-[#2f8b3c] hover:bg-[#f7f8f6]'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                multiple
                className="hidden"
                onChange={e => {
                  if (e.target.files) handleUploadFiles(e.target.files);
                  e.target.value = '';
                }}
              />

              {isProcessingFiles ? (
                <div className="flex items-center gap-2 py-2 text-[#2f8b3c]">
                  <Loader2 className="h-5 w-5 animate-spin" />
                  <span className="font-bold text-xs">Procesando archivos...</span>
                </div>
              ) : (
                <>
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#eef2ee] text-[#2f8b3c] mb-1.5">
                    <Upload className="h-5 w-5" />
                  </div>
                  <p className="text-xs font-bold text-[#26302b]">
                    Arrastra aquí tus archivos o <span className="text-[#2f8b3c] underline">haz clic para examinar</span>
                  </p>
                  <p className="mt-0.5 text-[10px] text-[#6d766f]">
                    Soporta PDFs, Word (DOCX), Excel (XLSX), Presentaciones (PPTX), Imágenes y Archivos comprimidos
                  </p>
                </>
              )}
            </div>

            {/* List of Attached Files */}
            {attachments.length > 0 && (
              <div className="space-y-1.5 mt-2 max-h-48 overflow-y-auto pr-1">
                {attachments.map(file => (
                  <div
                    key={file.id}
                    className="flex items-center justify-between rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 transition hover:bg-white"
                  >
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white border border-[#dfe6df]">
                        {getFileIcon(file.type)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-xs font-bold text-[#26302b]">
                          {file.name}
                        </p>
                        <div className="flex items-center gap-2 text-[10px] text-[#6d766f]">
                          <span className="font-semibold">{formatFileSize(file.size)}</span>
                          <span>·</span>
                          <span className="rounded bg-[#edf1ed] px-1 py-0.2 font-bold text-[#48534b]">
                            {file.type}
                          </span>
                          {file.storageUrl && (
                            <span className="inline-flex items-center gap-0.5 rounded bg-[#eaf6ec] px-1.5 py-0.5 font-bold text-[#236a2d]" title="Alojado en Firebase Cloud Storage">
                              <Cloud className="h-2.5 w-2.5" />
                              <span>Cloud</span>
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0 ml-2">
                      <button
                        type="button"
                        onClick={e => {
                          e.stopPropagation();
                          downloadAttachedFile(file, title);
                        }}
                        className="rounded-lg p-1.5 text-[#546057] hover:bg-[#eef2ee] hover:text-[#26302b]"
                        title="Descargar archivo"
                      >
                        <Download className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={e => {
                          e.stopPropagation();
                          handleRemoveAttachment(file.id);
                        }}
                        className="rounded-lg p-1.5 text-[#c6292e] hover:bg-[#fde7e7]"
                        title="Quitar archivo"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#dfe6df]">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2 font-bold text-[#6d766f] hover:bg-[#eef2ee]"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isProcessingFiles}
              className="rounded-xl bg-[#c6292e] px-5 py-2.5 font-bold text-white shadow-sm hover:bg-[#9f1d24] transition disabled:opacity-50"
            >
              {activity ? 'Guardar cambios' : 'Crear actividad'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
