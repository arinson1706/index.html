import React, { useState, useEffect } from 'react';
import { X, BarChart3, Lock, CheckCircle2 } from 'lucide-react';
import { ClassRoom, GradeEvaluation, PeriodsConfig, ParcialId } from '../../types';
import { getTodayDateString, getActivePeriod, isPeriodClosed } from '../../utils/storage';

interface EvaluationModalProps {
  isOpen: boolean;
  classes: ClassRoom[];
  defaultClassId?: string;
  periodsConfig?: PeriodsConfig;
  defaultParcial?: ParcialId;
  onClose: () => void;
  onSave: (evalData: Omit<GradeEvaluation, 'id'>) => void;
}

export const EvaluationModal: React.FC<EvaluationModalProps> = ({
  isOpen,
  classes,
  defaultClassId = '',
  periodsConfig,
  defaultParcial,
  onClose,
  onSave
}) => {
  const activePeriod = getActivePeriod(periodsConfig);
  const targetParcial = defaultParcial || periodsConfig?.activeParcial || activePeriod.id || 1;
  const isClosed = isPeriodClosed(periodsConfig, targetParcial);
  const periodObj = periodsConfig?.periods?.find(p => p.id === targetParcial) || activePeriod;

  const [title, setTitle] = useState('');
  const [classId, setClassId] = useState(defaultClassId || classes[0]?.id || '');
  const [type, setType] = useState('Tarea');
  const [value, setValue] = useState(20);
  const [scale, setScale] = useState<10 | 100>(100);
  const [date, setDate] = useState(getTodayDateString());

  useEffect(() => {
    setClassId(defaultClassId || classes[0]?.id || '');
    setTitle('');
    setType('Tarea');
    setValue(20);
    setScale(100);
    setDate(getTodayDateString());
  }, [defaultClassId, classes, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !classId || isClosed) return;

    onSave({
      classId,
      title: title.trim(),
      type,
      value: Number(value) || 20,
      scale,
      date,
      parcial: targetParcial,
      scores: {}
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-md rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#dfe6df] pb-4 mb-5">
          <div className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-[#c6292e]" />
            <h3 className="text-base font-black text-[#26302b]">Nueva evaluación</h3>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-[#6d766f] hover:bg-[#eef2ee]">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Parcial Indicator Banner */}
          <div
            className={`rounded-2xl border p-3 flex items-center justify-between ${
              isClosed
                ? 'border-[#c6292e]/30 bg-[#fde7e7] text-[#c6292e]'
                : 'border-[#2f8b3c]/30 bg-[#eaf6ec] text-[#236a2d]'
            }`}
          >
            <div className="flex items-center gap-2">
              {isClosed ? <Lock className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4" />}
              <div>
                <span className="text-[10px] font-bold block uppercase tracking-wider">
                  Asignación por Parcial
                </span>
                <strong className="text-xs font-black">
                  {periodObj.name} ({isClosed ? 'Cerrado por Coordinación' : 'Activo'})
                </strong>
              </div>
            </div>
            <span
              className={`rounded-lg px-2 py-0.5 text-[10px] font-extrabold ${
                isClosed ? 'bg-[#c6292e] text-white' : 'bg-[#2f8b3c] text-white'
              }`}
            >
              {isClosed ? 'Solo lectura' : 'Período en curso'}
            </span>
          </div>

          {isClosed && (
            <p className="text-[11px] text-[#c6292e] font-semibold">
              ⚠️ Este parcial está cerrado. No se pueden registrar nuevas evaluaciones en un período cerrado.
            </p>
          )}

          <div>
            <label className="block font-bold text-[#26302b] mb-1">Nombre de la evaluación *</label>
            <input
              type="text"
              required
              placeholder="Ej: Examen Parcial II, Ensayo, Proyecto"
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-bold text-[#26302b] mb-1">Clase asignada *</label>
            <select
              value={classId}
              onChange={e => setClassId(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
            >
              {classes.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-[#26302b] mb-1">Tipo de evaluación</label>
              <select
                value={type}
                onChange={e => setType(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              >
                <option value="Tarea">Tarea</option>
                <option value="Examen">Examen</option>
                <option value="Proyecto">Proyecto</option>
                <option value="Laboratorio">Laboratorio</option>
                <option value="Participación">Participación</option>
                <option value="Asistencia">Asistencia</option>
                <option value="Otro">Otro</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-[#26302b] mb-1">Escala máxima</label>
              <select
                value={scale}
                onChange={e => setScale(Number(e.target.value) === 10 ? 10 : 100)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              >
                <option value={100}>Escala 0 a 100 puntos</option>
                <option value={10}>Escala 0 a 10 puntos</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-[#26302b] mb-1">Ponderación (%)</label>
              <input
                type="number"
                min="1"
                max="100"
                value={value}
                onChange={e => setValue(Number(e.target.value))}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              />
            </div>

            <div>
              <label className="block font-bold text-[#26302b] mb-1">Fecha de evaluación</label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#dfe6df]">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2 font-bold text-[#6d766f] hover:bg-[#eef2ee]"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="rounded-xl bg-[#c6292e] px-4 py-2 font-bold text-white shadow-sm hover:bg-[#9f1d24]"
            >
              Crear evaluación
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
