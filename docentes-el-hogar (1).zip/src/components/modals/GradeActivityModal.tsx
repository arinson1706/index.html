import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Award,
  CheckCircle2,
  Search,
  Filter,
  Sparkles,
  Check,
  AlertCircle,
  MessageSquare,
  Paperclip,
  Download,
  FileText,
  FileSpreadsheet,
  Image,
  Video,
  File,
  Lock,
  Cloud
} from 'lucide-react';
import { Activity, ActivityStudentGrade, ClassRoom, Student } from '../../types';
import { getInitials, formatFileSize } from '../../utils/storage';
import { downloadAttachedFile } from '../../utils/fileHelpers';

interface GradeActivityModalProps {
  isOpen: boolean;
  activity: Activity | null;
  classRoom: ClassRoom | null;
  students: Student[];
  isReadOnly?: boolean;
  onClose: () => void;
  onSaveGrades: (
    activityId: string,
    scores: Record<string, number>,
    studentGrades: Record<string, ActivityStudentGrade>
  ) => void;
}

export const GradeActivityModal: React.FC<GradeActivityModalProps> = ({
  isOpen,
  activity,
  classRoom,
  students,
  isReadOnly = false,
  onClose,
  onSaveGrades
}) => {
  const [scores, setScores] = useState<Record<string, number>>({});
  const [gradesMap, setGradesMap] = useState<Record<string, ActivityStudentGrade>>({});
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMode, setFilterMode] = useState<'all' | 'graded' | 'pending'>('all');
  const [showFeedbackFor, setShowFeedbackFor] = useState<string | null>(null);

  useEffect(() => {
    if (activity && isOpen) {
      const initialScores: Record<string, number> = { ...(activity.scores || {}) };
      const initialGrades: Record<string, ActivityStudentGrade> = { ...(activity.studentGrades || {}) };

      // Initialize default grade state for any student that doesn't have one yet
      students.forEach(s => {
        if (initialScores[s.id] !== undefined && !initialGrades[s.id]) {
          initialGrades[s.id] = {
            score: initialScores[s.id],
            status: 'Calificado',
            feedback: ''
          };
        } else if (!initialGrades[s.id]) {
          initialGrades[s.id] = {
            score: undefined,
            status: 'Pendiente',
            feedback: ''
          };
        }
      });

      setScores(initialScores);
      setGradesMap(initialGrades);
      setSearchTerm('');
      setFilterMode('all');
      setShowFeedbackFor(null);
    }
  }, [activity, isOpen, students]);

  if (!isOpen || !activity) return null;

  const maxPoints = Number(activity.value) || 10;

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'PDF':
        return <FileText className="h-3.5 w-3.5 text-[#c6292e]" />;
      case 'XLSX':
        return <FileSpreadsheet className="h-3.5 w-3.5 text-[#2f8b3c]" />;
      case 'DOCX':
        return <FileText className="h-3.5 w-3.5 text-[#1a5fb4]" />;
      case 'Imagen':
        return <Image className="h-3.5 w-3.5 text-[#e66100]" />;
      case 'Video':
        return <Video className="h-3.5 w-3.5 text-[#9141ac]" />;
      default:
        return <File className="h-3.5 w-3.5 text-[#5d685f]" />;
    }
  };

  // Handle score change for a specific student
  const handleScoreChange = (studentId: string, rawVal: string) => {
    if (rawVal === '') {
      setScores(prev => {
        const next = { ...prev };
        delete next[studentId];
        return next;
      });
      setGradesMap(prev => ({
        ...prev,
        [studentId]: {
          ...(prev[studentId] || { status: 'Pendiente' }),
          score: undefined,
          status: 'Pendiente'
        }
      }));
      return;
    }

    let val = parseFloat(rawVal);
    if (isNaN(val)) val = 0;
    if (val < 0) val = 0;
    if (val > maxPoints) val = maxPoints;

    setScores(prev => ({ ...prev, [studentId]: val }));
    setGradesMap(prev => ({
      ...prev,
      [studentId]: {
        ...(prev[studentId] || {}),
        score: val,
        status: 'Calificado',
        gradedAt: new Date().toISOString()
      }
    }));
  };

  // Quick set max score for a student
  const handleSetQuickScore = (studentId: string, val: number) => {
    handleScoreChange(studentId, val.toString());
  };

  // Change submission status
  const handleStatusChange = (studentId: string, status: ActivityStudentGrade['status']) => {
    setGradesMap(prev => ({
      ...prev,
      [studentId]: {
        ...(prev[studentId] || {}),
        status
      }
    }));
  };

  // Change feedback note
  const handleFeedbackChange = (studentId: string, feedback: string) => {
    setGradesMap(prev => ({
      ...prev,
      [studentId]: {
        ...(prev[studentId] || { status: 'Pendiente' }),
        feedback
      }
    }));
  };

  // Quick batch: Assign full score to all pending students
  const handleAssignMaxToPending = () => {
    const updatedScores = { ...scores };
    const updatedGrades = { ...gradesMap };

    students.forEach(s => {
      if (updatedScores[s.id] === undefined) {
        updatedScores[s.id] = maxPoints;
        updatedGrades[s.id] = {
          ...(updatedGrades[s.id] || {}),
          score: maxPoints,
          status: 'Calificado',
          gradedAt: new Date().toISOString()
        };
      }
    });

    setScores(updatedScores);
    setGradesMap(updatedGrades);
  };

  // Clear all scores
  const handleClearAll = () => {
    if (!confirm('¿Estás seguro de reiniciar todas las calificaciones de esta actividad?')) return;
    setScores({});
    const resetGrades: Record<string, ActivityStudentGrade> = {};
    students.forEach(s => {
      resetGrades[s.id] = { status: 'Pendiente', feedback: '' };
    });
    setGradesMap(resetGrades);
  };

  // Calculated statistics
  const scoredStudentIds = Object.keys(scores).filter(id => scores[id] !== undefined && scores[id] !== null);
  const gradedCount = scoredStudentIds.length;
  const totalStudents = students.length;
  const progressPercent = totalStudents > 0 ? Math.round((gradedCount / totalStudents) * 100) : 0;

  const scoreValues = scoredStudentIds.map(id => scores[id]);
  const averageScore = scoreValues.length > 0
    ? (scoreValues.reduce((a, b) => a + b, 0) / scoreValues.length).toFixed(1)
    : '0.0';
  const averagePercent = maxPoints > 0 ? Math.round((Number(averageScore) / maxPoints) * 100) : 0;
  const maxRecorded = scoreValues.length > 0 ? Math.max(...scoreValues) : 0;
  const minRecorded = scoreValues.length > 0 ? Math.min(...scoreValues) : 0;

  // Filtered student list
  const filteredStudents = useMemo(() => {
    return students.filter(s => {
      const q = searchTerm.toLowerCase();
      const matchesSearch = s.name.toLowerCase().includes(q) || (s.code || '').toLowerCase().includes(q);
      const isGraded = scores[s.id] !== undefined;

      if (!matchesSearch) return false;
      if (filterMode === 'graded') return isGraded;
      if (filterMode === 'pending') return !isGraded;
      return true;
    });
  }, [students, searchTerm, filterMode, scores]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveGrades(activity.id, scores, gradesMap);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-4 backdrop-blur-xs overflow-y-auto">
      <div className="relative flex max-h-[92vh] w-full max-w-4xl flex-col rounded-3xl border border-[#dfe6df] bg-white shadow-2xl overflow-hidden">
        {/* Top Header */}
        <div className="flex items-start justify-between border-b border-[#dfe6df] bg-gradient-to-r from-white via-[#f7f8f6] to-white px-6 py-5">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1 rounded-md bg-[#c6292e]/10 px-2 py-0.5 text-[11px] font-black text-[#c6292e]">
                <Award className="h-3.5 w-3.5" />
                Calificador de Actividad
              </span>
              <span className="rounded-md bg-[#f0f4f0] px-2 py-0.5 text-[11px] font-bold text-[#236a2d] border border-[#2f8b3c]/20">
                {classRoom?.name || 'Clase'} {classRoom?.grade ? `(${classRoom.grade})` : ''}
              </span>
              <span className="rounded-md bg-[#fff7cc] px-2 py-0.5 text-[11px] font-black text-[#735f00] border border-[#f5c400]/30">
                Escala: 0 a {maxPoints} pts
              </span>
              {isReadOnly && (
                <span className="inline-flex items-center gap-1 rounded-md bg-[#fde7e7] px-2 py-0.5 text-[11px] font-bold text-[#c6292e] border border-[#c6292e]/30">
                  <Lock className="h-3 w-3" />
                  Parcial Cerrado (Solo Lectura)
                </span>
              )}
            </div>
            <h2 className="text-xl font-black text-[#26302b] sm:text-2xl">
              {activity.title}
            </h2>
            {activity.description && (
              <p className="text-xs text-[#6d766f] line-clamp-1 max-w-2xl">
                {activity.description}
              </p>
            )}

            {/* Teacher assigned materials strip */}
            {activity.attachments && activity.attachments.length > 0 && (
              <div className="mt-2 flex flex-wrap items-center gap-1.5 pt-1">
                <span className="text-[11px] font-bold text-[#536057] flex items-center gap-1">
                  <Paperclip className="h-3 w-3 text-[#2f8b3c]" />
                  Materiales de la actividad ({activity.attachments.length}):
                </span>
                {activity.attachments.map(att => (
                  <button
                    key={att.id}
                    type="button"
                    onClick={() => downloadAttachedFile(att, activity.title)}
                    className="inline-flex items-center gap-1 rounded-lg bg-white px-2 py-0.5 text-[10px] font-bold text-[#26302b] border border-[#dfe6df] hover:border-[#2f8b3c] hover:text-[#236a2d] transition shadow-2xs"
                    title="Descargar material de la actividad"
                  >
                    {getFileIcon(att.type)}
                    <span className="max-w-[130px] truncate">{att.name}</span>
                    <span className="text-[#8e9890]">({formatFileSize(att.size)})</span>
                    <Download className="h-2.5 w-2.5 text-[#2f8b3c]" />
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={onClose}
            className="rounded-xl p-2 text-[#6d766f] hover:bg-[#eef2ee] transition"
            title="Cerrar"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Read-only Alert Banner */}
        {isReadOnly && (
          <div className="flex items-center gap-2 border-b border-[#c6292e]/20 bg-[#fde7e7] px-6 py-2.5 text-xs font-bold text-[#c6292e]">
            <Lock className="h-4 w-4 shrink-0" />
            <span>
              Este parcial ha sido <strong>cerrado por Coordinación</strong>. Puedes revisar los puntajes y comentarios en modo de consulta, pero las calificaciones no se pueden modificar.
            </span>
          </div>
        )}

        {/* Statistical Overview Strip */}
        <div className="grid grid-cols-2 gap-3 border-b border-[#dfe6df] bg-[#fbfdfb] px-6 py-3.5 sm:grid-cols-4">
          <div className="rounded-2xl border border-[#dfe6df] bg-white p-3">
            <div className="text-[10px] font-extrabold uppercase tracking-wider text-[#6d766f]">
              Alumnos en clase
            </div>
            <div className="mt-1 text-lg font-black text-[#26302b]">
              {totalStudents}
            </div>
          </div>

          <div className="rounded-2xl border border-[#dfe6df] bg-white p-3">
            <div className="text-[10px] font-extrabold uppercase tracking-wider text-[#6d766f]">
              Calificados
            </div>
            <div className="mt-1 flex items-baseline gap-1.5">
              <span className="text-lg font-black text-[#236a2d]">
                {gradedCount} / {totalStudents}
              </span>
              <span className="text-xs font-bold text-[#6d766f]">({progressPercent}%)</span>
            </div>
          </div>

          <div className="rounded-2xl border border-[#dfe6df] bg-white p-3">
            <div className="text-[10px] font-extrabold uppercase tracking-wider text-[#6d766f]">
              Promedio grupal
            </div>
            <div className="mt-1 flex items-baseline gap-1.5">
              <span className="text-lg font-black text-[#26302b]">
                {averageScore} <span className="text-xs text-[#6d766f]">/ {maxPoints} pts</span>
              </span>
              <span className={`text-xs font-black ${
                averagePercent >= 70 ? 'text-[#236a2d]' : averagePercent >= 60 ? 'text-[#735f00]' : 'text-[#c6292e]'
              }`}>
                ({averagePercent}%)
              </span>
            </div>
          </div>

          <div className="rounded-2xl border border-[#dfe6df] bg-white p-3">
            <div className="text-[10px] font-extrabold uppercase tracking-wider text-[#6d766f]">
              Rango de notas
            </div>
            <div className="mt-1 text-xs font-bold text-[#26302b]">
              {scoreValues.length > 0 ? (
                <>Min: <strong className="text-[#c6292e]">{minRecorded}</strong> · Max: <strong className="text-[#236a2d]">{maxRecorded}</strong></>
              ) : (
                <span className="text-[#98a39b]">Sin notas aún</span>
              )}
            </div>
          </div>
        </div>

        {/* Toolbar: Search, Filters, and Batch Actions */}
        <div className="flex flex-col gap-3 border-b border-[#dfe6df] bg-white px-6 py-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-1 items-center gap-2">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-[#6d766f]" />
              <input
                type="text"
                placeholder="Buscar alumno por nombre o código..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] py-1.5 pl-9 pr-3 text-xs outline-none transition focus:border-[#2f8b3c] focus:bg-white"
              />
            </div>

            {/* Filter pills */}
            <div className="flex items-center gap-1 rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-1">
              {(['all', 'graded', 'pending'] as const).map(tab => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setFilterMode(tab)}
                  className={`rounded-lg px-2.5 py-1 text-[11px] font-extrabold transition ${
                    filterMode === tab
                      ? 'bg-[#26302b] text-white shadow-xs'
                      : 'text-[#6d766f] hover:text-[#26302b]'
                  }`}
                >
                  {tab === 'all' ? `Todos (${totalStudents})` : tab === 'graded' ? `Calificados (${gradedCount})` : `Pendientes (${totalStudents - gradedCount})`}
                </button>
              ))}
            </div>
          </div>

          {!isReadOnly && (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleAssignMaxToPending}
                className="inline-flex items-center gap-1 rounded-xl border border-[#bfe2c4] bg-[#eaf6ec] px-3 py-1.5 text-xs font-bold text-[#236a2d] transition hover:bg-[#d8edd9]"
                title={`Asignar ${maxPoints} puntos a todos los alumnos que aún no tienen nota`}
              >
                <Sparkles className="h-3.5 w-3.5 text-[#2f8b3c]" />
                <span>Puntaje completo a pendientes</span>
              </button>

              {gradedCount > 0 && (
                <button
                  type="button"
                  onClick={handleClearAll}
                  className="rounded-xl px-2.5 py-1.5 text-xs font-semibold text-[#c6292e] hover:bg-[#fde7e7]"
                >
                  Limpiar
                </button>
              )}
            </div>
          )}
        </div>

        {/* Students List Form */}
        <form onSubmit={handleSubmit} className="flex flex-1 flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto px-6 py-4">
            {filteredStudents.length === 0 ? (
              <div className="py-12 text-center">
                <AlertCircle className="mx-auto h-8 w-8 text-[#cad4cb] mb-2" />
                <p className="text-xs font-bold text-[#26302b]">
                  {searchTerm || filterMode !== 'all'
                    ? 'No se encontraron alumnos con los filtros seleccionados'
                    : 'No hay alumnos inscritos en esta clase'}
                </p>
                <p className="mt-1 text-[11px] text-[#6d766f]">
                  Verifica que los alumnos estén inscritos al grado correspondiente de esta materia.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {filteredStudents.map((student, index) => {
                  const studentScore = scores[student.id];
                  const hasScore = studentScore !== undefined && studentScore !== null;
                  const currentNum = hasScore ? studentScore : 0;
                  const percent = maxPoints > 0 ? Math.round((currentNum / maxPoints) * 100) : 0;
                  const currentGradeInfo = gradesMap[student.id] || { status: 'Pendiente', feedback: '' };
                  const isShowingFeedback = showFeedbackFor === student.id || Boolean(currentGradeInfo.feedback);

                  return (
                    <div
                      key={student.id}
                      className={`rounded-2xl border p-3.5 transition ${
                        hasScore
                          ? 'border-[#bfe2c4] bg-[#fbfdfb]'
                          : 'border-[#dfe6df] bg-white hover:border-[#cad4cb]'
                      }`}
                    >
                      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                        {/* Student identity */}
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#eef2ee] text-xs font-black text-[#26302b]">
                            {index + 1}
                          </div>
                          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#2f8b3c]/10 text-xs font-black text-[#236a2d]">
                            {getInitials(student.name)}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <strong className="truncate text-xs font-extrabold text-[#26302b]">
                                {student.name}
                              </strong>
                              {student.code && (
                                <span className="rounded-md bg-[#f0f4f0] px-1.5 py-0.2 text-[10px] font-bold text-[#536057]">
                                  {student.code}
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-[#6d766f]">
                              Sec. {student.section || 'A'} · {student.guardianName ? `Tutor: ${student.guardianName}` : 'Matriculado'}
                            </span>
                          </div>
                        </div>

                        {/* Grade Controls */}
                        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                          {/* Delivery Status */}
                          <select
                            disabled={isReadOnly}
                            value={currentGradeInfo.status || 'Pendiente'}
                            onChange={e =>
                              handleStatusChange(
                                student.id,
                                e.target.value as ActivityStudentGrade['status']
                              )
                            }
                            className={`rounded-xl border px-2 py-1.5 text-[11px] font-bold outline-none ${
                              isReadOnly ? 'opacity-75 cursor-not-allowed' : ''
                            } ${
                              currentGradeInfo.status === 'Entregado' || currentGradeInfo.status === 'Calificado'
                                ? 'border-[#bfe2c4] bg-[#eaf6ec] text-[#236a2d]'
                                : currentGradeInfo.status === 'No Entregado'
                                ? 'border-[#fde7e7] bg-[#fde7e7] text-[#c6292e]'
                                : 'border-[#dfe6df] bg-[#f7f8f6] text-[#536057]'
                            }`}
                          >
                            <option value="Pendiente">Pendiente</option>
                            <option value="Entregado">Entregado</option>
                            <option value="Calificado">Calificado</option>
                            <option value="No Entregado">No Entregado</option>
                          </select>

                          {/* Quick Score Buttons */}
                          {!isReadOnly && (
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => handleSetQuickScore(student.id, maxPoints)}
                                className="rounded-lg border border-[#dfe6df] bg-[#f7f8f6] px-2 py-1 text-[10px] font-black text-[#236a2d] hover:bg-[#eaf6ec] hover:border-[#bfe2c4]"
                                title={`Asignar ${maxPoints} pts`}
                              >
                                Max ({maxPoints})
                              </button>
                              <button
                                type="button"
                                onClick={() => handleSetQuickScore(student.id, 0)}
                                className="rounded-lg border border-[#dfe6df] bg-[#f7f8f6] px-2 py-1 text-[10px] font-bold text-[#6d766f] hover:bg-[#fde7e7] hover:text-[#c6292e]"
                                title="Asignar 0 pts"
                              >
                                0 pts
                              </button>
                            </div>
                          )}

                          {/* Score Input or Locked Score Badge */}
                          <div className="flex items-center gap-1.5">
                            {isReadOnly ? (
                              <div className="flex items-center gap-1 rounded-xl border border-[#dfe6df] bg-[#edf1ed] px-2.5 py-1.5 text-xs font-black text-[#546057]">
                                <Lock className="h-3 w-3 text-[#6d766f]" />
                                <span>{hasScore ? studentScore : '—'}</span>
                              </div>
                            ) : (
                              <div className="relative">
                                <input
                                  type="number"
                                  min="0"
                                  max={maxPoints}
                                  step="0.5"
                                  placeholder="0"
                                  value={hasScore ? studentScore : ''}
                                  onChange={e => handleScoreChange(student.id, e.target.value)}
                                  className="w-20 rounded-xl border border-[#dfe6df] bg-white px-2.5 py-1.5 text-center text-xs font-black text-[#26302b] outline-none transition focus:border-[#2f8b3c] focus:ring-2 focus:ring-[#2f8b3c]/20"
                                />
                              </div>
                            )}
                            <span className="text-xs font-bold text-[#6d766f]">
                              / {maxPoints} pts
                            </span>

                            {/* Score Percentage Pill */}
                            {hasScore ? (
                              <span
                                className={`rounded-xl px-2 py-1 text-[11px] font-black ${
                                  percent >= 70
                                    ? 'bg-[#eaf6ec] text-[#236a2d]'
                                    : percent >= 60
                                    ? 'bg-[#fff7cc] text-[#735f00]'
                                    : 'bg-[#fde7e7] text-[#c6292e]'
                                }`}
                              >
                                {percent}%
                              </span>
                            ) : (
                              <span className="rounded-xl bg-[#f7f8f6] px-2 py-1 text-[10px] font-semibold text-[#8e9890] border border-[#dfe6df]">
                                Sin calificar
                              </span>
                            )}
                          </div>

                          {/* Toggle feedback note button */}
                          <button
                            type="button"
                            onClick={() =>
                              setShowFeedbackFor(prev => (prev === student.id ? null : student.id))
                            }
                            className={`rounded-xl p-1.5 transition ${
                              currentGradeInfo.feedback
                                ? 'bg-[#eaf6ec] text-[#236a2d] border border-[#bfe2c4]'
                                : 'text-[#6d766f] hover:bg-[#eef2ee]'
                            }`}
                            title={currentGradeInfo.feedback ? 'Ver comentario del docente' : 'Agregar comentario para el alumno'}
                          >
                            <MessageSquare className="h-4 w-4" />
                          </button>
                        </div>
                      </div>

                      {/* Student Submitted Homework Files */}
                      {currentGradeInfo.attachments && currentGradeInfo.attachments.length > 0 && (
                        <div className="mt-2.5 flex flex-wrap items-center gap-2 rounded-xl bg-[#eaf6ec] p-2.5 border border-[#bfe2c4]/70">
                          <span className="flex items-center gap-1 text-[11px] font-bold text-[#236a2d]">
                            <Paperclip className="h-3.5 w-3.5" />
                            Trabajo entregado ({currentGradeInfo.attachments.length}):
                          </span>
                          {currentGradeInfo.attachments.map(att => (
                            <button
                              key={att.id}
                              type="button"
                              onClick={() => downloadAttachedFile(att, `Entrega_${student.name}_${activity.title}`)}
                              className="inline-flex items-center gap-1.5 rounded-lg bg-white px-2.5 py-1 text-xs font-bold text-[#26302b] border border-[#dfe6df] hover:border-[#2f8b3c] hover:text-[#236a2d] shadow-2xs transition"
                              title="Descargar archivo entregado por el estudiante"
                            >
                              {getFileIcon(att.type)}
                              <span className="max-w-[140px] truncate">{att.name}</span>
                              <span className="text-[10px] text-[#6d766f]">({formatFileSize(att.size)})</span>
                              {att.storageUrl && (
                                <span className="inline-flex items-center gap-0.5 rounded bg-[#eaf6ec] px-1 py-0.5 text-[9px] font-bold text-[#236a2d]" title="Alojado en Firebase Cloud Storage">
                                  <Cloud className="h-2.5 w-2.5" />
                                </span>
                              )}
                              <Download className="h-3 w-3 text-[#2f8b3c]" />
                            </button>
                          ))}
                          {currentGradeInfo.studentComment && (
                            <div className="w-full text-[11px] text-[#536057] italic bg-white/80 px-2 py-1 rounded-lg border border-[#dfe6df]/60 mt-1">
                              "{currentGradeInfo.studentComment}"
                            </div>
                          )}
                        </div>
                      )}

                      {/* Expandable Feedback / Observation Note */}
                      {isShowingFeedback && (
                        <div className="mt-2.5 border-t border-[#edf1ed] pt-2">
                          <input
                            type="text"
                            placeholder="Comentario u observación sobre el trabajo del estudiante (opcional)..."
                            value={currentGradeInfo.feedback || ''}
                            onChange={e => handleFeedbackChange(student.id, e.target.value)}
                            className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3 py-1.5 text-xs text-[#26302b] outline-none focus:border-[#2f8b3c] focus:bg-white"
                          />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Modal Footer with Submit Actions */}
          <div className="flex flex-col gap-3 border-t border-[#dfe6df] bg-[#f7f8f6] px-6 py-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2 text-xs text-[#536057]">
              <CheckCircle2 className="h-4 w-4 text-[#2f8b3c]" />
              <span>
                <strong>{gradedCount}</strong> de <strong>{totalStudents}</strong> alumnos calificados
                {gradedCount === totalStudents && totalStudents > 0 && (
                  <span className="ml-1.5 font-bold text-[#236a2d]">· ¡Calificación completa!</span>
                )}
              </span>
            </div>

            <div className="flex items-center justify-end gap-2">
              {isReadOnly ? (
                <button
                  type="button"
                  onClick={onClose}
                  className="flex items-center gap-1.5 rounded-xl bg-[#26302b] px-5 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-black transition"
                >
                  <Lock className="h-4 w-4" />
                  <span>Cerrar (Modo lectura)</span>
                </button>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={onClose}
                    className="rounded-xl px-4 py-2 text-xs font-bold text-[#6d766f] hover:bg-[#eef2ee]"
                  >
                    Cancelar
                  </button>

                  <button
                    type="submit"
                    className="flex items-center gap-1.5 rounded-xl bg-[#2f8b3c] px-5 py-2.5 text-xs font-extrabold text-white shadow-sm hover:bg-[#236a2d] transition"
                  >
                    <Check className="h-4 w-4" />
                    <span>Guardar calificaciones</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
