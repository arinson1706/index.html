import React, { useState } from 'react';
import { X, Calendar } from 'lucide-react';
import { CalendarEvent, ClassRoom } from '../../types';
import { getTodayDateString } from '../../utils/storage';

interface EventModalProps {
  isOpen: boolean;
  classes: ClassRoom[];
  onClose: () => void;
  onSave: (eventData: Omit<CalendarEvent, 'id'>) => void;
}

export const EventModal: React.FC<EventModalProps> = ({ isOpen, classes, onClose, onSave }) => {
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(getTodayDateString());
  const [type, setType] = useState<CalendarEvent['type']>('Actividad');
  const [classId, setClassId] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !date) return;

    onSave({
      title: title.trim(),
      date,
      type,
      classId: classId || undefined
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-md rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#dfe6df] pb-4 mb-5">
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-[#c6292e]" />
            <h3 className="text-base font-black text-[#26302b]">Nuevo evento en agenda</h3>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-[#6d766f] hover:bg-[#eef2ee]">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-[#26302b] mb-1">Nombre del evento o recordatorio *</label>
            <input
              type="text"
              required
              placeholder="Ej: Entrega de calificaciones, Reunión de padres..."
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] focus:bg-white"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-[#26302b] mb-1">Fecha programada *</label>
              <input
                type="date"
                required
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              />
            </div>

            <div>
              <label className="block font-bold text-[#26302b] mb-1">Tipo de evento</label>
              <select
                value={type}
                onChange={e => setType(e.target.value as CalendarEvent['type'])}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
              >
                <option value="Actividad">Actividad</option>
                <option value="Evaluación">Evaluación</option>
                <option value="Reunión">Reunión</option>
                <option value="Proyecto">Proyecto</option>
                <option value="Importante">Importante</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-bold text-[#26302b] mb-1">Vincular a clase (opcional)</label>
            <select
              value={classId}
              onChange={e => setClassId(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c]"
            >
              <option value="">Para toda la institución / General</option>
              {classes.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#dfe6df]">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2 font-bold text-[#6d766f] hover:bg-[#eef2ee]"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="rounded-xl bg-[#c6292e] px-4 py-2 font-bold text-white shadow-sm hover:bg-[#9f1d24]"
            >
              Agregar evento
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
