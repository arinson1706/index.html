import React, { useState, useEffect } from 'react';
import {
  X,
  MessagesSquare,
  FileText,
  Upload,
  CheckCircle2,
  Trash2,
  Cloud,
  Loader2,
  Pin,
  CheckSquare
} from 'lucide-react';
import { ForumTopic, ClassRoom, Activity, User, AttachedFile, ParcialId, PeriodsConfig } from '../../types';
import { uploadFileToStorage } from '../../services/firebase';
import { formatFileSize, getActivePeriod } from '../../utils/storage';

interface ForumTopicModalProps {
  isOpen: boolean;
  topic?: ForumTopic | null;
  classes: ClassRoom[];
  activities: Activity[];
  currentUser: User;
  periodsConfig?: PeriodsConfig;
  initialClassId?: string;
  initialActivityId?: string;
  onClose: () => void;
  onSave: (topicData: Partial<ForumTopic>) => void;
}

export const ForumTopicModal: React.FC<ForumTopicModalProps> = ({
  isOpen,
  topic,
  classes,
  activities,
  currentUser,
  periodsConfig,
  initialClassId,
  initialActivityId,
  onClose,
  onSave
}) => {
  const activePeriod = getActivePeriod(periodsConfig);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [classId, setClassId] = useState('all');
  const [activityId, setActivityId] = useState('');
  const [category, setCategory] = useState<ForumTopic['category']>('debate');
  const [parcial, setParcial] = useState<ParcialId>(activePeriod.id);
  const [status, setStatus] = useState<'open' | 'closed'>('open');
  const [pinned, setPinned] = useState(false);
  const [attachments, setAttachments] = useState<AttachedFile[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (topic) {
      setTitle(topic.title);
      setDescription(topic.description);
      setClassId(topic.classId || 'all');
      setActivityId(topic.activityId || '');
      setCategory(topic.category || 'debate');
      setParcial(topic.parcial || activePeriod.id);
      setStatus(topic.status || 'open');
      setPinned(Boolean(topic.pinned));
      setAttachments(topic.attachments || []);
    } else {
      setTitle('');
      setDescription('');
      setClassId(initialClassId || (classes.length > 0 ? classes[0].id : 'all'));
      setActivityId(initialActivityId || '');
      setCategory(initialActivityId ? 'tarea' : 'debate');
      setParcial(activePeriod.id);
      setStatus('open');
      setPinned(false);
      setAttachments([]);
    }
    setError(null);
  }, [topic, isOpen, initialClassId, initialActivityId, classes, activePeriod.id]);

  if (!isOpen) return null;

  // Filter activities for the selected class
  const classActivities = activities.filter(
    a => classId === 'all' || a.classId === classId
  );

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsUploading(true);
      setUploadProgress(10);
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
      const storagePath = `forum_attachments/${Date.now()}_${safeName}`;

      let downloadUrl = '';
      try {
        const uploadResult = await uploadFileToStorage(file, storagePath, progress => {
          setUploadProgress(progress);
        });
        downloadUrl = uploadResult.downloadUrl;
      } catch (uploadErr) {
        console.warn('Fallback to local read if cloud upload fails:', uploadErr);
      }

      const newAtt: AttachedFile = {
        id: `att-forum-${Date.now()}`,
        name: file.name,
        size: file.size,
        type: file.type.startsWith('image/')
          ? 'image'
          : file.type.includes('pdf')
          ? 'pdf'
          : 'document',
        mime: file.type,
        storageUrl: downloadUrl || undefined,
        storagePath: storagePath,
        uploadedAt: new Date().toISOString()
      };

      setAttachments(prev => [...prev, newAtt]);
      setIsUploading(false);
      setUploadProgress(null);
    } catch (err: any) {
      console.error('File upload error:', err);
      setIsUploading(false);
      setUploadProgress(null);
      setError('No se pudo subir el archivo. Intenta de nuevo.');
    }
  };

  const handleRemoveAttachment = (attId: string) => {
    setAttachments(prev => prev.filter(a => a.id !== attId));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Por favor escribe un título para el tema.');
      return;
    }
    if (!description.trim()) {
      setError('Por favor redacta la descripción o pregunta detonadora del foro.');
      return;
    }

    onSave({
      id: topic?.id,
      title: title.trim(),
      description: description.trim(),
      classId,
      activityId: activityId || undefined,
      category,
      parcial,
      status,
      pinned,
      attachments,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorRole: currentUser.role as 'admin' | 'teacher',
      updatedAt: new Date().toISOString()
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs animate-fade-in">
      <div className="relative flex max-h-[92vh] w-full max-w-2xl flex-col rounded-3xl border border-[#dfe6df] bg-white shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#dfe6df] px-6 py-5">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#236a2d]/10 text-[#236a2d]">
              <MessagesSquare className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-[#141d16]">
                {topic ? 'Editar tema en el foro' : 'Nueva actividad en el foro'}
              </h2>
              <p className="text-xs text-[#526456]">
                Crea una consigna o debate donde los alumnos participen con sus opiniones públicas
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-2 text-[#526456] hover:bg-[#f4f7f4] hover:text-[#141d16] transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
          {error && (
            <div className="rounded-2xl border border-red-200 bg-red-50 p-3 text-xs font-medium text-red-700">
              {error}
            </div>
          )}

          {/* Title */}
          <div>
            <label className="block text-xs font-bold text-[#141d16] uppercase tracking-wider mb-1.5">
              Título del debate o consigna *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="Ej: ¿Cómo afecta el cambio climático a nuestra comunidad?"
              className="w-full rounded-2xl border border-[#dfe6df] bg-[#f4f7f4] px-4 py-2.5 text-sm font-medium text-[#141d16] focus:border-[#236a2d] focus:bg-white focus:outline-hidden"
            />
          </div>

          {/* Grid: Class, Parcial, Category */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-[#141d16] uppercase tracking-wider mb-1.5">
                Clase dirigida
              </label>
              <select
                value={classId}
                onChange={e => {
                  setClassId(e.target.value);
                  setActivityId('');
                }}
                className="w-full rounded-2xl border border-[#dfe6df] bg-[#f4f7f4] px-3 py-2.5 text-sm font-medium text-[#141d16] focus:border-[#236a2d] focus:bg-white focus:outline-hidden"
              >
                <option value="all">🏫 Toda la institución / General</option>
                {classes.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.grade} "{c.section}")
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#141d16] uppercase tracking-wider mb-1.5">
                Parcial
              </label>
              <select
                value={parcial}
                onChange={e => setParcial(Number(e.target.value) as ParcialId)}
                className="w-full rounded-2xl border border-[#dfe6df] bg-[#f4f7f4] px-3 py-2.5 text-sm font-medium text-[#141d16] focus:border-[#236a2d] focus:bg-white focus:outline-hidden"
              >
                <option value={1}>1er Parcial</option>
                <option value={2}>2do Parcial</option>
                <option value={3}>3er Parcial</option>
                <option value={4}>4to Parcial</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#141d16] uppercase tracking-wider mb-1.5">
                Tipo de debate
              </label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as any)}
                className="w-full rounded-2xl border border-[#dfe6df] bg-[#f4f7f4] px-3 py-2.5 text-sm font-medium text-[#141d16] focus:border-[#236a2d] focus:bg-white focus:outline-hidden"
              >
                <option value="debate">💬 Debate de opinión</option>
                <option value="tarea">📝 Vinculado a tarea</option>
                <option value="pregunta">💡 Pregunta detonadora</option>
                <option value="lectura">📖 Discusión de lectura</option>
                <option value="proyecto">🔬 Avance de proyecto</option>
                <option value="general">📢 General / Libre</option>
              </select>
            </div>
          </div>

          {/* Optional Activity Link */}
          <div className="rounded-2xl border border-[#dfe6df] bg-[#f9faf9] p-3.5 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-[#141d16] uppercase tracking-wider">
              <CheckSquare className="h-4 w-4 text-[#236a2d]" />
              <span>Vincular a una Tarea o Actividad existente (Opcional)</span>
            </div>
            <p className="text-xs text-[#526456]">
              Permite que los alumnos discutan sobre la tarea, compartan dudas y analicen soluciones.
            </p>
            <select
              value={activityId}
              onChange={e => {
                setActivityId(e.target.value);
                if (e.target.value) setCategory('tarea');
              }}
              className="w-full rounded-2xl border border-[#dfe6df] bg-white px-3 py-2 text-sm font-medium text-[#141d16] focus:border-[#236a2d] focus:outline-hidden"
            >
              <option value="">-- Sin tarea vinculada (tema libre o de clase) --</option>
              {classActivities.map(act => (
                <option key={act.id} value={act.id}>
                  {act.title} ({act.value} pts) - {act.deadline || act.date}
                </option>
              ))}
            </select>
          </div>

          {/* Description & Prompt */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-[#141d16] uppercase tracking-wider">
                Consigna, pregunta detonadora o instrucciones *
              </label>
              <span className="text-[11px] text-[#526456]">Visible para todos los alumnos</span>
            </div>
            <textarea
              required
              rows={4}
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Escribe la pregunta o el tema sobre el cual los alumnos deben reflexionar y expresar sus puntos de vista..."
              className="w-full rounded-2xl border border-[#dfe6df] bg-[#f4f7f4] p-3 text-sm font-medium text-[#141d16] focus:border-[#236a2d] focus:bg-white focus:outline-hidden"
            />
          </div>

          {/* Options: Status & Pin */}
          <div className="flex flex-wrap items-center gap-4 rounded-2xl border border-[#dfe6df] p-3">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-[#141d16]">
              <input
                type="checkbox"
                checked={status === 'open'}
                onChange={e => setStatus(e.target.checked ? 'open' : 'closed')}
                className="h-4 w-4 rounded-md accent-[#236a2d]"
              />
              <span>Foro abierto para recibir opiniones de los alumnos</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-[#141d16]">
              <input
                type="checkbox"
                checked={pinned}
                onChange={e => setPinned(e.target.checked)}
                className="h-4 w-4 rounded-md accent-[#236a2d]"
              />
              <Pin className="h-3.5 w-3.5 text-amber-600" />
              <span>Fijar tema en la parte superior</span>
            </label>
          </div>

          {/* Attachments & Cloud Storage */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-[#141d16] uppercase tracking-wider">
                Material de apoyo adjunto
              </label>
              <span className="inline-flex items-center gap-1 text-[11px] text-[#236a2d] font-semibold">
                <Cloud className="h-3 w-3" />
                Firebase Cloud Storage
              </span>
            </div>

            {attachments.length > 0 && (
              <div className="mb-2 space-y-1.5">
                {attachments.map(att => (
                  <div
                    key={att.id}
                    className="flex items-center justify-between rounded-xl border border-[#dfe6df] bg-[#f4f7f4] px-3 py-1.5 text-xs text-[#141d16]"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <FileText className="h-4 w-4 shrink-0 text-[#236a2d]" />
                      <span className="truncate font-medium">{att.name}</span>
                      <span className="text-[#526456]">({formatFileSize(att.size)})</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveAttachment(att.id)}
                      className="text-red-500 hover:text-red-700 p-1"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <label className="flex cursor-pointer items-center justify-center gap-2 rounded-2xl border border-dashed border-[#dfe6df] bg-[#f9faf9] p-3 text-xs font-semibold text-[#526456] hover:bg-[#eef5ee] hover:text-[#236a2d] transition-colors">
              {isUploading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin text-[#236a2d]" />
                  <span>Subiendo a la nube ({uploadProgress || 0}%)...</span>
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4" />
                  <span>Subir documento, lectura o imagen de apoyo (PDF, DOCX, IMG)</span>
                </>
              )}
              <input
                type="file"
                disabled={isUploading}
                onChange={handleFileUpload}
                className="hidden"
                accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.png,.jpg,.jpeg,.zip"
              />
            </label>
          </div>
        </form>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 border-t border-[#dfe6df] px-6 py-4 bg-[#f9faf9] rounded-b-3xl">
          <button
            type="button"
            onClick={onClose}
            className="rounded-2xl border border-[#dfe6df] bg-white px-5 py-2.5 text-xs font-bold text-[#526456] hover:bg-[#f4f7f4] transition-colors"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            className="flex items-center gap-2 rounded-2xl bg-[#236a2d] px-6 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-[#1b5323] transition-colors"
          >
            <CheckCircle2 className="h-4 w-4" />
            <span>{topic ? 'Guardar cambios' : 'Publicar actividad en el foro'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
