import React, { useState, useEffect } from 'react';
import { X, Key, UserCheck, Eye, EyeOff, ShieldCheck } from 'lucide-react';
import { Student, User } from '../../types';

interface StudentAccessModalProps {
  isOpen: boolean;
  student: Student | null;
  existingUser?: User | null;
  allUsers: User[];
  onClose: () => void;
  onSaveAccess: (studentId: string, username: string, password: string, active: boolean) => void;
}

export const StudentAccessModal: React.FC<StudentAccessModalProps> = ({
  isOpen,
  student,
  existingUser,
  allUsers,
  onClose,
  onSaveAccess
}) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [active, setActive] = useState(true);
  const [showPassword, setShowPassword] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!student) return;
    setError('');

    if (existingUser) {
      setUsername(existingUser.username || '');
      setPassword(existingUser.password || '');
      setActive(existingUser.active !== false);
    } else {
      // Suggest clean username based on student's name
      const nameParts = student.name
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9\s]/g, '')
        .trim()
        .split(/\s+/);

      let suggested = '';
      if (nameParts.length >= 2) {
        suggested = `${nameParts[0]}.${nameParts[1]}`;
      } else if (nameParts.length === 1) {
        suggested = nameParts[0];
      } else {
        suggested = `est_${student.code?.toLowerCase() || Date.now()}`;
      }

      setUsername(suggested);
      setPassword('');
      setActive(true);
    }
  }, [student, existingUser, isOpen]);

  if (!isOpen || !student) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanUser = username.trim().toLowerCase();
    const cleanPass = password.trim();

    if (!cleanUser || !cleanPass) {
      setError('Por favor ingresa usuario y contraseña.');
      return;
    }

    // Check if username is taken by another user
    const duplicate = allUsers.find(
      u => u.username.toLowerCase() === cleanUser && u.id !== existingUser?.id
    );

    if (duplicate) {
      setError(`El nombre de usuario "${cleanUser}" ya está en uso por otro usuario.`);
      return;
    }

    onSaveAccess(student.id, cleanUser, cleanPass, active);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-md rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-2xl animate-fade-in">
        <div className="flex items-center justify-between border-b border-[#dfe6df] pb-4 mb-4">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#eaf6ec] text-[#2f8b3c]">
              <Key className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-[#26302b]">
                {existingUser ? 'Credenciales de acceso' : 'Dar acceso al alumno'}
              </h3>
              <span className="text-[11px] font-medium text-[#6d766f]">
                {student.name} ({student.code || 'S/C'})
              </span>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-[#6d766f] hover:bg-[#eef2ee]">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mb-4 rounded-2xl bg-[#f7f8f6] p-3 text-xs text-[#546057] border border-[#dfe6df]/80">
          <div className="flex items-center gap-1.5 font-bold text-[#236a2d]">
            <ShieldCheck className="h-4 w-4" />
            <span>Acceso para el estudiante</span>
          </div>
          <p className="mt-1 text-[11px] leading-relaxed text-[#6d766f]">
            El alumno podrá ingresar a Docentes El Hogar para consultar sus notas, asistencias, tareas y recursos.
            No tendrá permisos para crear evaluaciones ni modificar datos escolares.
          </p>
        </div>

        {error && (
          <div className="mb-4 rounded-xl border border-[#fde7e7] bg-[#fde7e7] p-2.5 text-xs font-bold text-[#c6292e]">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-[#26302b] mb-1">Nombre de usuario (Login) *</label>
            <input
              type="text"
              required
              value={username}
              onChange={e => setUsername(e.target.value)}
              placeholder="ej: carlos.mendoza"
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3.5 py-2.5 text-xs font-bold text-[#26302b] outline-none transition focus:border-[#2f8b3c] focus:bg-white"
            />
            <span className="mt-1 block text-[10px] text-[#6d766f]">
              Sin espacios ni caracteres especiales.
            </span>
          </div>

          <div>
            <label className="block font-bold text-[#26302b] mb-1">Contraseña de acceso *</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3.5 py-2.5 pr-10 text-xs font-bold text-[#26302b] outline-none transition focus:border-[#2f8b3c] focus:bg-white"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-[#6d766f] hover:text-[#26302b]"
                title={showPassword ? 'Ocultar contraseña' : 'Ver contraseña'}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            <span className="mt-1 block text-[10px] text-[#6d766f]">
              Puedes ver y compartir esta contraseña directamente con el estudiante.
            </span>
          </div>

          <div>
            <label className="block font-bold text-[#26302b] mb-1">Estado de la cuenta</label>
            <select
              value={active ? 'true' : 'false'}
              onChange={e => setActive(e.target.value === 'true')}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3.5 py-2.5 text-xs font-bold text-[#26302b] outline-none focus:border-[#2f8b3c]"
            >
              <option value="true">Activa (El alumno puede ingresar)</option>
              <option value="false">Desactivada (Acceso suspendido)</option>
            </select>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#dfe6df]">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2 font-bold text-[#6d766f] hover:bg-[#eef2ee]"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 rounded-xl bg-[#2f8b3c] px-4 py-2 font-bold text-white shadow-sm hover:bg-[#236a2d]"
            >
              <UserCheck className="h-4 w-4" />
              <span>{existingUser ? 'Actualizar credenciales' : 'Conceder acceso'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
