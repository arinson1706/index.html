import React, { useState } from 'react';
import { X, Upload, Download, Sparkles, BookOpen, Check } from 'lucide-react';
import { ClassRoom, Student } from '../../types';
import { isStudentInClass, matchGrade } from '../../utils/storage';

interface BulkStudentModalProps {
  isOpen: boolean;
  classes: ClassRoom[];
  onClose: () => void;
  onImport: (students: Omit<Student, 'id'>[]) => void;
}

const STANDARD_GRADES = [
  { value: '1ro', label: '1ro Primaria' },
  { value: '2do', label: '2do Primaria' },
  { value: '3ro', label: '3ro Primaria' },
  { value: '4to', label: '4to Primaria' },
  { value: '5to', label: '5to Primaria' },
  { value: '6to', label: '6to Primaria' },
  { value: '7mo', label: '7mo Básica' },
  { value: '8vo', label: '8vo Básica' },
  { value: '9no', label: '9no Básica' },
  { value: '10mo', label: '10mo Básica' },
  { value: '11mo', label: '11mo Diversificado' }
];

export const BulkStudentModal: React.FC<BulkStudentModalProps> = ({
  isOpen,
  classes,
  onClose,
  onImport
}) => {
  const [selectedGrade, setSelectedGrade] = useState('7mo');
  const [selectedSection, setSelectedSection] = useState('A');
  const [csvText, setCsvText] = useState('');
  const [parsedList, setParsedList] = useState<Omit<Student, 'id'>[]>([]);

  if (!isOpen) return null;

  const matchingClassesForGrade = classes.filter(c =>
    isStudentInClass(
      {
        id: 'preview',
        name: 'Preview',
        code: '',
        classId: '',
        grade: selectedGrade,
        section: selectedSection,
        status: 'Activo'
      },
      c
    )
  );

  const handleParseCsv = (text: string, grade = selectedGrade, sec = selectedSection) => {
    setCsvText(text);
    const lines = text
      .split('\n')
      .map(l => l.trim())
      .filter(l => l.length > 0);

    const students: Omit<Student, 'id'>[] = [];

    // Check if line 0 is a header
    let startIndex = 0;
    if (lines[0]?.toLowerCase().includes('nombre') || lines[0]?.toLowerCase().includes('name')) {
      startIndex = 1;
    }

    for (let i = startIndex; i < lines.length; i++) {
      const parts = lines[i].split(',').map(p => p.trim());
      if (parts[0]) {
        const studentGrade = parts[2] || grade;
        const studentSec = parts[3] || sec;

        // Auto-match all classes assigned to this grade
        const matching = classes.filter(c => matchGrade(studentGrade, c.grade));
        const matchingClassIds = matching.map(c => c.id);

        students.push({
          name: parts[0],
          code: parts[1] || `AL-${Math.floor(1000 + Math.random() * 9000)}`,
          classId: matchingClassIds[0] || classes[0]?.id || '',
          enrolledClassIds: matchingClassIds,
          grade: studentGrade,
          section: studentSec,
          contact: parts[4] || '',
          status: 'Activo'
        });
      }
    }

    setParsedList(students);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = evt => {
      const content = evt.target?.result as string;
      handleParseCsv(content, selectedGrade, selectedSection);
    };
    reader.readAsText(file);
  };

  const handleDownloadTemplate = () => {
    const csvContent =
      'Nombre,Codigo,Grado,Seccion,Contacto\nJuan Perez,AL-2025-01,7mo,A,504 9999-0001\nMaria Rodriguez,AL-2025-02,7mo,A,504 9999-0002\nCarlos Sanchez,AL-2025-03,7mo,A,504 9999-0003';
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'plantilla-alumnos-por-grado.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (parsedList.length === 0) return;
    onImport(parsedList);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
      <div className="relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#dfe6df] pb-4 mb-5">
          <div className="flex items-center gap-2">
            <Upload className="h-5 w-5 text-[#c6292e]" />
            <div>
              <h3 className="text-base font-black text-[#26302b]">Carga masiva de alumnos (CSV)</h3>
              <p className="text-[11px] font-semibold text-[#2f8b3c]">
                Inscripción automática en todas las clases del grado
              </p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-[#6d766f] hover:bg-[#eef2ee]">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl bg-[#f7f8f6] p-4 border border-[#dfe6df]">
            <div className="grid grid-cols-2 gap-3 flex-1">
              <div>
                <label className="block font-bold text-[#26302b] mb-1">Grado predeterminado</label>
                <select
                  value={selectedGrade}
                  onChange={e => {
                    setSelectedGrade(e.target.value);
                    if (csvText) handleParseCsv(csvText, e.target.value, selectedSection);
                  }}
                  className="w-full rounded-xl border border-[#dfe6df] bg-white px-3 py-2 font-bold text-[#26302b] outline-none focus:border-[#2f8b3c]"
                >
                  {STANDARD_GRADES.map(g => (
                    <option key={g.value} value={g.value}>
                      {g.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-[#26302b] mb-1">Sección predeterminada</label>
                <input
                  type="text"
                  value={selectedSection}
                  onChange={e => {
                    setSelectedSection(e.target.value);
                    if (csvText) handleParseCsv(csvText, selectedGrade, e.target.value);
                  }}
                  placeholder="A"
                  className="w-full rounded-xl border border-[#dfe6df] bg-white px-3 py-2 font-bold text-[#26302b] outline-none focus:border-[#2f8b3c]"
                />
              </div>
            </div>

            <button
              type="button"
              onClick={handleDownloadTemplate}
              className="flex items-center gap-1.5 text-xs font-bold text-[#2f8b3c] hover:underline self-end sm:self-center"
            >
              <Download className="h-4 w-4" />
              <span>Plantilla CSV</span>
            </button>
          </div>

          {/* Info note */}
          <div className="flex items-center gap-2 rounded-xl bg-[#eaf6ec] p-3 text-[11px] text-[#236a2d]">
            <Sparkles className="h-4 w-4 shrink-0 text-[#2f8b3c]" />
            <span>
              Los estudiantes importados pertenecerán a este grado y se agregarán <strong>automáticamente a todas las {matchingClassesForGrade.length} clases</strong> registradas para él.
            </span>
          </div>

          <div>
            <label className="block font-bold text-[#26302b] mb-1">
              Subir archivo CSV o pegar contenido
            </label>
            <input
              type="file"
              accept=".csv,.txt"
              onChange={handleFileUpload}
              className="mb-2 block w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2 file:mr-3 file:rounded-lg file:border-0 file:bg-[#2f8b3c] file:px-3 file:py-1 file:text-xs file:font-bold file:text-white hover:file:bg-[#236a2d]"
            />
            <textarea
              rows={4}
              placeholder="Nombre, Codigo, Grado, Seccion, Contacto&#10;Juan Perez, AL-01, 7mo, A, 9999-0001"
              value={csvText}
              onChange={e => handleParseCsv(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-3 font-mono text-[11px] outline-none focus:border-[#2f8b3c] focus:bg-white"
            />
          </div>

          {/* Preview */}
          {parsedList.length > 0 && (
            <div>
              <strong className="block text-xs font-bold text-[#236a2d] mb-2">
                Vista previa: {parsedList.length} alumnos detectados
              </strong>
              <div className="max-h-40 overflow-y-auto rounded-xl border border-[#dfe6df]">
                <table className="w-full border-collapse text-left text-[11px]">
                  <thead className="bg-[#f7f8f6] text-[#6d766f]">
                    <tr>
                      <th className="p-2">Nombre</th>
                      <th className="p-2">Código</th>
                      <th className="p-2">Grado / Sec</th>
                      <th className="p-2">Contacto</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#dfe6df]">
                    {parsedList.slice(0, 10).map((s, idx) => (
                      <tr key={idx}>
                        <td className="p-2 font-bold text-[#26302b]">{s.name}</td>
                        <td className="p-2 font-mono">{s.code}</td>
                        <td className="p-2 font-bold text-[#2f8b3c]">
                          {s.grade} · Sec. {s.section || 'A'}
                        </td>
                        <td className="p-2 text-[#6d766f]">{s.contact || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {parsedList.length > 10 && (
                <span className="text-[10px] text-[#6d766f]">
                  ... y {parsedList.length - 10} alumnos más.
                </span>
              )}
            </div>
          )}

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#dfe6df]">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2 font-bold text-[#6d766f] hover:bg-[#eef2ee]"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={parsedList.length === 0}
              className="flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2 font-bold text-white shadow-sm hover:bg-[#9f1d24] disabled:opacity-50"
            >
              <Check className="h-4 w-4" />
              <span>Importar {parsedList.length} alumnos</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
