import React, { useState, useRef } from 'react';
import {
  X,
  Upload,
  Paperclip,
  FileText,
  FileSpreadsheet,
  Image,
  Video,
  File,
  Trash2,
  Download,
  Loader2,
  CheckCircle2,
  Calendar,
  Clock,
  Send,
  Cloud
} from 'lucide-react';
import { Activity, ActivityStudentGrade, AttachedFile, Student } from '../../types';
import { formatDate, formatFileSize } from '../../utils/storage';
import { processUploadFile, downloadAttachedFile } from '../../utils/fileHelpers';

interface SubmitHomeworkModalProps {
  isOpen: boolean;
  activity: Activity;
  student: Student;
  currentGrade?: ActivityStudentGrade;
  onClose: () => void;
  onSubmitHomework: (
    activityId: string,
    studentId: string,
    submissionData: {
      attachments: AttachedFile[];
      studentComment?: string;
    }
  ) => void;
}

export const SubmitHomeworkModal: React.FC<SubmitHomeworkModalProps> = ({
  isOpen,
  activity,
  student,
  currentGrade,
  onClose,
  onSubmitHomework
}) => {
  const [attachments, setAttachments] = useState<AttachedFile[]>(
    currentGrade?.attachments || []
  );
  const [studentComment, setStudentComment] = useState(
    currentGrade?.studentComment || ''
  );
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleUploadFiles = async (files: FileList | File[]) => {
    if (!files || files.length === 0) return;
    setIsProcessing(true);

    try {
      const fileArray = Array.from(files);
      const newAttachments: AttachedFile[] = [];

      for (const file of fileArray) {
        const attached = await processUploadFile(file, 'homework');
        newAttachments.push(attached);
      }

      setAttachments(prev => [...prev, ...newAttachments]);
    } catch (err) {
      console.error('Error uploading student homework file:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      await handleUploadFiles(e.dataTransfer.files);
    }
  };

  const handleRemoveAttachment = (attId: string) => {
    setAttachments(prev => prev.filter(a => a.id !== attId));
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'PDF':
        return <FileText className="h-4 w-4 text-[#c6292e]" />;
      case 'XLSX':
        return <FileSpreadsheet className="h-4 w-4 text-[#2f8b3c]" />;
      case 'DOCX':
        return <FileText className="h-4 w-4 text-[#1a5fb4]" />;
      case 'Imagen':
        return <Image className="h-4 w-4 text-[#e66100]" />;
      case 'Video':
        return <Video className="h-4 w-4 text-[#9141ac]" />;
      default:
        return <File className="h-4 w-4 text-[#5d685f]" />;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (attachments.length === 0 && !studentComment.trim()) {
      alert('Por favor adjunta al menos un archivo o escribe un comentario de tu entrega.');
      return;
    }

    onSubmitHomework(activity.id, student.id, {
      attachments,
      studentComment: studentComment.trim()
    });
    onClose();
  };

  const isAlreadyGraded = currentGrade?.status === 'Calificado';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-4 backdrop-blur-xs overflow-y-auto">
      <div className="relative my-6 max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[#dfe6df] pb-4 mb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="rounded-md bg-[#2f8b3c]/10 px-2 py-0.5 text-[11px] font-black text-[#236a2d]">
                Entrega de Tarea
              </span>
              <span className="rounded-md bg-[#fff7cc] px-2 py-0.5 text-[11px] font-black text-[#735f00]">
                {activity.value} pts posibles
              </span>
            </div>
            <h3 className="text-lg font-black text-[#26302b]">
              {activity.title}
            </h3>
            <p className="text-xs text-[#6d766f]">
              Estudiante: <strong>{student.name}</strong> · Vence: {formatDate(activity.deadline)}
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl p-1.5 text-[#6d766f] hover:bg-[#eef2ee]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Activity instructions summary */}
        {activity.description && (
          <div className="mb-4 rounded-2xl bg-[#f7f8f6] p-3 border border-[#dfe6df] text-xs text-[#536057]">
            <strong className="block text-[11px] font-black text-[#26302b] mb-1">
              Instrucciones de la tarea:
            </strong>
            <p className="leading-relaxed">{activity.description}</p>
          </div>
        )}

        {/* If activity has teacher attachments, show them so student can download them */}
        {activity.attachments && activity.attachments.length > 0 && (
          <div className="mb-4 rounded-2xl border border-[#bfe2c4] bg-[#fbfdfb] p-3 text-xs">
            <strong className="block text-[11px] font-black text-[#236a2d] mb-2 flex items-center gap-1.5">
              <Paperclip className="h-3.5 w-3.5" />
              Materiales y guías provistas por el docente ({activity.attachments.length}):
            </strong>
            <div className="space-y-1.5">
              {activity.attachments.map(att => (
                <div
                  key={att.id}
                  className="flex items-center justify-between rounded-xl bg-white p-2 border border-[#dfe6df]"
                >
                  <div className="flex items-center gap-2 truncate">
                    {getFileIcon(att.type)}
                    <span className="truncate font-semibold text-[#26302b]">{att.name}</span>
                    <span className="text-[10px] text-[#6d766f]">({formatFileSize(att.size)})</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => downloadAttachedFile(att, activity.title)}
                    className="flex items-center gap-1 rounded-lg bg-[#eaf6ec] px-2 py-1 text-[11px] font-bold text-[#236a2d] hover:bg-[#d8edd9]"
                  >
                    <Download className="h-3 w-3" />
                    <span>Descargar</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Homework file upload dropzone */}
          <div>
            <label className="block font-black text-[#26302b] mb-1.5 flex items-center justify-between">
              <span>Adjuntar archivo(s) de tu trabajo *</span>
              <span className="text-[10px] font-normal text-[#6d766f]">
                PDF, Fotos, Documentos de texto o comprimidos
              </span>
            </label>

            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`relative flex flex-col items-center justify-center rounded-2xl border-2 border-dashed p-4 text-center cursor-pointer transition ${
                isDragging
                  ? 'border-[#2f8b3c] bg-[#eaf6ec]'
                  : 'border-[#cad4cb] bg-[#fbfdfb] hover:border-[#2f8b3c] hover:bg-[#f7f8f6]'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                multiple
                className="hidden"
                onChange={e => {
                  if (e.target.files) handleUploadFiles(e.target.files);
                  e.target.value = '';
                }}
              />

              {isProcessing ? (
                <div className="flex items-center gap-2 py-2 text-[#2f8b3c]">
                  <Loader2 className="h-5 w-5 animate-spin" />
                  <span className="font-bold">Cargando archivo...</span>
                </div>
              ) : (
                <>
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#eef2ee] text-[#2f8b3c] mb-1.5">
                    <Upload className="h-5 w-5" />
                  </div>
                  <p className="text-xs font-bold text-[#26302b]">
                    Arrastra tus archivos de tarea aquí o <span className="text-[#2f8b3c] underline">haz clic para buscar</span>
                  </p>
                  <p className="mt-0.5 text-[10px] text-[#6d766f]">
                    Puedes subir varios archivos (ej: páginas del cuaderno en imagen o documento en PDF)
                  </p>
                </>
              )}
            </div>

            {/* List of Student Attached Files */}
            {attachments.length > 0 && (
              <div className="space-y-1.5 mt-2.5 max-h-40 overflow-y-auto">
                {attachments.map(file => (
                  <div
                    key={file.id}
                    className="flex items-center justify-between rounded-xl border border-[#bfe2c4] bg-[#fbfdfb] p-2.5"
                  >
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white border border-[#dfe6df]">
                        {getFileIcon(file.type)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-xs font-bold text-[#26302b]">
                          {file.name}
                        </p>
                        <div className="flex items-center gap-2 text-[10px] text-[#6d766f]">
                          <span>{formatFileSize(file.size)} · {file.type}</span>
                          {file.storageUrl && (
                            <span className="inline-flex items-center gap-0.5 rounded bg-[#eaf6ec] px-1.5 py-0.5 font-bold text-[#236a2d]" title="Alojado en Firebase Cloud Storage">
                              <Cloud className="h-2.5 w-2.5" />
                              <span>Cloud</span>
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0 ml-2">
                      <button
                        type="button"
                        onClick={e => {
                          e.stopPropagation();
                          downloadAttachedFile(file, activity.title);
                        }}
                        className="rounded-lg p-1.5 text-[#546057] hover:bg-[#eef2ee]"
                        title="Ver / Descargar"
                      >
                        <Download className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={e => {
                          e.stopPropagation();
                          handleRemoveAttachment(file.id);
                        }}
                        className="rounded-lg p-1.5 text-[#c6292e] hover:bg-[#fde7e7]"
                        title="Quitar"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Student Comment */}
          <div>
            <label className="block font-bold text-[#26302b] mb-1">
              Comentario u observación para el docente (opcional)
            </label>
            <textarea
              rows={2}
              placeholder="Ej: Profesor, adjunto el desarrollo de los 10 ejercicios del libro..."
              value={studentComment}
              onChange={e => setStudentComment(e.target.value)}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] focus:bg-white"
            />
          </div>

          {isAlreadyGraded && (
            <div className="rounded-xl border border-[#f5c400]/40 bg-[#fff7cc] p-3 text-[11px] text-[#735f00] font-semibold">
              Esta actividad ya fue calificada por el docente con {currentGrade?.score} pts. Si vuelves a enviar, el docente podrá revisar la nueva entrega.
            </div>
          )}

          {/* Buttons */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#dfe6df]">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2 font-bold text-[#6d766f] hover:bg-[#eef2ee]"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isProcessing || (attachments.length === 0 && !studentComment.trim())}
              className="flex items-center gap-1.5 rounded-xl bg-[#2f8b3c] px-5 py-2.5 font-bold text-white shadow-sm hover:bg-[#236a2d] transition disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
              <span>{currentGrade?.status === 'Entregado' ? 'Actualizar mi entrega' : 'Entregar tarea'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
