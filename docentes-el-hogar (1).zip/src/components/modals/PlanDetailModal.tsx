import React from 'react';
import { X, Printer, PenTool, Edit, Copy, Calendar, BookOpen } from 'lucide-react';
import { LessonPlan, ClassRoom } from '../../types';
import { formatDate } from '../../utils/storage';
import { HOGAR_LOGO } from '../../constants/initialData';

interface PlanDetailModalProps {
  plan: LessonPlan | null;
  classes?: ClassRoom[];
  onClose: () => void;
  onEdit: (plan: LessonPlan) => void;
  onDuplicate: (id: string) => void;
}

export const PlanDetailModal: React.FC<PlanDetailModalProps> = ({
  plan,
  classes = [],
  onClose,
  onEdit,
  onDuplicate
}) => {
  if (!plan) return null;

  const associatedClass = classes.find(c => c.id === plan.classId);

  const handlePrint = () => {
    const printWin = window.open('', '_blank');
    if (!printWin) {
      window.print();
      return;
    }

    const expectationsText = plan.expectations || plan.objective || '—';
    const standardText = plan.standard || plan.competency || '—';
    const conceptualText = plan.conceptualContent || plan.content || '—';
    const attitudinalText = plan.attitudinalContent || '—';
    const methodologyText = plan.methodology || plan.strategies || '—';
    const teachingStrategiesText = plan.teachingStrategies || plan.activities || '—';
    const resourcesText = plan.resources || '—';
    const reactivationText = plan.knowledgeReactivation || '—';
    const applicationText = plan.knowledgeApplication || '—';
    const organizationText = plan.knowledgeOrganization || '—';
    const evaluationText = plan.evaluationStrategies || plan.evaluation || '—';

    printWin.document.write(`
      <!DOCTYPE html>
      <html lang="es">
        <head>
          <meta charset="utf-8" />
          <title>${plan.title} - Planificación de Clases</title>
          <style>
            @page {
              size: letter landscape;
              margin: 10mm;
            }
            body {
              font-family: Arial, Helvetica, sans-serif;
              color: #000;
              margin: 0;
              padding: 10px;
              background: #fff;
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
            .header-container {
              text-align: center;
              margin-bottom: 12px;
            }
            .school-title {
              font-size: 16pt;
              font-weight: 900;
              color: #006680;
              letter-spacing: 1px;
              margin: 0;
              text-transform: uppercase;
            }
            .doc-title {
              font-size: 17pt;
              font-weight: 900;
              color: #000;
              text-decoration: underline;
              margin: 3px 0 0 0;
              text-transform: uppercase;
            }
            table.plan-table {
              width: 100%;
              border-collapse: collapse;
              border: 1.5px solid #000;
              table-layout: fixed;
            }
            table.plan-table td, table.plan-table th {
              border: 1.5px solid #000;
              padding: 6px 8px;
              vertical-align: top;
              font-size: 10pt;
              line-height: 1.35;
            }
            .field-label {
              color: #b30000;
              font-weight: bold;
              display: block;
              margin-bottom: 4px;
              font-size: 10pt;
            }
            .field-content {
              white-space: pre-wrap;
              color: #000;
              font-size: 9.5pt;
            }
            .signatures {
              margin-top: 25px;
              display: flex;
              justify-content: space-around;
              font-size: 10pt;
              font-weight: bold;
              text-align: center;
            }
            .signature-line {
              border-top: 1px solid #000;
              width: 200px;
              margin: 40px auto 4px auto;
            }
          </style>
        </head>
        <body>
          <div class="header-container">
            <h1 class="school-title">ESCUELA HOGAR DE AMOR Y ESPERANZA</h1>
            <h2 class="doc-title">PLANIFICACIÓN DE CLASES</h2>
          </div>

          <table class="plan-table">
            <!-- Row 1 -->
            <tr>
              <td style="width: 3%; text-align: center;">&nbsp;</td>
              <td style="width: 25%;">
                <span class="field-label">Espacio Curricular</span>
                <span class="field-content">${plan.subject || ''}</span>
              </td>
              <td style="width: 30%;">
                <span class="field-label">Tema</span>
                <span class="field-content">${plan.topic || ''}</span>
              </td>
              <td style="width: 16%;">
                <span class="field-label">Nivel</span>
                <span class="field-content">${plan.level || ''}</span>
              </td>
              <td style="width: 11%;">
                <span class="field-label">Grado</span>
                <span class="field-content">${plan.grade || ''}</span>
              </td>
              <td style="width: 15%;">
                <span class="field-label">Fecha</span>
                <span class="field-content">${formatDate(plan.date)}</span>
              </td>
            </tr>

            <!-- Row 2 -->
            <tr>
              <td colspan="3" style="height: 80px;">
                <span class="field-label">Expectativas de Logro</span>
                <div class="field-content">${expectationsText}</div>
              </td>
              <td colspan="3" style="height: 80px;">
                <span class="field-label">Estándar</span>
                <div class="field-content">${standardText}</div>
              </td>
            </tr>

            <!-- Row 3 -->
            <tr>
              <td colspan="6" style="height: 85px;">
                <div style="margin-bottom: 8px;">
                  <span class="field-label">1. Contenido Conceptual</span>
                  <div class="field-content">${conceptualText}</div>
                </div>
                <div>
                  <span class="field-label">2. Contenido Actitudinal</span>
                  <div class="field-content">${attitudinalText}</div>
                </div>
              </td>
            </tr>

            <!-- Row 4 -->
            <tr>
              <td colspan="2" style="width: 33.33%; height: 85px;">
                <span class="field-label">2. Metodología</span>
                <div class="field-content">${methodologyText}</div>
              </td>
              <td colspan="2" style="width: 33.33%; height: 85px;">
                <span class="field-label">3. Estrategias de Enseñanza</span>
                <div class="field-content">${teachingStrategiesText}</div>
              </td>
              <td colspan="2" style="width: 33.34%; height: 85px;">
                <span class="field-label">4. Recursos</span>
                <div class="field-content">${resourcesText}</div>
              </td>
            </tr>

            <!-- Row 5 -->
            <tr>
              <td colspan="2" style="width: 33.33%; height: 85px;">
                <span class="field-label">5. Reactivación de los conocimientos</span>
                <div class="field-content">${reactivationText}</div>
              </td>
              <td colspan="2" style="width: 33.33%; height: 85px;">
                <span class="field-label">6. Aplicación de los Conocimientos</span>
                <div class="field-content">${applicationText}</div>
              </td>
              <td colspan="2" style="width: 33.34%; height: 85px;">
                <span class="field-label">7. Organización del Conocimiento</span>
                <div class="field-content">${organizationText}</div>
              </td>
            </tr>

            <!-- Row 6 -->
            <tr>
              <td colspan="6" style="height: 75px;">
                <span class="field-label">8. Estrategias de Evaluación</span>
                <div class="field-content">${evaluationText}</div>
              </td>
            </tr>
          </table>

          <div class="signatures">
            <div>
              <div class="signature-line"></div>
              <span>Docente Titular</span>
            </div>
            <div>
              <div class="signature-line"></div>
              <span>Coordinación Académica</span>
            </div>
            <div>
              <div class="signature-line"></div>
              <span>Dirección Escolar</span>
            </div>
          </div>
        </body>
      </html>
    `);

    printWin.document.close();
    printWin.focus();
    setTimeout(() => {
      printWin.print();
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-2 sm:p-4 backdrop-blur-xs overflow-y-auto">
      <div className="relative my-6 max-h-[94vh] w-full max-w-5xl flex flex-col rounded-3xl border border-[#dfe6df] bg-white shadow-2xl overflow-hidden">
        
        {/* Header Bar */}
        <div className="flex items-center justify-between border-b border-[#dfe6df] bg-[#f8faf8] px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#2f8b3c] text-white shadow-xs">
              <PenTool className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-[#26302b]">{plan.title}</h3>
              <div className="flex flex-wrap items-center gap-2 text-xs text-[#6d766f]">
                <span className="font-bold text-[#2f8b3c]">{plan.subject}</span>
                <span>·</span>
                <span>Grado {plan.grade}</span>
                <span>·</span>
                <span>{formatDate(plan.date)}</span>
                {associatedClass && (
                  <span className="rounded-md bg-[#eaf6ec] px-2 py-0.5 text-[10px] font-extrabold text-[#236a2d]">
                    Clase: {associatedClass.name}
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 rounded-xl bg-[#26302b] px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-[#39483f] transition"
              title="Imprimir o exportar en formato oficial"
            >
              <Printer className="h-4 w-4" />
              <span>Imprimir / PDF</span>
            </button>
            <button
              onClick={() => onEdit(plan)}
              className="flex items-center gap-1.5 rounded-xl border border-[#dfe6df] bg-white px-3 py-2 text-xs font-bold text-[#236a2d] hover:bg-[#eaf6ec] transition"
              title="Editar esta planificación"
            >
              <Edit className="h-4 w-4" />
              <span className="hidden sm:inline">Editar</span>
            </button>
            <button
              onClick={() => onDuplicate(plan.id)}
              className="flex items-center gap-1.5 rounded-xl border border-[#dfe6df] bg-white px-3 py-2 text-xs font-bold text-[#546057] hover:bg-[#eef2ee] transition"
              title="Duplicar planificación"
            >
              <Copy className="h-4 w-4" />
              <span className="hidden sm:inline">Duplicar</span>
            </button>
            <button
              onClick={onClose}
              className="rounded-xl p-1.5 text-[#6d766f] hover:bg-[#eef2ee] transition"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Content Body - Official Format Preview */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          
          {/* Official Document Sheet */}
          <div className="rounded-2xl border-2 border-black bg-white p-4 sm:p-6 shadow-md overflow-x-auto">
            
            {/* School Title */}
            <div className="text-center py-2 mb-4">
              <h2 className="text-base sm:text-lg font-black tracking-wider text-[#006680] uppercase">
                ESCUELA HOGAR DE AMOR Y ESPERANZA
              </h2>
              <h1 className="text-lg sm:text-xl font-black tracking-tight text-black underline underline-offset-4 uppercase mt-0.5">
                PLANIFICACIÓN DE CLASES
              </h1>
            </div>

            {/* Official Table */}
            <div className="border border-black divide-y divide-black text-black">
              
              {/* Row 1: Espacio Curricular | Tema | Nivel | Grado | Fecha */}
              <div className="grid grid-cols-1 sm:grid-cols-12 divide-y sm:divide-y-0 sm:divide-x divide-black bg-[#fafafa]">
                <div className="sm:col-span-1 flex items-center justify-center p-2 bg-white">
                  <span className="text-[10px] font-bold text-[#6d766f]">#</span>
                </div>
                <div className="sm:col-span-3 p-2.5">
                  <span className="block text-[11px] font-bold text-[#b30000]">
                    Espacio Curricular
                  </span>
                  <span className="font-semibold text-xs text-black">
                    {plan.subject || '—'}
                  </span>
                </div>
                <div className="sm:col-span-3 p-2.5">
                  <span className="block text-[11px] font-bold text-[#b30000]">
                    Tema
                  </span>
                  <span className="font-semibold text-xs text-black">
                    {plan.topic || '—'}
                  </span>
                </div>
                <div className="sm:col-span-2 p-2.5">
                  <span className="block text-[11px] font-bold text-[#b30000]">
                    Nivel
                  </span>
                  <span className="font-semibold text-xs text-black">
                    {plan.level || 'Educación Básica'}
                  </span>
                </div>
                <div className="sm:col-span-1 p-2.5">
                  <span className="block text-[11px] font-bold text-[#b30000]">
                    Grado
                  </span>
                  <span className="font-semibold text-xs text-black">
                    {plan.grade || '—'}
                  </span>
                </div>
                <div className="sm:col-span-2 p-2.5">
                  <span className="block text-[11px] font-bold text-[#b30000]">
                    Fecha
                  </span>
                  <span className="font-semibold text-xs text-black">
                    {formatDate(plan.date)}
                  </span>
                </div>
              </div>

              {/* Row 2: Expectativas de Logro | Estándar */}
              <div className="grid grid-cols-1 sm:grid-cols-12 divide-y sm:divide-y-0 sm:divide-x divide-black">
                <div className="sm:col-span-5 p-3">
                  <span className="block text-[11px] font-bold text-[#b30000] mb-1">
                    Expectativas de Logro
                  </span>
                  <p className="text-xs text-black whitespace-pre-wrap leading-relaxed">
                    {plan.expectations || plan.objective || 'Sin expectativas especificadas.'}
                  </p>
                </div>
                <div className="sm:col-span-7 p-3">
                  <span className="block text-[11px] font-bold text-[#b30000] mb-1">
                    Estándar
                  </span>
                  <p className="text-xs text-black whitespace-pre-wrap leading-relaxed">
                    {plan.standard || plan.competency || 'Sin estándar curricular especificado.'}
                  </p>
                </div>
              </div>

              {/* Row 3: 1. Contenido Conceptual | 2. Contenido Actitudinal */}
              <div className="p-3 space-y-3">
                <div>
                  <span className="block text-[11px] font-bold text-[#b30000] mb-1">
                    1. Contenido Conceptual
                  </span>
                  <p className="text-xs text-black whitespace-pre-wrap leading-relaxed">
                    {plan.conceptualContent || plan.content || 'Sin contenido conceptual especificado.'}
                  </p>
                </div>
                <div>
                  <span className="block text-[11px] font-bold text-[#b30000] mb-1">
                    2. Contenido Actitudinal
                  </span>
                  <p className="text-xs text-black whitespace-pre-wrap leading-relaxed">
                    {plan.attitudinalContent || 'Sin contenido actitudinal especificado.'}
                  </p>
                </div>
              </div>

              {/* Row 4: 2. Metodología | 3. Estrategias de Enseñanza | 4. Recursos */}
              <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-black">
                <div className="p-3">
                  <span className="block text-[11px] font-bold text-[#b30000] mb-1">
                    2. Metodología
                  </span>
                  <p className="text-xs text-black whitespace-pre-wrap leading-relaxed">
                    {plan.methodology || plan.strategies || 'Metodología activa y participativa.'}
                  </p>
                </div>
                <div className="p-3">
                  <span className="block text-[11px] font-bold text-[#b30000] mb-1">
                    3. Estrategias de Enseñanza
                  </span>
                  <p className="text-xs text-black whitespace-pre-wrap leading-relaxed">
                    {plan.teachingStrategies || plan.activities || 'Sin estrategias especificadas.'}
                  </p>
                </div>
                <div className="p-3">
                  <span className="block text-[11px] font-bold text-[#b30000] mb-1">
                    4. Recursos
                  </span>
                  <p className="text-xs text-black whitespace-pre-wrap leading-relaxed">
                    {plan.resources || 'Sin recursos especificados.'}
                  </p>
                </div>
              </div>

              {/* Row 5: 5. Reactivación de los conocimientos | 6. Aplicación de los Conocimientos | 7. Organización del Conocimiento */}
              <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-black">
                <div className="p-3">
                  <span className="block text-[11px] font-bold text-[#b30000] mb-1">
                    5. Reactivación de los conocimientos
                  </span>
                  <p className="text-xs text-black whitespace-pre-wrap leading-relaxed">
                    {plan.knowledgeReactivation || 'Sin reactivación de conocimientos previa.'}
                  </p>
                </div>
                <div className="p-3">
                  <span className="block text-[11px] font-bold text-[#b30000] mb-1">
                    6. Aplicación de los Conocimientos
                  </span>
                  <p className="text-xs text-black whitespace-pre-wrap leading-relaxed">
                    {plan.knowledgeApplication || 'Sin aplicación práctica de conocimientos.'}
                  </p>
                </div>
                <div className="p-3">
                  <span className="block text-[11px] font-bold text-[#b30000] mb-1">
                    7. Organización del Conocimiento
                  </span>
                  <p className="text-xs text-black whitespace-pre-wrap leading-relaxed">
                    {plan.knowledgeOrganization || 'Sin síntesis u organización del conocimiento.'}
                  </p>
                </div>
              </div>

              {/* Row 6: 8. Estrategias de Evaluación */}
              <div className="p-3">
                <span className="block text-[11px] font-bold text-[#b30000] mb-1">
                  8. Estrategias de Evaluación
                </span>
                <p className="text-xs text-black whitespace-pre-wrap leading-relaxed">
                  {plan.evaluationStrategies || plan.evaluation || 'Sin estrategias de evaluación especificadas.'}
                </p>
              </div>

            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
