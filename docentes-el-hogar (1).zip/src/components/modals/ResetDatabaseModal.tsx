import React, { useState } from 'react';
import { X, KeyRound, Eye, EyeOff, AlertTriangle, Trash2 } from 'lucide-react';
import { ADMIN_MASTER_KEY } from '../../constants/initialData';

interface ResetDatabaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

export const ResetDatabaseModal: React.FC<ResetDatabaseModalProps> = ({
  isOpen,
  onClose,
  onConfirm
}) => {
  const [keyInput, setKeyInput] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleClose = () => {
    setKeyInput('');
    setError('');
    setShowKey(false);
    onClose();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanKey = keyInput.trim();

    if (!cleanKey) {
      setError('Por favor ingresa la llave maestra institucional.');
      return;
    }

    if (cleanKey !== ADMIN_MASTER_KEY) {
      setError('Llave maestra incorrecta. No tienes autorización para vaciar la base de datos.');
      return;
    }

    onConfirm();
    handleClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-md rounded-3xl border border-[#f5c6c6] bg-white p-6 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#dfe6df] pb-4 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#fde7e7] text-[#c6292e]">
              <Trash2 className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-[#26302b]">
                Vaciar Base de Datos
              </h3>
              <p className="text-[11px] font-semibold text-[#8a3333]">
                Confirmación de seguridad con llave maestra
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="rounded-xl p-1 text-[#6d766f] hover:bg-[#eef2ee] transition"
            title="Cerrar"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Warning Banner */}
        <div className="mb-4 rounded-2xl border border-[#f5c6c6] bg-[#fff5f5] p-3.5">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="h-4 w-4 shrink-0 text-[#c6292e] mt-0.5" />
            <div className="text-xs text-[#522525] leading-relaxed">
              <p className="font-extrabold text-[#c6292e] mb-1">¡Advertencia irreversible!</p>
              <p>
                Esta acción eliminará todas las clases, alumnos, asistencias, calificaciones,
                actividades, planificaciones y recursos escolares para iniciar el sistema totalmente desde cero.
              </p>
            </div>
          </div>
        </div>

        <p className="text-xs text-[#5d685f] mb-4">
          Para confirmar el vaciado completo del sistema, debes introducir la <strong>llave maestra</strong> institucional.
        </p>

        {error && (
          <div className="mb-4 rounded-xl border border-[#f5c6c6] bg-[#fde7e7] p-3 text-xs font-bold text-[#a92028]">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-[#26302b] mb-1.5 flex items-center gap-1.5">
              <KeyRound className="h-3.5 w-3.5 text-[#c6292e]" />
              <span>Llave Maestra Institucional *</span>
            </label>
            <div className="relative">
              <input
                type={showKey ? 'text' : 'password'}
                autoFocus
                required
                placeholder="Ingresa la llave maestra"
                value={keyInput}
                onChange={e => {
                  setKeyInput(e.target.value);
                  setError('');
                }}
                className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-3.5 py-2.5 pr-10 text-xs font-mono font-bold tracking-wider text-[#26302b] outline-none transition focus:border-[#c6292e] focus:bg-white focus:ring-2 focus:ring-[#c6292e]/20"
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute right-3 top-2.5 text-[#6d766f] hover:text-[#26302b] transition"
                tabIndex={-1}
              >
                {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-[#dfe6df]">
            <button
              type="button"
              onClick={handleClose}
              className="rounded-xl px-4 py-2.5 text-xs font-bold text-[#6d766f] hover:bg-[#eef2ee] transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2.5 text-xs font-extrabold text-white shadow-sm hover:bg-[#9f1d24] transition active:scale-[0.98]"
            >
              <Trash2 className="h-3.5 w-3.5" />
              <span>Vaciar base de datos</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
