import React, { useState } from 'react';
import {
  X,
  Calendar,
  Lock,
  Unlock,
  Play,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ShieldCheck,
  CheckSquare,
  BarChart3,
  Users,
  Info
} from 'lucide-react';
import { AppData, ParcialId, AcademicPeriod, PeriodsConfig, User } from '../../types';
import { formatDate, getTodayDateString } from '../../utils/storage';

interface PeriodsControlModalProps {
  isOpen: boolean;
  periodsConfig: PeriodsConfig;
  data: AppData;
  currentUser: User;
  onClose: () => void;
  onStartPeriod: (parcialId: ParcialId) => void;
  onClosePeriod: (parcialId: ParcialId) => void;
  onReopenPeriod: (parcialId: ParcialId) => void;
}

export const PeriodsControlModal: React.FC<PeriodsControlModalProps> = ({
  isOpen,
  periodsConfig,
  data,
  currentUser,
  onClose,
  onStartPeriod,
  onClosePeriod,
  onReopenPeriod
}) => {
  const [confirmAction, setConfirmAction] = useState<{
    type: 'start' | 'close' | 'reopen';
    period: AcademicPeriod;
  } | null>(null);

  if (!isOpen) return null;

  const handleExecuteConfirm = () => {
    if (!confirmAction) return;
    if (confirmAction.type === 'start') {
      onStartPeriod(confirmAction.period.id);
    } else if (confirmAction.type === 'close') {
      onClosePeriod(confirmAction.period.id);
    } else if (confirmAction.type === 'reopen') {
      onReopenPeriod(confirmAction.period.id);
    }
    setConfirmAction(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-3xl rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-2xl sm:p-7 max-h-[92vh] flex flex-col">
        {/* Modal Header */}
        <div className="flex items-start justify-between border-b border-[#dfe6df] pb-4 shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <span className="rounded-full bg-[#eaf6ec] px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-[#236a2d]">
                Coordinación Académica
              </span>
              <span className="rounded-full bg-[#f7f8f6] border border-[#dfe6df] px-2 py-0.5 text-[10px] font-bold text-[#6d766f]">
                Año Escolar 4 Parciales
              </span>
            </div>
            <h2 className="mt-1 text-xl font-black text-[#26302b] sm:text-2xl">
              Control y Gestión de Parciales
            </h2>
            <p className="mt-0.5 text-xs text-[#6d766f]">
              Inicia o cierra los parciales del año lectivo para habilitar o proteger el registro de notas y tareas.
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl p-1.5 text-[#6d766f] transition hover:bg-[#eef2ee]"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Informative Guidance Banner */}
        <div className="my-4 rounded-2xl border border-[#2f8b3c]/20 bg-[#f4faf4] p-3.5 text-xs text-[#236a2d] shrink-0">
          <div className="flex items-start gap-2.5">
            <Info className="h-4 w-4 shrink-0 mt-0.5 text-[#2f8b3c]" />
            <div className="space-y-1">
              <strong className="block font-bold">Reglas de seguridad institucional:</strong>
              <p className="text-[11px] text-[#344b37] leading-relaxed">
                • <strong>Parcial Activo:</strong> Docentes y estudiantes pueden trabajar con normalidad (crear tareas, entregar asignaciones y registrar notas).<br />
                • <strong>Parcial Cerrado:</strong> Pasa a modo de <em>solo lectura</em>. Toda la información histórica permanece intacta para consulta y reportes, pero nadie puede alterar las calificaciones ni subir nuevo contenido.
              </p>
            </div>
          </div>
        </div>

        {/* 4 Parciales Grid */}
        <div className="overflow-y-auto space-y-4 pr-1 py-1 flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {periodsConfig.periods.map(period => {
              const isActive = period.status === 'active';
              const isClosed = period.status === 'closed';
              const isUpcoming = period.status === 'upcoming';

              const actCount = data.activities.filter(a => (a.parcial || 1) === period.id).length;
              const evalCount = data.grades.filter(g => (g.parcial || 1) === period.id).length;

              return (
                <div
                  key={period.id}
                  className={`relative flex flex-col justify-between rounded-2xl border p-4.5 transition ${
                    isActive
                      ? 'border-[#2f8b3c] bg-white shadow-md ring-2 ring-[#2f8b3c]/15'
                      : isClosed
                      ? 'border-[#dfe6df] bg-[#fafbfa]'
                      : 'border-[#dfe6df]/80 bg-[#fcfdfc] opacity-85'
                  }`}
                >
                  <div>
                    {/* Period Card Header */}
                    <div className="flex items-center justify-between gap-2 border-b border-[#edf1ed] pb-3 mb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-base font-black text-[#26302b]">{period.name}</h3>
                          {isActive && (
                            <span className="flex items-center gap-1 rounded-full bg-[#2f8b3c] px-2 py-0.5 text-[9px] font-extrabold text-white animate-pulse">
                              <span className="h-1.5 w-1.5 rounded-full bg-white" />
                              ACTIVO EN CURSO
                            </span>
                          )}
                          {isClosed && (
                            <span className="flex items-center gap-1 rounded-full bg-[#6d766f] px-2 py-0.5 text-[9px] font-bold text-white">
                              <Lock className="h-2.5 w-2.5" />
                              CERRADO (Solo lectura)
                            </span>
                          )}
                          {isUpcoming && (
                            <span className="rounded-full bg-[#eef2ee] px-2 py-0.5 text-[9px] font-bold text-[#6d766f]">
                              EN ESPERA
                            </span>
                          )}
                        </div>
                        <div className="mt-1 text-[11px] text-[#6d766f]">
                          {isActive && 'Abierto actualmente para docentes y alumnos.'}
                          {isClosed && (
                            <span>
                              Cerrado el {formatDate(period.closedDate || getTodayDateString())}
                              {period.closedBy ? ` por ${period.closedBy}` : ''}.
                            </span>
                          )}
                          {isUpcoming && 'Aún no iniciado por coordinación.'}
                        </div>
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="grid grid-cols-2 gap-2 text-xs mb-4">
                      <div className="rounded-xl border border-[#edf1ed] bg-white p-2.5">
                        <div className="flex items-center gap-1.5 text-[10px] text-[#6d766f] font-bold">
                          <CheckSquare className="h-3 w-3 text-[#2f8b3c]" />
                          Actividades
                        </div>
                        <div className="mt-1 text-base font-black text-[#26302b]">{actCount}</div>
                      </div>
                      <div className="rounded-xl border border-[#edf1ed] bg-white p-2.5">
                        <div className="flex items-center gap-1.5 text-[10px] text-[#6d766f] font-bold">
                          <BarChart3 className="h-3 w-3 text-[#c6292e]" />
                          Evaluaciones
                        </div>
                        <div className="mt-1 text-base font-black text-[#26302b]">{evalCount}</div>
                      </div>
                    </div>
                  </div>

                  {/* Actions for this Parcial */}
                  <div className="pt-2 border-t border-[#edf1ed] flex items-center justify-between gap-2">
                    {isActive ? (
                      <button
                        onClick={() => setConfirmAction({ type: 'close', period })}
                        className="w-full flex items-center justify-center gap-1.5 rounded-xl bg-[#c6292e] py-2 px-3 text-xs font-bold text-white shadow-xs transition hover:bg-[#9f1d24]"
                      >
                        <Lock className="h-3.5 w-3.5" />
                        <span>Cerrar {period.name}</span>
                      </button>
                    ) : isClosed ? (
                      <div className="w-full flex items-center gap-2">
                        <button
                          onClick={() => setConfirmAction({ type: 'start', period })}
                          className="flex-1 flex items-center justify-center gap-1 rounded-xl bg-[#2f8b3c] py-2 px-2.5 text-xs font-bold text-white shadow-xs transition hover:bg-[#236a2d]"
                          title="Volver a poner este parcial como el activo de trabajo"
                        >
                          <Play className="h-3 w-3" />
                          <span>Activar</span>
                        </button>
                        <button
                          onClick={() => setConfirmAction({ type: 'reopen', period })}
                          className="flex items-center justify-center gap-1 rounded-xl border border-[#dfe6df] bg-white py-2 px-2.5 text-xs font-bold text-[#6d766f] hover:bg-[#f7f8f6]"
                          title="Habilitar temporalmente para corrección"
                        >
                          <Unlock className="h-3 w-3" />
                          <span>Reabrir</span>
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setConfirmAction({ type: 'start', period })}
                        className="w-full flex items-center justify-center gap-1.5 rounded-xl bg-[#2f8b3c] py-2 px-3 text-xs font-bold text-white shadow-xs transition hover:bg-[#236a2d]"
                      >
                        <Play className="h-3.5 w-3.5" />
                        <span>Iniciar {period.name}</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Confirmation Sub-Modal Overlay */}
        {confirmAction && (
          <div className="absolute inset-0 z-20 flex items-center justify-center rounded-3xl bg-black/60 p-4 backdrop-blur-xs">
            <div className="w-full max-w-md rounded-2xl bg-white p-5 shadow-2xl border border-[#dfe6df]">
              <div className="flex items-center gap-3 mb-3">
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-xl ${
                    confirmAction.type === 'close'
                      ? 'bg-[#fde7e7] text-[#c6292e]'
                      : 'bg-[#eaf6ec] text-[#2f8b3c]'
                  }`}
                >
                  {confirmAction.type === 'close' ? (
                    <Lock className="h-5 w-5" />
                  ) : (
                    <Play className="h-5 w-5" />
                  )}
                </div>
                <div>
                  <h4 className="text-sm font-black text-[#26302b]">
                    {confirmAction.type === 'close'
                      ? `¿Confirmas el cierre del ${confirmAction.period.name}?`
                      : confirmAction.type === 'start'
                      ? `¿Iniciar el ${confirmAction.period.name}?`
                      : `¿Reabrir el ${confirmAction.period.name}?`}
                  </h4>
                  <span className="text-[11px] text-[#6d766f]">
                    Acción de Coordinación Académica
                  </span>
                </div>
              </div>

              <p className="text-xs text-[#546057] leading-relaxed mb-4">
                {confirmAction.type === 'close' && (
                  <>
                    Al cerrar el <strong>{confirmAction.period.name}</strong>, ningún docente ni alumno podrá modificar notas, subir tareas o editar actividades en este período. Quedará en <strong>modo de solo lectura</strong> para consulta histórica.
                  </>
                )}
                {confirmAction.type === 'start' && (
                  <>
                    El <strong>{confirmAction.period.name}</strong> se establecerá como el período activo. El parcial previamente activo quedará cerrado para proteger su historial.
                  </>
                )}
                {confirmAction.type === 'reopen' && (
                  <>
                    Se reabrirá el <strong>{confirmAction.period.name}</strong> para que los docentes autorizados puedan corregir o actualizar calificaciones bajo la supervisión de coordinación.
                  </>
                )}
              </p>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#dfe6df]">
                <button
                  type="button"
                  onClick={() => setConfirmAction(null)}
                  className="rounded-xl border border-[#dfe6df] bg-white px-3.5 py-1.5 text-xs font-bold text-[#6d766f] hover:bg-[#f7f8f6]"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleExecuteConfirm}
                  className={`rounded-xl px-4 py-1.5 text-xs font-bold text-white shadow-xs ${
                    confirmAction.type === 'close'
                      ? 'bg-[#c6292e] hover:bg-[#9f1d24]'
                      : 'bg-[#2f8b3c] hover:bg-[#236a2d]'
                  }`}
                >
                  {confirmAction.type === 'close'
                    ? 'Sí, cerrar parcial'
                    : confirmAction.type === 'start'
                    ? 'Sí, iniciar parcial'
                    : 'Sí, reabrir'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="mt-4 pt-3 border-t border-[#dfe6df] flex items-center justify-between text-xs shrink-0">
          <div className="flex items-center gap-1.5 text-[#6d766f]">
            <ShieldCheck className="h-4 w-4 text-[#2f8b3c]" />
            <span>Coordinador responsable: <strong>{currentUser.name}</strong></span>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-4 py-1.5 text-xs font-bold text-[#26302b] hover:bg-[#eef2ee]"
          >
            Listo
          </button>
        </div>
      </div>
    </div>
  );
};
