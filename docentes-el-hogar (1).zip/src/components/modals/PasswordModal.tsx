import React, { useState } from 'react';
import { X, Key } from 'lucide-react';
import { User } from '../../types';

interface PasswordModalProps {
  isOpen: boolean;
  user: User | null;
  onClose: () => void;
  onSave: (userId: string, newPass: string) => void;
}

export const PasswordModal: React.FC<PasswordModalProps> = ({
  isOpen,
  user,
  onClose,
  onSave
}) => {
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [error, setError] = useState('');

  if (!isOpen || !user) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPass.trim()) {
      setError('Por favor ingresa una nueva contraseña');
      return;
    }
    if (newPass !== confirmPass) {
      setError('Las contraseñas no coinciden');
      return;
    }

    onSave(user.id, newPass.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-sm rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#dfe6df] pb-4 mb-4">
          <div className="flex items-center gap-2">
            <Key className="h-5 w-5 text-[#c6292e]" />
            <h3 className="text-base font-black text-[#26302b]">Cambiar contraseña</h3>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-[#6d766f] hover:bg-[#eef2ee]">
            <X className="h-4 w-4" />
          </button>
        </div>

        <p className="text-xs text-[#6d766f] mb-4">
          Actualizar clave de acceso para <strong>{user.name}</strong> (@{user.username}).
        </p>

        {error && (
          <div className="mb-3 rounded-xl bg-[#fde7e7] p-2.5 text-xs font-bold text-[#c6292e]">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="block font-bold text-[#26302b] mb-1">Nueva contraseña</label>
            <input
              type="password"
              required
              placeholder="Nueva contraseña"
              value={newPass}
              onChange={e => {
                setNewPass(e.target.value);
                setError('');
              }}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-bold text-[#26302b] mb-1">Confirmar contraseña</label>
            <input
              type="password"
              required
              placeholder="Confirmar contraseña"
              value={confirmPass}
              onChange={e => {
                setConfirmPass(e.target.value);
                setError('');
              }}
              className="w-full rounded-xl border border-[#dfe6df] bg-[#f7f8f6] p-2.5 outline-none focus:border-[#2f8b3c] focus:bg-white"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#dfe6df]">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2 font-bold text-[#6d766f] hover:bg-[#eef2ee]"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="rounded-xl bg-[#c6292e] px-4 py-2 font-bold text-white shadow-sm hover:bg-[#9f1d24]"
            >
              Actualizar clave
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
