import React, { useState, useEffect } from 'react';
import { X, LayoutGrid, UserCheck, GraduationCap, BookOpen, Users, CheckCircle2 } from 'lucide-react';
import { ClassRoom, User, Student } from '../../types';
import { STANDARD_GRADES, COMMON_SUBJECTS } from '../../constants/initialData';

interface ClassModalProps {
  isOpen: boolean;
  classItem?: ClassRoom | null;
  teachers?: User[];
  students?: Student[];
  defaultGrade?: string;
  onClose: () => void;
  onSave: (classData: Omit<ClassRoom, 'id'> & { id?: string }) => void;
}

export const ClassModal: React.FC<ClassModalProps> = ({
  isOpen,
  classItem,
  teachers = [],
  students = [],
  defaultGrade = '',
  onClose,
  onSave
}) => {
  const [grade, setGrade] = useState('7mo');
  const [isCustomGrade, setIsCustomGrade] = useState(false);
  const [customGrade, setCustomGrade] = useState('');
  const [section, setSection] = useState('A');
  const [subject, setSubject] = useState('Matemáticas');
  const [name, setName] = useState('');
  const [year, setYear] = useState('2026');
  const [teacherId, setTeacherId] = useState('');

  const teacherList = teachers.filter(u => u.role === 'teacher');

  // Determine active grade string
  const activeGrade = isCustomGrade ? customGrade.trim() : grade;

  // Calculate matching students for this grade and section
  const matchingStudentsCount = students.filter(
    s => s.status !== 'Inactivo' && (s.grade === activeGrade || (!s.grade && activeGrade === '7mo'))
  ).length;

  useEffect(() => {
    if (classItem) {
      const isStd = STANDARD_GRADES.some(g => g.value === classItem.grade);
      if (isStd) {
        setGrade(classItem.grade || '7mo');
        setIsCustomGrade(false);
      } else {
        setGrade('custom');
        setIsCustomGrade(true);
        setCustomGrade(classItem.grade || '');
      }
      setSection(classItem.section || 'A');
      setYear(classItem.year || '2026');
      setSubject(classItem.subject || '');
      setName(classItem.name || '');
      setTeacherId(classItem.teacherId || teacherList[0]?.id || '');
    } else {
      const initialGrade = defaultGrade || '7mo';
      const isStd = STANDARD_GRADES.some(g => g.value === initialGrade);
      if (isStd) {
        setGrade(initialGrade);
        setIsCustomGrade(false);
      } else if (initialGrade) {
        setGrade('custom');
        setIsCustomGrade(true);
        setCustomGrade(initialGrade);
      } else {
        setGrade('7mo');
        setIsCustomGrade(false);
      }
      setSection('A');
      setYear(new Date().getFullYear().toString());
      setSubject('Matemáticas');
      setName(`Matemáticas ${initialGrade || '7mo'} A`);
      setTeacherId(teacherList[0]?.id || '');
    }
  }, [classItem, isOpen, defaultGrade, teachers]);

  if (!isOpen) return null;

  const handleSelectSubject = (subj: string) => {
    setSubject(subj);
    const gr = activeGrade || '7mo';
    const sec = section || 'A';
    setName(`${subj} ${gr} ${sec}`.trim());
  };

  const handleGradeChange = (newGrade: string) => {
    if (newGrade === 'custom') {
      setIsCustomGrade(true);
      setCustomGrade('');
    } else {
      setIsCustomGrade(false);
      setGrade(newGrade);
      const subj = subject.trim() || 'Clase';
      setName(`${subj} ${newGrade} ${section || 'A'}`.trim());
    }
  };

  const handleSectionChange = (newSec: string) => {
    setSection(newSec);
    const gr = activeGrade || '7mo';
    const subj = subject.trim() || 'Clase';
    setName(`${subj} ${gr} ${newSec}`.trim());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalGrade = activeGrade || '7mo';
    const finalName = name.trim() || `${subject || 'Clase'} ${finalGrade} ${section}`.trim();

    onSave({
      id: classItem ? classItem.id : undefined,
      name: finalName,
      grade: finalGrade,
      section: section.trim() || 'A',
      year: year.trim() || new Date().getFullYear().toString(),
      subject: subject.trim(),
      teacherId: teacherId || undefined
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-lg rounded-3xl border border-[#dfe6df] bg-white p-6 shadow-2xl my-8">
        <div className="flex items-center justify-between border-b border-[#dfe6df] pb-4 mb-5">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#fde7e7] text-[#c6292e]">
              <GraduationCap className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-[#26302b]">
                {classItem ? 'Editar clase por grado' : 'Asignar clase por grado'}
              </h3>
              <p className="text-[11px] text-[#6d766f]">
                Primero define el grado escolar y luego la materia con su docente asignado.
              </p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-[#6d766f] hover:bg-[#eef2ee]">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* PASO 1: SELECCIÓN DE GRADO Y SECCIÓN */}
          <div className="rounded-2xl border border-[#bfe2c4] bg-[#f4fbf5] p-4">
            <div className="flex items-center gap-1.5 mb-2.5">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#2f8b3c] text-[10px] font-black text-white">
                1
              </span>
              <strong className="text-xs font-black uppercase tracking-wider text-[#1e5826]">
                Paso 1: Seleccionar el Grado y Sección
              </strong>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="block font-bold text-[#26302b] mb-1 flex items-center justify-between">
                  <span>Grado escolar *</span>
                  {isCustomGrade && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsCustomGrade(false);
                        setGrade('7mo');
                      }}
                      className="text-[10px] text-[#2f8b3c] hover:underline"
                    >
                      Ver lista estándar
                    </button>
                  )}
                </label>

                {!isCustomGrade ? (
                  <select
                    value={grade}
                    onChange={e => handleGradeChange(e.target.value)}
                    className="w-full rounded-xl border border-[#dfe6df] bg-white p-2.5 outline-none focus:border-[#2f8b3c] font-black text-[#26302b]"
                  >
                    <optgroup label="Grados de la Institución">
                      {STANDARD_GRADES.map(g => (
                        <option key={g.value} value={g.value}>
                          {g.label} ({g.value})
                        </option>
                      ))}
                    </optgroup>
                    <option value="custom">+ Personalizar otro grado...</option>
                  </select>
                ) : (
                  <input
                    type="text"
                    placeholder="Ej: Pre-Básica, Kinder, etc."
                    value={customGrade}
                    onChange={e => {
                      setCustomGrade(e.target.value);
                      const subj = subject.trim() || 'Clase';
                      setName(`${subj} ${e.target.value} ${section || 'A'}`.trim());
                    }}
                    required
                    className="w-full rounded-xl border border-[#dfe6df] bg-white p-2.5 outline-none focus:border-[#2f8b3c] font-bold text-[#26302b]"
                  />
                )}
              </div>

              <div>
                <label className="block font-bold text-[#26302b] mb-1">Sección *</label>
                <input
                  type="text"
                  placeholder="Ej: A, B, C o Única"
                  value={section}
                  onChange={e => handleSectionChange(e.target.value)}
                  required
                  className="w-full rounded-xl border border-[#dfe6df] bg-white p-2.5 outline-none focus:border-[#2f8b3c] font-bold text-[#26302b]"
                />
              </div>
            </div>

            {/* Matched students feedback */}
            <div className="mt-3 flex items-center gap-2 rounded-xl bg-white/90 px-3 py-2 text-[11px] text-[#26302b] border border-[#d2ebd6]">
              <Users className="h-4 w-4 text-[#2f8b3c] shrink-0" />
              <span>
                <strong>{matchingStudentsCount} alumnos</strong> registrados en este grado se sincronizarán automáticamente con esta clase.
              </span>
            </div>
          </div>

          {/* PASO 2: ASIGNATURA Y MATERIA */}
          <div className="rounded-2xl border border-[#dfe6df] bg-[#fcfdfc] p-4 space-y-3">
            <div className="flex items-center gap-1.5 mb-1">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#c6292e] text-[10px] font-black text-white">
                2
              </span>
              <strong className="text-xs font-black uppercase tracking-wider text-[#26302b]">
                Paso 2: Materia y Nombre de la Clase
              </strong>
            </div>

            {/* Quick subject suggestions */}
            <div>
              <label className="block text-[11px] font-bold text-[#6d766f] mb-1.5">
                Selecciona una materia o escribe una personalizada:
              </label>
              <div className="flex flex-wrap gap-1.5">
                {COMMON_SUBJECTS.map(subj => {
                  const isSelected = subject.toLowerCase() === subj.toLowerCase();
                  return (
                    <button
                      key={subj}
                      type="button"
                      onClick={() => handleSelectSubject(subj)}
                      className={`rounded-lg px-2.5 py-1 text-[11px] font-semibold transition ${
                        isSelected
                          ? 'bg-[#2f8b3c] text-white shadow-xs'
                          : 'bg-[#eef2ee] text-[#26302b] hover:bg-[#dfe6df]'
                      }`}
                    >
                      {subj}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="block font-bold text-[#26302b] mb-1">Materia / Asignatura *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Matemáticas"
                  value={subject}
                  onChange={e => handleSelectSubject(e.target.value)}
                  className="w-full rounded-xl border border-[#dfe6df] bg-white p-2.5 outline-none focus:border-[#2f8b3c] font-medium text-[#26302b]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#26302b] mb-1">Año lectivo</label>
                <input
                  type="text"
                  placeholder="2026"
                  value={year}
                  onChange={e => setYear(e.target.value)}
                  className="w-full rounded-xl border border-[#dfe6df] bg-white p-2.5 outline-none focus:border-[#2f8b3c]"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-[#26302b] mb-1">Nombre visible de la clase *</label>
              <input
                type="text"
                required
                placeholder="Ej: Matemáticas 7mo A"
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full rounded-xl border border-[#dfe6df] bg-white p-2.5 outline-none focus:border-[#2f8b3c] font-bold text-[#26302b]"
              />
              <span className="mt-1 block text-[10px] text-[#6d766f]">
                Nombre con el que los docentes y alumnos identificarán el grupo en el sistema.
              </span>
            </div>
          </div>

          {/* PASO 3: DOCENTE TITULAR */}
          <div className="rounded-2xl border border-[#dfe6df] bg-[#fcfdfc] p-4">
            <div className="flex items-center gap-1.5 mb-2.5">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#536057] text-[10px] font-black text-white">
                3
              </span>
              <strong className="text-xs font-black uppercase tracking-wider text-[#26302b]">
                Paso 3: Docente Titular Asignado
              </strong>
            </div>

            <label className="block font-bold text-[#26302b] mb-1 flex items-center gap-1.5">
              <UserCheck className="h-3.5 w-3.5 text-[#2f8b3c]" />
              <span>Docente a cargo de la clase *</span>
            </label>
            <select
              value={teacherId}
              onChange={e => setTeacherId(e.target.value)}
              required
              className="w-full rounded-xl border border-[#dfe6df] bg-white p-2.5 outline-none focus:border-[#2f8b3c] font-bold text-[#26302b]"
            >
              {teacherList.length === 0 && (
                <option value="">No hay docentes registrados todavía en el sistema</option>
              )}
              {teacherList.map(t => (
                <option key={t.id} value={t.id}>
                  {t.name} (@{t.username})
                </option>
              ))}
            </select>
            <span className="mt-1.5 block text-[10px] text-[#6d766f]">
              El docente tendrá acceso completo para calificar tareas, tomar asistencia y subir contenidos para los alumnos de este grado.
            </span>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#dfe6df]">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2 font-bold text-[#6d766f] hover:bg-[#eef2ee]"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 rounded-xl bg-[#c6292e] px-4 py-2 font-bold text-white shadow-sm hover:bg-[#9f1d24]"
            >
              <CheckCircle2 className="h-4 w-4" />
              <span>{classItem ? 'Guardar cambios' : 'Asignar clase a este grado'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
