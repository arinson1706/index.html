import React from 'react';
import {
  X,
  FileCode,
  Download,
  FileText,
  Globe,
  Terminal,
  FolderArchive,
  CheckCircle2,
  ExternalLink,
  Code
} from 'lucide-react';
import { AppData, PeriodsConfig } from '../../types';
import {
  downloadOriginalIndexHtml,
  downloadStandaloneAppHtml,
  downloadAcademicReportHtml
} from '../../utils/htmlExporter';

interface DownloadCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: AppData;
  periodsConfig?: PeriodsConfig;
}

export const DownloadCodeModal: React.FC<DownloadCodeModalProps> = ({
  isOpen,
  onClose,
  data,
  periodsConfig
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-fade-in">
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border border-[#dfe6df] bg-white p-6 sm:p-8 shadow-2xl">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[#dfe6df] pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#eaf6ec] text-[#236a2d] border border-[#2f8b3c]/20 shadow-xs">
              <FileCode className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#2f8b3c]">
                  Exportación de Código
                </span>
                <span className="rounded-full bg-[#eef2ee] px-2 py-0.5 text-[10px] font-bold text-[#465249]">
                  HTML5 & Web
                </span>
              </div>
              <h2 className="text-xl font-black text-[#26302b]">Descargar Código en HTML</h2>
              <p className="text-xs text-[#6d766f]">
                Elige la opción que mejor se adapte a tus necesidades de descarga o respaldo.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-xl text-[#6d766f] transition hover:bg-[#eef2ee] hover:text-[#26302b]"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Options List */}
        <div className="mt-6 space-y-4">
          {/* Option 1: Standalone HTML (Recommended) */}
          <div className="rounded-2xl border-2 border-[#2f8b3c] bg-[#f7fbf8] p-5 shadow-xs transition hover:shadow-md">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#2f8b3c] text-white">
                    <Globe className="h-4 w-4" />
                  </span>
                  <h3 className="text-sm font-extrabold text-[#26302b]">
                    Aplicación Autónoma en un solo archivo HTML
                  </h3>
                  <span className="rounded-full bg-[#2f8b3c] px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-wider text-white">
                    Recomendado
                  </span>
                </div>
                <p className="text-xs text-[#546057] leading-relaxed">
                  Genera un único archivo <strong>.html</strong> 100% independiente con interfaz interactiva, diseño de El Hogar y toda la base de datos embebida (alumnos, clases, notas y foros). Se abre directamente con doble clic en cualquier navegador y sin internet.
                </p>
              </div>

              <button
                onClick={() => downloadStandaloneAppHtml(data)}
                className="flex items-center justify-center gap-2 rounded-xl bg-[#2f8b3c] px-4 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-[#236a2d] transition shrink-0 active:scale-95"
              >
                <Download className="h-4 w-4" />
                <span>Descargar (.html)</span>
              </button>
            </div>
          </div>

          {/* Option 2: index.html source file */}
          <div className="rounded-2xl border border-[#dfe6df] bg-white p-5 shadow-xs transition hover:border-[#2f8b3c]/60">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#eef2ee] text-[#26302b]">
                    <Code className="h-4 w-4" />
                  </span>
                  <h3 className="text-sm font-extrabold text-[#26302b]">
                    Archivo fuente "index.html" del proyecto
                  </h3>
                </div>
                <p className="text-xs text-[#6d766f] leading-relaxed">
                  Descarga el archivo <code>index.html</code> original que sirve de plantilla y punto de entrada al proyecto React/Vite, incluyendo metadatos, fuentes tipográficas y scripts.
                </p>
              </div>

              <button
                onClick={downloadOriginalIndexHtml}
                className="flex items-center justify-center gap-2 rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-4 py-2.5 text-xs font-bold text-[#26302b] hover:bg-[#eef2ee] transition shrink-0 active:scale-95"
              >
                <Download className="h-4 w-4 text-[#2f8b3c]" />
                <span>Descargar index.html</span>
              </button>
            </div>
          </div>

          {/* Option 3: Academic report in HTML */}
          <div className="rounded-2xl border border-[#dfe6df] bg-white p-5 shadow-xs transition hover:border-[#2f8b3c]/60">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#eef2ee] text-[#26302b]">
                    <FileText className="h-4 w-4" />
                  </span>
                  <h3 className="text-sm font-extrabold text-[#26302b]">
                    Reporte Académico Oficial en HTML
                  </h3>
                </div>
                <p className="text-xs text-[#6d766f] leading-relaxed">
                  Documento formal estructurado en formato HTML con las listas oficiales de estudiantes, clases asignadas y docentes, listo para imprimir o guardar como PDF.
                </p>
              </div>

              <button
                onClick={() => downloadAcademicReportHtml(data, periodsConfig)}
                className="flex items-center justify-center gap-2 rounded-xl border border-[#dfe6df] bg-[#f7f8f6] px-4 py-2.5 text-xs font-bold text-[#26302b] hover:bg-[#eef2ee] transition shrink-0 active:scale-95"
              >
                <Download className="h-4 w-4 text-[#2f8b3c]" />
                <span>Descargar Reporte</span>
              </button>
            </div>
          </div>

          {/* Instructions Box: Full Source Code (ZIP) via AI Studio */}
          <div className="rounded-2xl border border-[#dfe6df] bg-[#f7f8f6] p-5">
            <div className="flex items-start gap-3">
              <FolderArchive className="h-5 w-5 text-[#2f8b3c] shrink-0 mt-0.5" />
              <div className="space-y-2 text-xs text-[#465249]">
                <h4 className="font-extrabold text-[#26302b]">
                  ¿Deseas descargar TODO el código fuente del proyecto completo (ZIP)?
                </h4>
                <p className="leading-relaxed">
                  Esta plataforma está desarrollada como una aplicación web profesional en <strong>HTML5, React 19, TypeScript y Tailwind CSS</strong>.
                </p>
                <ul className="space-y-1.5 list-disc pl-4 text-[#546057]">
                  <li>
                    <strong>Desde la barra superior de Google AI Studio:</strong> Busca el botón de descarga / exportación (ícono de código o flecha de descarga en la cabecera de la ventana) para descargar el paquete <strong>.ZIP</strong> con todos los archivos de la aplicación (código, imágenes, configuración).
                  </li>
                  <li>
                    <strong>Para ejecutarlo en tu computadora:</strong> Descomprime el archivo descargado, abre una terminal en la carpeta y escribe:
                    <div className="mt-1.5 rounded-lg bg-[#26302b] p-2 font-mono text-[11px] text-[#eaf6ec]">
                      npm install<br />
                      npm run dev
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 flex justify-end border-t border-[#dfe6df] pt-4">
          <button
            onClick={onClose}
            className="rounded-xl bg-[#26302b] px-5 py-2.5 text-xs font-bold text-white transition hover:bg-[#3d4b43]"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
