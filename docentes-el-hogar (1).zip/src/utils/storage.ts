import { AppData, GradeEvaluation, Student, AttendanceRecord, ClassRoom, Activity, PeriodsConfig, ParcialId, AcademicPeriod } from '../types';
import { INITIAL_DATA, DEFAULT_PERIODS_CONFIG } from '../constants/initialData';

export const STORAGE_KEY = 'hogar-amor-esperanza-v1';
export const SESSION_KEY = 'hogar-amor-esperanza-session';
const IDB_NAME = 'hogar-amor-esperanza-files';
const IDB_STORE = 'files';

export function normalizeAppData(parsed: any): AppData {
  if (!parsed || typeof parsed !== 'object') {
    return JSON.parse(JSON.stringify(INITIAL_DATA));
  }
  const classes: ClassRoom[] = Array.isArray(parsed.classes) ? parsed.classes : [];
  const students: Student[] = (Array.isArray(parsed.students) ? parsed.students : []).map((s: Student) => {
    const gradeClasses = classes.filter(c => matchGrade(s.grade, c.grade));
    const enrolledSet = new Set<string>([
      ...(s.enrolledClassIds || []),
      ...gradeClasses.map(c => c.id)
    ]);
    if (s.classId) enrolledSet.add(s.classId);
    return {
      ...s,
      classId: s.classId || gradeClasses[0]?.id || '',
      enrolledClassIds: Array.from(enrolledSet)
    };
  });

  const periodsConfig: PeriodsConfig =
    parsed.periodsConfig && Array.isArray(parsed.periodsConfig.periods) && parsed.periodsConfig.periods.length > 0
      ? parsed.periodsConfig
      : DEFAULT_PERIODS_CONFIG;

  const rawActivities: Activity[] = Array.isArray(parsed.activities) ? parsed.activities : [];
  const activities: Activity[] = rawActivities.map(a => ({
    ...a,
    parcial: a.parcial || 1
  }));

  const rawGrades: GradeEvaluation[] = Array.isArray(parsed.grades) ? parsed.grades : [];
  const grades: GradeEvaluation[] = rawGrades.map(g => ({
    ...g,
    parcial: g.parcial || 1
  }));

  const forumTopics =
    Array.isArray(parsed.forumTopics) && parsed.forumTopics.length > 0
      ? parsed.forumTopics
      : INITIAL_DATA.forumTopics || [];

  const forumComments =
    Array.isArray(parsed.forumComments) && parsed.forumComments.length > 0
      ? parsed.forumComments
      : INITIAL_DATA.forumComments || [];

  return {
    users: Array.isArray(parsed.users) ? parsed.users : INITIAL_DATA.users,
    classes,
    students,
    resources: Array.isArray(parsed.resources) ? parsed.resources : [],
    plans: Array.isArray(parsed.plans) ? parsed.plans : [],
    activities,
    forumTopics,
    forumComments,
    grades,
    attendance: parsed.attendance && typeof parsed.attendance === 'object' ? parsed.attendance : {},
    events: Array.isArray(parsed.events) ? parsed.events : [],
    periodsConfig
  };
}

export function loadAppData(): AppData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      saveAppData(INITIAL_DATA);
      return JSON.parse(JSON.stringify(INITIAL_DATA));
    }
    const parsed = JSON.parse(raw);
    return normalizeAppData(parsed);
  } catch (err) {
    console.error('Error loading app data from localStorage:', err);
    return JSON.parse(JSON.stringify(INITIAL_DATA));
  }
}

export function saveAppData(data: AppData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (err) {
    console.error('Error saving app data to localStorage:', err);
  }
}

export const INACTIVITY_TIMEOUT_MS = 2 * 60 * 60 * 1000; // 2 horas (7,200,000 ms)

export function loadActiveSession(): string | null {
  try {
    const raw = sessionStorage.getItem(SESSION_KEY) || localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed?.userId) return null;

    // Verificar si la sesión superó las 2 horas de inactividad
    const now = Date.now();
    const lastActivity =
      typeof parsed.lastActivityAt === 'number'
        ? parsed.lastActivityAt
        : parsed.loginAt
        ? new Date(parsed.loginAt).getTime()
        : now;

    if (now - lastActivity > INACTIVITY_TIMEOUT_MS) {
      // Sesión expirada por inactividad
      clearActiveSession();
      return null;
    }

    return parsed.userId;
  } catch {
    return null;
  }
}

export function saveActiveSession(userId: string): void {
  try {
    const now = Date.now();
    const payload = JSON.stringify({
      userId,
      loginAt: new Date(now).toISOString(),
      lastActivityAt: now
    });
    sessionStorage.setItem(SESSION_KEY, payload);
    localStorage.setItem(SESSION_KEY, payload);
  } catch (err) {
    console.error('Error saving session:', err);
  }
}

/**
 * Actualiza la marca temporal de la última actividad del usuario.
 */
export function updateSessionActivity(): void {
  try {
    const raw = sessionStorage.getItem(SESSION_KEY) || localStorage.getItem(SESSION_KEY);
    if (!raw) return;
    const parsed = JSON.parse(raw);
    if (!parsed || !parsed.userId) return;

    parsed.lastActivityAt = Date.now();
    const payload = JSON.stringify(parsed);
    sessionStorage.setItem(SESSION_KEY, payload);
    localStorage.setItem(SESSION_KEY, payload);
  } catch (err) {
    console.error('Error updating session activity:', err);
  }
}

/**
 * Retorna true si la sesión actual ha sobrepasado las 2 horas de inactividad.
 */
export function isSessionExpired(): boolean {
  try {
    const raw = sessionStorage.getItem(SESSION_KEY) || localStorage.getItem(SESSION_KEY);
    if (!raw) return true;
    const parsed = JSON.parse(raw);
    if (!parsed?.userId) return true;

    const now = Date.now();
    const lastActivity =
      typeof parsed.lastActivityAt === 'number'
        ? parsed.lastActivityAt
        : parsed.loginAt
        ? new Date(parsed.loginAt).getTime()
        : now;

    return now - lastActivity > INACTIVITY_TIMEOUT_MS;
  } catch {
    return true;
  }
}

/**
 * Loads current logged user object from active session
 */
export function loadSession(): import('../types').User | null {
  try {
    const userId = loadActiveSession();
    if (!userId) return null;
    const appData = loadAppData();
    const user = appData.users.find(u => u.id === userId);
    return user || null;
  } catch {
    return null;
  }
}

export function saveSession(user: import('../types').User): void {
  saveActiveSession(user.id);
}

// Aliases for convenience
export const loadData = loadAppData;
export const saveData = saveAppData;
export const clearSession = clearActiveSession;
export const saveFileBlob = storeFileBlob;
export const getFileBlob = retrieveFileBlob;

/**
 * Closes the active session without touching ANY stored school data.
 * All classes, students, grades, plans and resources remain 100% intact.
 */
export function clearActiveSession(): void {
  try {
    sessionStorage.removeItem(SESSION_KEY);
    localStorage.removeItem(SESSION_KEY);
  } catch (err) {
    console.error('Error clearing session:', err);
  }
}

// IndexedDB File Helpers with fallback
function openIndexedDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      return reject(new Error('IndexedDB not supported'));
    }
    const req = window.indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(IDB_STORE)) {
        db.createObjectStore(IDB_STORE);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function storeFileBlob(id: string, file: File | Blob): Promise<boolean> {
  try {
    const db = await openIndexedDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).put(file, id);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    return false;
  }
}

export async function retrieveFileBlob(id: string): Promise<Blob | null> {
  try {
    const db = await openIndexedDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const req = tx.objectStore(IDB_STORE).get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(tx.error);
    });
  } catch {
    return null;
  }
}

export async function deleteFileBlob(id: string): Promise<void> {
  try {
    const db = await openIndexedDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // ignore
  }
}

export function generateId(prefix = 'item'): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 7)}`;
}

export function getInitials(name = ''): string {
  return name
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .map(w => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase() || 'DH';
}

export function formatDate(dateString?: string): string {
  if (!dateString) return '—';
  try {
    const parts = dateString.split('-');
    if (parts.length === 3) {
      const [year, month, day] = parts;
      return `${day}/${month}/${year}`;
    }
    return dateString;
  } catch {
    return dateString;
  }
}

export function formatFileSize(bytes = 0): string {
  if (!bytes || bytes <= 0) return '—';
  const units = ['B', 'KB', 'MB', 'GB'];
  let val = bytes;
  let unitIndex = 0;
  while (val >= 1024 && unitIndex < units.length - 1) {
    val /= 1024;
    unitIndex++;
  }
  return `${val.toFixed(unitIndex === 0 ? 0 : 1)} ${units[unitIndex]}`;
}

export function getTodayDateString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Academic calculations
const ORDINAL_MAP: Record<string, string> = {
  primer: '1', primero: '1', primera: '1', '1ro': '1', '1ero': '1', '1ra': '1',
  segundo: '2', segunda: '2', '2do': '2', '2da': '2',
  tercer: '3', tercero: '3', trasera: '3', '3ro': '3', '3ero': '3', '3ra': '3',
  cuarto: '4', cuarta: '4', '4to': '4', '4ta': '4',
  quinto: '5', quinta: '5', '5to': '5', '5ta': '5',
  sexto: '6', sexta: '6', '6to': '6', '6ta': '6',
  septimo: '7', septima: '7', '7mo': '7', '7ma': '7',
  octavo: '8', octava: '8', '8vo': '8', '8va': '8',
  noveno: '9', novena: '9', '9no': '9', '9na': '9',
  decimo: '10', decima: '10', '10mo': '10', '10ma': '10',
  undecimo: '11', undecima: '11', once: '11', '11mo': '11', '11ma': '11',
  duodecimo: '12', duodecima: '12', doce: '12', '12mo': '12', '12ma': '12'
};

export function normalizeGrade(grade?: string): string {
  if (!grade) return '';
  const clean = grade
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');

  // Check for ordinals in the words
  for (const [key, num] of Object.entries(ORDINAL_MAP)) {
    const regex = new RegExp(`\\b${key}\\b`, 'i');
    if (regex.test(clean) || clean.startsWith(key)) {
      return num;
    }
  }

  // Check for any number in the string (e.g. "7mo", "7", "grado 7", "7mo basica")
  const numMatch = clean.match(/\d+/);
  if (numMatch) {
    return numMatch[0];
  }

  // Non-numeric fallback (e.g. "preescolar", "kinder")
  return clean.replace(/[^a-z0-9]/g, '');
}

/**
 * Compares two grade identifiers to check if they represent the same academic grade level.
 * Handles exact matches, standard shortforms ("7mo", "7mo Básica", "7"), and textual names ("Séptimo").
 */
export function matchGrade(gradeA?: string, gradeB?: string): boolean {
  if (!gradeA || !gradeB) return false;
  const normA = normalizeGrade(gradeA);
  const normB = normalizeGrade(gradeB);
  if (!normA || !normB) return false;
  return normA === normB;
}

export function matchSection(secA?: string, secB?: string): boolean {
  const sA = (secA || '').trim().toLowerCase();
  const sB = (secB || '').trim().toLowerCase();
  if (!sA || !sB) return true;
  if (sA === 'única' || sA === 'unica' || sB === 'única' || sB === 'unica' || sA === 'todas' || sB === 'todas') return true;
  return sA === sB;
}

/**
 * Determines if a student belongs to a class.
 * Every student assigned to a grade is automatically enrolled in ALL classes assigned to that grade.
 */
export function isStudentInClass(student: Student, classItem: ClassRoom): boolean {
  if (!student || !classItem) return false;

  // 1. Direct classId match
  if (student.classId === classItem.id) return true;

  // 2. Explicit enrolledClassIds array
  if (Array.isArray(student.enrolledClassIds) && student.enrolledClassIds.includes(classItem.id)) {
    return true;
  }

  // 3. Match by grade: every class assigned to the student's grade automatically enrolls the student
  if (matchGrade(student.grade, classItem.grade)) {
    return true;
  }

  return false;
}

export function calculateStudentAverage(
  studentId: string,
  classId: string,
  grades: GradeEvaluation[],
  activities: Activity[] = [],
  parcial?: number
): number {
  const classGrades = grades.filter(
    g => g.classId === classId && (!parcial || (g.parcial || 1) === parcial)
  );
  const classActivities = (activities || []).filter(
    a => a.classId === classId && (!parcial || (a.parcial || 1) === parcial)
  );
  if (classGrades.length === 0 && classActivities.length === 0) return 0;

  let totalWeight = 0;
  let weightedScoreSum = 0;

  // 1. Standard Evaluations
  classGrades.forEach(grade => {
    const weight = Number(grade.value) > 0 ? Number(grade.value) : (grade.scale === 10 ? 10 : 100);
    const rawScore = Number(grade.scores?.[studentId] ?? 0);
    // Normalize to 0 - 100 percentage scale
    const normalizedScore = grade.scale === 10 ? rawScore * 10 : rawScore;
    totalWeight += weight;
    weightedScoreSum += normalizedScore * weight;
  });

  // 2. Class Activities & Homework
  classActivities.forEach(activity => {
    const maxVal = Number(activity.value) > 0 ? Number(activity.value) : 100;
    const weight = maxVal;
    const rawScore = Number(
      activity.scores?.[studentId] ?? activity.studentGrades?.[studentId]?.score ?? 0
    );
    // Normalize to 0 - 100 percentage scale
    const normalizedScore = Math.min(100, Math.max(0, (rawScore / maxVal) * 100));
    totalWeight += weight;
    weightedScoreSum += normalizedScore * weight;
  });

  return totalWeight > 0 ? Math.round(weightedScoreSum / totalWeight) : 0;
}

export function calculateClassAverage(
  classItemOrId: ClassRoom | string,
  students: Student[],
  grades: GradeEvaluation[],
  allClasses?: ClassRoom[],
  activities: Activity[] = [],
  parcial?: number
): number {
  const targetClass: ClassRoom | undefined =
    typeof classItemOrId === 'string'
      ? allClasses?.find(c => c.id === classItemOrId)
      : classItemOrId;

  const targetClassId = typeof classItemOrId === 'string' ? classItemOrId : classItemOrId.id;

  const classStudents = students.filter(s => {
    if (s.status === 'Inactivo') return false;
    if (targetClass) {
      return isStudentInClass(s, targetClass);
    }
    return s.classId === targetClassId;
  });

  if (classStudents.length === 0) return 0;
  const sum = classStudents.reduce(
    (acc, s) => acc + calculateStudentAverage(s.id, targetClassId, grades, activities, parcial),
    0
  );
  return Math.round(sum / classStudents.length);
}

export function calculateGlobalAverage(
  students: Student[],
  grades: GradeEvaluation[],
  activities: Activity[] = [],
  parcial?: number
): number {
  const activeStudents = students.filter(s => s.status !== 'Inactivo');
  if (activeStudents.length === 0) return 0;
  const sum = activeStudents.reduce(
    (acc, s) => acc + calculateStudentAverage(s.id, s.classId, grades, activities, parcial),
    0
  );
  return Math.round(sum / activeStudents.length);
}

export function isPeriodClosed(periodsConfig: PeriodsConfig | undefined, parcialId: ParcialId): boolean {
  if (!periodsConfig || !periodsConfig.periods) return false;
  const period = periodsConfig.periods.find(p => p.id === parcialId);
  return period ? period.status === 'closed' : false;
}

export function getActivePeriod(periodsConfig: PeriodsConfig | undefined): AcademicPeriod {
  const defaultPeriod: AcademicPeriod = {
    id: 1,
    name: '1er Parcial',
    status: 'active'
  };
  if (!periodsConfig || !periodsConfig.periods) return defaultPeriod;
  const active = periodsConfig.periods.find(p => p.status === 'active');
  return active || periodsConfig.periods.find(p => p.id === periodsConfig.activeParcial) || defaultPeriod;
}

export function calculateStudentAttendancePercentage(
  studentId: string,
  classId: string,
  attendance: AttendanceRecord
): number {
  if (!classId) return 0;
  const records = Object.entries(attendance)
    .filter(([key]) => key.endsWith(`:${classId}`))
    .map(([, stMap]) => stMap[studentId])
    .filter(Boolean);

  if (records.length === 0) return 100; // Default when no absences
  const presentCount = records.filter(r => r === 'P' || r === 'J').length;
  return Math.round((presentCount / records.length) * 100);
}
