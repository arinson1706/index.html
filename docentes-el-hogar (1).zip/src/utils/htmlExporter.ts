import { AppData, PeriodsConfig } from '../types';
import { HOGAR_LOGO } from '../constants/initialData';

/**
 * Descarga el archivo index.html original del proyecto
 */
export function downloadOriginalIndexHtml(): void {
  const htmlContent = `<!doctype html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Docentes El Hogar</title>
    <meta name="description" content="Espacio integral de gestión docente para Docentes El Hogar: clases, alumnos, recursos, planificación, calificaciones, asistencia y calendario." />
    <meta property="og:title" content="Docentes El Hogar" />
    <meta property="og:description" content="Espacio integral de gestión docente para Docentes El Hogar: clases, alumnos, recursos, planificación, calificaciones, asistencia y calendario." />
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary_large_image" />
    <link rel="icon" type="image/png" href="/logo.png" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  </head>
  <body class="bg-[#f7f8f6] text-[#26302b] antialiased selection:bg-[#2f8b3c]/20 selection:text-[#2f8b3c]">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`;

  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'index.html';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Descarga una versión HTML autónoma y autosuficiente con diseño, visualizador
 * y todos los datos actuales del sistema embebidos para abrir sin necesidad de servidor.
 */
export function downloadStandaloneAppHtml(data: AppData): void {
  const safeDataJson = JSON.stringify(data).replace(/</g, '\\u003c');
  const nowStr = new Date().toLocaleDateString('es-HN', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  const htmlContent = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Docentes El Hogar - Copia Local HTML</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary: #2f8b3c;
      --primary-dark: #236a2d;
      --accent-red: #c6292e;
      --accent-yellow: #f5c400;
      --bg: #f4f7f4;
      --card-bg: #ffffff;
      --text: #26302b;
      --text-muted: #6d766f;
      --border: #dfe6df;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
      background-color: var(--bg);
      color: var(--text);
      line-height: 1.5;
      padding-bottom: 40px;
    }
    header {
      background: #ffffff;
      border-bottom: 1px solid var(--border);
      padding: 16px 24px;
      position: sticky;
      top: 0;
      z-index: 20;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 16px;
    }
    .brand {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .brand img {
      width: 44px;
      height: 44px;
      border-radius: 12px;
      border: 1px solid var(--border);
      object-fit: contain;
      padding: 2px;
      background: white;
    }
    .brand h1 { font-size: 18px; font-weight: 800; color: var(--text); }
    .brand p { font-size: 11px; color: var(--text-muted); font-weight: 600; }
    .tricolor-bar {
      height: 4px;
      width: 100%;
      background: linear-gradient(90deg, var(--accent-red) 0% 46%, var(--accent-yellow) 46% 58%, var(--primary) 58% 100%);
    }
    .container {
      max-width: 1200px;
      margin: 24px auto;
      padding: 0 16px;
    }
    .badge {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 4px 10px;
      border-radius: 9999px;
      font-size: 11px;
      font-weight: 700;
    }
    .badge-green { background: #eaf6ec; color: var(--primary-dark); }
    .badge-red { background: #fde7e7; color: var(--accent-red); }
    .badge-gray { background: #eef2ee; color: var(--text-muted); }
    .hero-card {
      background: white;
      border: 1px solid var(--border);
      border-radius: 20px;
      padding: 24px;
      margin-bottom: 24px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    }
    .hero-title { font-size: 22px; font-weight: 800; margin-bottom: 6px; }
    .hero-desc { font-size: 13px; color: var(--text-muted); }
    .tabs {
      display: flex;
      gap: 8px;
      margin-bottom: 20px;
      flex-wrap: wrap;
      background: #eef2ee;
      padding: 6px;
      border-radius: 14px;
    }
    .tab-btn {
      padding: 8px 16px;
      border-radius: 10px;
      border: none;
      background: transparent;
      font-family: inherit;
      font-size: 12px;
      font-weight: 700;
      color: var(--text-muted);
      cursor: pointer;
      transition: all 0.15s ease;
    }
    .tab-btn.active {
      background: white;
      color: var(--text);
      box-shadow: 0 1px 3px rgba(0,0,0,0.06);
    }
    .tab-btn:hover:not(.active) { color: var(--text); }
    .grid-stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
      margin-bottom: 24px;
    }
    .stat-card {
      background: white;
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 16px;
    }
    .stat-num { font-size: 26px; font-weight: 800; color: var(--primary); }
    .stat-label { font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
    .table-container {
      background: white;
      border: 1px solid var(--border);
      border-radius: 16px;
      overflow-x: auto;
      margin-bottom: 24px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
      font-size: 12px;
    }
    th {
      background: #f7f8f6;
      padding: 12px 16px;
      font-weight: 800;
      color: var(--text-muted);
      border-bottom: 1px solid var(--border);
      text-transform: uppercase;
      font-size: 10px;
      letter-spacing: 0.5px;
    }
    td {
      padding: 12px 16px;
      border-bottom: 1px solid #f1f4f1;
      color: var(--text);
      vertical-align: middle;
    }
    tr:last-child td { border-bottom: none; }
    tr:hover td { background: #fafcfa; }
    .search-box {
      width: 100%;
      max-width: 320px;
      padding: 8px 12px;
      border: 1px solid var(--border);
      border-radius: 10px;
      font-family: inherit;
      font-size: 12px;
      outline: none;
      margin-bottom: 16px;
    }
    .search-box:focus { border-color: var(--primary); }
    .section-view { display: none; }
    .section-view.active { display: block; }
    .forum-card {
      background: white;
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 16px 20px;
      margin-bottom: 12px;
    }
    .forum-title { font-size: 15px; font-weight: 800; color: var(--text); margin-bottom: 4px; }
    .forum-meta { font-size: 11px; color: var(--text-muted); margin-bottom: 10px; display: flex; gap: 8px; flex-wrap: wrap; }
    .forum-desc { font-size: 13px; color: #465249; line-height: 1.5; white-space: pre-wrap; }
    .print-btn {
      background: var(--primary);
      color: white;
      border: none;
      padding: 8px 16px;
      border-radius: 10px;
      font-family: inherit;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
    }
    .print-btn:hover { background: var(--primary-dark); }
  </style>
</head>
<body>
  <div class="tricolor-bar"></div>
  <header>
    <div class="brand">
      <img src="${HOGAR_LOGO}" alt="Logo Docentes El Hogar">
      <div>
        <h1>Docentes El Hogar</h1>
        <p>Hogar de Amor y Esperanza · Versión Autónoma HTML</p>
      </div>
    </div>
    <div style="display: flex; gap: 8px; align-items: center;">
      <span class="badge badge-green">● Archivo HTML Autónomo</span>
      <button class="print-btn" onclick="window.print()">🖨️ Imprimir / Guardar PDF</button>
    </div>
  </header>

  <div class="container">
    <div class="hero-card">
      <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 12px;">
        <div>
          <span class="badge badge-gray" style="margin-bottom: 8px;">Copia Exportada en HTML</span>
          <h2 class="hero-title">Sistema Académico y Base de Datos Escolar</h2>
          <p class="hero-desc">Generado el <strong>${nowStr}</strong>. Este archivo HTML contiene todos los registros escolares y funciona directamente en tu navegador sin necesidad de conexión a internet.</p>
        </div>
      </div>
    </div>

    <!-- Navegación por pestañas -->
    <div class="tabs">
      <button class="tab-btn active" onclick="switchTab('resumen')">📊 Resumen General</button>
      <button class="tab-btn" onclick="switchTab('alumnos')">👥 Alumnos (<span id="count-students">0</span>)</button>
      <button class="tab-btn" onclick="switchTab('clases')">📚 Clases y Materias (<span id="count-classes">0</span>)</button>
      <button class="tab-btn" onclick="switchTab('docentes')">🎓 Docentes & Usuarios (<span id="count-users">0</span>)</button>
      <button class="tab-btn" onclick="switchTab('actividades')">📝 Actividades & Tareas (<span id="count-activities">0</span>)</button>
      <button class="tab-btn" onclick="switchTab('foro')">💬 Foros Escolares (<span id="count-forums">0</span>)</button>
      <button class="tab-btn" onclick="switchTab('calificaciones')">⭐ Calificaciones (<span id="count-grades">0</span>)</button>
    </div>

    <!-- TAB: RESUMEN -->
    <div id="view-resumen" class="section-view active">
      <div class="grid-stats">
        <div class="stat-card">
          <div class="stat-num" id="stat-students">0</div>
          <div class="stat-label">Alumnos Matriculados</div>
        </div>
        <div class="stat-card">
          <div class="stat-num" id="stat-classes">0</div>
          <div class="stat-label">Clases y Asignaturas</div>
        </div>
        <div class="stat-card">
          <div class="stat-num" id="stat-teachers">0</div>
          <div class="stat-label">Docentes Registrados</div>
        </div>
        <div class="stat-card">
          <div class="stat-num" id="stat-activities">0</div>
          <div class="stat-label">Tareas & Actividades</div>
        </div>
      </div>

      <div class="hero-card">
        <h3 style="font-size: 15px; font-weight: 800; margin-bottom: 10px;">Acerca de este archivo HTML</h3>
        <p style="font-size: 13px; color: var(--text-muted); line-height: 1.6;">
          Este archivo HTML contiene una copia estructurada de todo el código de datos de la institución <strong>Docentes El Hogar</strong>.
          Puedes guardarlo en una memoria USB, enviarlo por correo electrónico, abrirlo en cualquier teléfono, tableta o computadora sin necesidad de instalar programas adicionales.
        </p>
      </div>
    </div>

    <!-- TAB: ALUMNOS -->
    <div id="view-alumnos" class="section-view">
      <input type="text" class="search-box" id="search-students" placeholder="🔍 Buscar alumno por nombre o identidad..." oninput="filterStudents()">
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Nombre del Alumno</th>
              <th>Identidad / Código</th>
              <th>Grado</th>
              <th>Sección</th>
              <th>Usuario de Acceso</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody id="tbody-students"></tbody>
        </table>
      </div>
    </div>

    <!-- TAB: CLASES -->
    <div id="view-clases" class="section-view">
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Materia / Asignatura</th>
              <th>Grado</th>
              <th>Sección</th>
              <th>Docente Titular</th>
              <th>Horario</th>
            </tr>
          </thead>
          <tbody id="tbody-classes"></tbody>
        </table>
      </div>
    </div>

    <!-- TAB: DOCENTES -->
    <div id="view-docentes" class="section-view">
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Nombre Completo</th>
              <th>Usuario</th>
              <th>Rol en el Sistema</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody id="tbody-teachers"></tbody>
        </table>
      </div>
    </div>

    <!-- TAB: ACTIVIDADES -->
    <div id="view-actividades" class="section-view">
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Título de la Tarea / Actividad</th>
              <th>Tipo</th>
              <th>Clase</th>
              <th>Parcial</th>
              <th>Puntaje</th>
              <th>Fecha Límite</th>
            </tr>
          </thead>
          <tbody id="tbody-activities"></tbody>
        </table>
      </div>
    </div>

    <!-- TAB: FORO -->
    <div id="view-foro" class="section-view">
      <div id="forum-topics-container"></div>
    </div>

    <!-- TAB: CALIFICACIONES -->
    <div id="view-calificaciones" class="section-view">
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Alumno</th>
              <th>Clase</th>
              <th>Parcial</th>
              <th>Calificación Final</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody id="tbody-grades"></tbody>
        </table>
      </div>
    </div>
  </div>

  <script>
    const APP_DATA = ${safeDataJson};

    function init() {
      // Conteo inicial
      const students = APP_DATA.students || [];
      const classes = APP_DATA.classes || [];
      const users = APP_DATA.users || [];
      const activities = APP_DATA.activities || [];
      const forums = APP_DATA.forumTopics || [];
      const grades = APP_DATA.grades || [];
      const teachers = users.filter(u => u.role === 'teacher');

      document.getElementById('count-students').textContent = students.length;
      document.getElementById('count-classes').textContent = classes.length;
      document.getElementById('count-users').textContent = users.length;
      document.getElementById('count-activities').textContent = activities.length;
      document.getElementById('count-forums').textContent = forums.length;
      document.getElementById('count-grades').textContent = grades.length;

      document.getElementById('stat-students').textContent = students.length;
      document.getElementById('stat-classes').textContent = classes.length;
      document.getElementById('stat-teachers').textContent = teachers.length;
      document.getElementById('stat-activities').textContent = activities.length;

      renderStudents(students);
      renderClasses(classes);
      renderTeachers(users);
      renderActivities(activities);
      renderForums(forums);
      renderGrades(grades);
    }

    function renderStudents(list) {
      const tbody = document.getElementById('tbody-students');
      if (!list.length) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:#999; padding:20px;">No hay alumnos registrados</td></tr>';
        return;
      }
      tbody.innerHTML = list.map(s => \`
        <tr>
          <td><strong>\${s.name || ''}</strong></td>
          <td><code>\${s.dni || s.id || ''}</code></td>
          <td><span class="badge badge-gray">\${s.grade || '-'}</span></td>
          <td>\${s.section || 'A'}</td>
          <td>\${s.username ? '<code>' + s.username + '</code>' : '<span style="color:#aaa">Sin credencial</span>'}</td>
          <td><span class="badge badge-green">Activo</span></td>
        </tr>
      \`).join('');
    }

    function filterStudents() {
      const q = document.getElementById('search-students').value.toLowerCase();
      const filtered = (APP_DATA.students || []).filter(s =>
        (s.name || '').toLowerCase().includes(q) ||
        (s.dni || '').toLowerCase().includes(q)
      );
      renderStudents(filtered);
    }

    function renderClasses(list) {
      const tbody = document.getElementById('tbody-classes');
      if (!list.length) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:#999; padding:20px;">No hay clases registradas</td></tr>';
        return;
      }
      tbody.innerHTML = list.map(c => {
        const teacher = (APP_DATA.users || []).find(u => u.id === c.teacherId);
        return \`
          <tr>
            <td><strong>\${c.name || ''}</strong></td>
            <td><span class="badge badge-gray">\${c.grade || '-'}</span></td>
            <td>\${c.section || 'A'}</td>
            <td>\${teacher ? teacher.name : (c.teacherName || 'Sin asignar')}</td>
            <td>\${c.schedule || 'Lunes a Viernes'}</td>
          </tr>
        \`;
      }).join('');
    }

    function renderTeachers(list) {
      const tbody = document.getElementById('tbody-teachers');
      tbody.innerHTML = list.map(u => {
        const roleLabel = u.role === 'admin' ? 'Administrador' : u.role === 'teacher' ? 'Docente' : 'Alumno';
        const roleBadge = u.role === 'admin' ? 'badge-red' : u.role === 'teacher' ? 'badge-green' : 'badge-gray';
        return \`
          <tr>
            <td><strong>\${u.name || ''}</strong></td>
            <td><code>\${u.username || ''}</code></td>
            <td><span class="badge \${roleBadge}">\${roleLabel}</span></td>
            <td><span class="badge \${u.active ? 'badge-green' : 'badge-gray'}">\${u.active ? 'Activo' : 'Inactivo'}</span></td>
          </tr>
        \`;
      }).join('');
    }

    function renderActivities(list) {
      const tbody = document.getElementById('tbody-activities');
      if (!list.length) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:#999; padding:20px;">No hay actividades registradas</td></tr>';
        return;
      }
      tbody.innerHTML = list.map(a => {
        const cls = (APP_DATA.classes || []).find(c => c.id === a.classId);
        return \`
          <tr>
            <td><strong>\${a.title || ''}</strong></td>
            <td><span class="badge badge-gray">\${a.type || 'Tarea'}</span></td>
            <td>\${cls ? cls.name : 'Todas las clases'}</td>
            <td>Parcial \${a.parcial || 1}</td>
            <td><strong>\${a.maxScore || 10} pts</strong></td>
            <td>\${a.dueDate || '-'}</td>
          </tr>
        \`;
      }).join('');
    }

    function renderForums(list) {
      const container = document.getElementById('forum-topics-container');
      if (!list.length) {
        container.innerHTML = '<div class="hero-card" style="text-align:center; color:#999;">No hay temas de debate creados en el foro</div>';
        return;
      }
      container.innerHTML = list.map(t => {
        const author = (APP_DATA.users || []).find(u => u.id === t.authorId);
        const comments = (APP_DATA.forumComments || []).filter(c => c.topicId === t.id);
        return \`
          <div class="forum-card">
            <div class="forum-title">\${t.title || ''}</div>
            <div class="forum-meta">
              <span class="badge badge-green">Por: \${t.authorName || (author ? author.name : 'Docente')}</span>
              <span class="badge badge-gray">Parcial \${t.parcial || 1}</span>
              <span class="badge badge-gray">\${comments.length} opiniones de alumnos</span>
            </div>
            <div class="forum-desc">\${t.description || ''}</div>
          </div>
        \`;
      }).join('');
    }

    function renderGrades(list) {
      const tbody = document.getElementById('tbody-grades');
      if (!list.length) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:#999; padding:20px;">No hay notas registradas aún</td></tr>';
        return;
      }
      tbody.innerHTML = list.map(g => {
        const student = (APP_DATA.students || []).find(s => s.id === g.studentId);
        const cls = (APP_DATA.classes || []).find(c => c.id === g.classId);
        const score = typeof g.score === 'number' ? g.score : (g.totalScore || 0);
        const approved = score >= 70;
        return \`
          <tr>
            <td><strong>\${student ? student.name : 'Alumno #' + g.studentId}</strong></td>
            <td>\${cls ? cls.name : '-'}</td>
            <td>Parcial \${g.parcial || 1}</td>
            <td><strong>\${score}%</strong></td>
            <td><span class="badge \${approved ? 'badge-green' : 'badge-red'}">\${approved ? 'Aprobado' : 'Reprobado'}</span></td>
          </tr>
        \`;
      }).join('');
    }

    function switchTab(tabName) {
      document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
      document.querySelectorAll('.section-view').forEach(view => view.classList.remove('active'));

      event.target.classList.add('active');
      const targetView = document.getElementById('view-' + tabName);
      if (targetView) targetView.classList.add('active');
    }

    window.onload = init;
  </script>
</body>
</html>
`;

  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const dateStr = new Date().toISOString().slice(0, 10);
  a.download = `docentes-el-hogar-autonomo-${dateStr}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Descarga un informe escolar estructurado e imprimible en formato HTML
 */
export function downloadAcademicReportHtml(data: AppData, periodsConfig?: PeriodsConfig): void {
  const nowStr = new Date().toLocaleDateString('es-HN', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  });

  const students = data.students || [];
  const classes = data.classes || [];
  const users = data.users || [];
  const teachers = users.filter(u => u.role === 'teacher');

  const studentsRows = students.map((s, idx) => `
    <tr>
      <td style="text-align: center;">${idx + 1}</td>
      <td><strong>${s.name}</strong></td>
      <td>${s.code || s.id || '-'}</td>
      <td>${s.grade || '-'} ${s.section || 'A'}</td>
      <td>${s.guardianPhone || s.contact || '-'}</td>
    </tr>
  `).join('');

  const classesRows = classes.map(c => {
    const teacher = users.find(u => u.id === c.teacherId);
    return `
      <tr>
        <td><strong>${c.name}</strong></td>
        <td>${c.grade || '-'} ${c.section || 'A'}</td>
        <td>${teacher ? teacher.name : 'Sin asignar'}</td>
        <td>${c.subject || 'General'}</td>
      </tr>
    `;
  }).join('');

  const htmlContent = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Reporte Académico Oficial - Docentes El Hogar</title>
  <style>
    body { font-family: Arial, sans-serif; font-size: 12px; color: #222; margin: 30px; }
    .header { text-align: center; border-bottom: 3px double #2f8b3c; padding-bottom: 15px; margin-bottom: 20px; }
    .header h1 { font-size: 20px; margin: 0 0 5px 0; color: #236a2d; }
    .header p { margin: 2px 0; font-size: 12px; color: #555; }
    .section-title { font-size: 14px; font-weight: bold; background: #eaf6ec; padding: 6px 10px; border-left: 4px solid #2f8b3c; margin: 25px 0 10px 0; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
    th { background: #f0f4f0; border: 1px solid #ccc; padding: 6px 8px; font-size: 11px; text-align: left; }
    td { border: 1px solid #ccc; padding: 6px 8px; font-size: 11px; }
    .footer { margin-top: 40px; text-align: center; font-size: 10px; color: #888; border-top: 1px solid #ddd; padding-top: 10px; }
    @media print {
      body { margin: 10mm; }
      .no-print { display: none; }
    }
  </style>
</head>
<body>
  <div class="no-print" style="margin-bottom: 15px; text-align: right;">
    <button onclick="window.print()" style="background:#2f8b3c; color:white; border:none; padding:8px 16px; border-radius:6px; cursor:pointer; font-weight:bold;">🖨️ Imprimir / Guardar como PDF</button>
  </div>

  <div class="header">
    <h1>HOGAR DE AMOR Y ESPERANZA</h1>
    <p><strong>DOCENTES EL HOGAR · SISTEMA DE GESTIÓN ACADÉMICA</strong></p>
    <p>Consolidado Institucional · Fecha de emisión: ${nowStr}</p>
  </div>

  <div class="section-title">1. Resumen Estadístico Institucional</div>
  <table>
    <tr>
      <th>Total Alumnos Matriculados</th>
      <th>Total Clases Habilitadas</th>
      <th>Personal Docente Activo</th>
      <th>Tareas y Actividades</th>
    </tr>
    <tr>
      <td><strong>${students.length}</strong> alumnos</td>
      <td><strong>${classes.length}</strong> asignaturas</td>
      <td><strong>${teachers.length}</strong> docentes</td>
      <td><strong>${(data.activities || []).length}</strong> actividades registradas</td>
    </tr>
  </table>

  <div class="section-title">2. Padrón General de Alumnos</div>
  <table>
    <thead>
      <tr>
        <th style="width: 30px; text-align: center;">N°</th>
        <th>Nombre Completo del Estudiante</th>
        <th>Identidad / Código</th>
        <th>Grado y Sección</th>
        <th>Teléfono de Contacto</th>
      </tr>
    </thead>
    <tbody>
      ${studentsRows || '<tr><td colspan="5" style="text-align:center;">No hay alumnos registrados</td></tr>'}
    </tbody>
  </table>

  <div class="section-title">3. Distribución de Clases y Asignaturas</div>
  <table>
    <thead>
      <tr>
        <th>Asignatura</th>
        <th>Grado y Sección</th>
        <th>Docente Encargado</th>
        <th>Horario Semanal</th>
      </tr>
    </thead>
    <tbody>
      ${classesRows || '<tr><td colspan="4" style="text-align:center;">No hay clases registradas</td></tr>'}
    </tbody>
  </table>

  <div class="footer">
    Docentes El Hogar · Tegucigalpa, Honduras · Documento Académico Oficial generado en formato HTML
  </div>
</body>
</html>
`;

  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const dateStr = new Date().toISOString().slice(0, 10);
  a.download = `reporte-academico-el-hogar-${dateStr}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
