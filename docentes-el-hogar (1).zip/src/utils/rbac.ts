import { ClassRoom, Student, User, Activity, Resource } from '../types';
import { isStudentInClass } from './storage';

/**
 * Returns classes accessible by the current user based on RBAC rules.
 * - Admin: Sees all classes of all teachers.
 * - Teacher: Sees ONLY classes assigned to them by the administrator.
 * - Student: Sees all classes matching their grade.
 */
export function getAllowedClasses(
  classes: ClassRoom[],
  currentUser?: User | null,
  students: Student[] = []
): ClassRoom[] {
  if (!currentUser) return classes;

  if (currentUser.role === 'admin') {
    return classes;
  }

  if (currentUser.role === 'teacher') {
    // Teachers ONLY see classes explicitly assigned to them by administrator
    return classes.filter(c => c.teacherId === currentUser.id);
  }

  if (currentUser.role === 'student') {
    const studentProfile = students.find(
      s => s.userId === currentUser.id || s.name.toLowerCase() === currentUser.name.toLowerCase()
    );
    if (!studentProfile) return [];
    return classes.filter(c => isStudentInClass(studentProfile, c));
  }

  return classes;
}

/**
 * Returns students accessible by the current user:
 * - Admin: Sees all students across all grades.
 * - Teacher: Sees all students enrolled in the classes/grades they teach.
 * - Student: Sees ONLY themselves.
 */
export function getAllowedStudents(
  students: Student[],
  classes: ClassRoom[],
  currentUser?: User | null
): Student[] {
  if (!currentUser) return students;

  if (currentUser.role === 'admin') {
    return students;
  }

  if (currentUser.role === 'teacher') {
    const teacherClasses = getAllowedClasses(classes, currentUser, students);
    return students.filter(s => teacherClasses.some(c => isStudentInClass(s, c)));
  }

  if (currentUser.role === 'student') {
    return students.filter(
      s => s.userId === currentUser.id || s.name.toLowerCase() === currentUser.name.toLowerCase()
    );
  }

  return students;
}

/**
 * Groups items by Grade (e.g. '7mo', '8vo', '1ro', etc.)
 */
export function groupByGrade<T>(items: T[], getGrade: (item: T) => string): Record<string, T[]> {
  return items.reduce((acc, item) => {
    const grade = getGrade(item) || 'Sin grado asignado';
    if (!acc[grade]) {
      acc[grade] = [];
    }
    acc[grade].push(item);
    return acc;
  }, {} as Record<string, T[]>);
}

/**
 * Returns resources visible to the current user:
 * - Admin: Sees ALL resources (both institutional and uploaded by teachers).
 * - Student: Sees ALL institutional resources uploaded by administration,
 *   plus resources assigned to their class or grade.
 * - Teacher: Sees ALL institutional resources uploaded by administration,
 *   plus resources belonging to their assigned classes/grades or uploaded by them.
 */
export function getAllowedResources(
  resources: Resource[],
  currentUser?: User | null,
  students: Student[] = [],
  classes: ClassRoom[] = []
): Resource[] {
  if (!currentUser) return resources;

  if (currentUser.role === 'admin') {
    return resources;
  }

  if (currentUser.role === 'student') {
    const studentProfile = students.find(
      s => s.userId === currentUser.id || s.name.toLowerCase() === currentUser.name.toLowerCase()
    );

    return resources.filter(r => {
      // Always visible if uploaded by admin or marked institutional
      const isFromAdmin =
        r.uploadedByRole === 'admin' ||
        r.classId === 'admin' ||
        r.classId === 'institutional' ||
        !r.classId;
      if (isFromAdmin) return true;

      // Check if student profile matches class or grade
      if (studentProfile) {
        if (studentProfile.classId && r.classId === studentProfile.classId) return true;
        if (
          studentProfile.grade &&
          (r.grade === studentProfile.grade || r.grade === 'Todos' || r.grade === 'General')
        ) {
          return true;
        }
      }

      // If resource is marked for "Todos"
      if (r.grade === 'Todos' || r.grade === 'General') return true;

      return false;
    });
  }

  if (currentUser.role === 'teacher') {
    const teacherClasses = getAllowedClasses(classes, currentUser, students);
    const teacherClassIds = new Set(teacherClasses.map(c => c.id));
    const teacherGrades = new Set(teacherClasses.map(c => c.grade).filter(Boolean));

    return resources.filter(r => {
      // Always visible if uploaded by admin
      const isFromAdmin =
        r.uploadedByRole === 'admin' ||
        r.classId === 'admin' ||
        r.classId === 'institutional' ||
        !r.classId;
      if (isFromAdmin) return true;

      // Resources assigned to teacher's class
      if (r.classId && teacherClassIds.has(r.classId)) return true;

      // Resources assigned to teacher's grade
      if (r.grade && (teacherGrades.has(r.grade) || r.grade === 'Todos' || r.grade === 'General')) {
        return true;
      }

      return false;
    });
  }

  return resources;
}
