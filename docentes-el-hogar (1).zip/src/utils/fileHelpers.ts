import { AttachedFile } from '../types';
import { retrieveFileBlob, formatFileSize, storeFileBlob } from './storage';
import { uploadFileToStorage, deleteFileFromStorage } from '../services/firebase';

/**
 * Detect file category based on filename extension and mime
 */
export function detectFileType(filename: string, mime?: string): string {
  const ext = filename.split('.').pop()?.toLowerCase() || '';

  if (ext === 'pdf' || mime?.includes('pdf')) return 'PDF';
  if (['doc', 'docx', 'odt', 'rtf'].includes(ext) || mime?.includes('word') || mime?.includes('officedocument.wordprocessingml')) return 'DOCX';
  if (['xls', 'xlsx', 'csv', 'ods'].includes(ext) || mime?.includes('sheet') || mime?.includes('excel')) return 'XLSX';
  if (['ppt', 'pptx', 'odp'].includes(ext) || mime?.includes('presentation')) return 'PPTX';
  if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp'].includes(ext) || mime?.startsWith('image/')) return 'Imagen';
  if (['mp4', 'webm', 'avi', 'mkv', 'mov'].includes(ext) || mime?.startsWith('video/')) return 'Video';
  if (['mp3', 'wav', 'ogg', 'm4a'].includes(ext) || mime?.startsWith('audio/')) return 'Audio';
  if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext) || mime?.includes('zip') || mime?.includes('compressed')) return 'ZIP';

  return 'Documento';
}

/**
 * Reads a browser File object as a base64 Data URL string
 */
export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

/**
 * Prepares an AttachedFile object and uploads directly to Firebase Cloud Storage,
 * maintaining local IndexedDB / base64 as dual backup.
 */
export async function processUploadFile(
  file: File,
  folderPrefix: string = 'general',
  onProgress?: (percent: number) => void
): Promise<AttachedFile> {
  const id = `att-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
  const type = detectFileType(file.name, file.type);
  const cleanName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
  const storagePath = `attachments/${folderPrefix}/${id}_${cleanName}`;

  let storageUrl: string | undefined = undefined;

  // 1. Upload to Firebase Cloud Storage
  try {
    const uploadResult = await uploadFileToStorage(file, storagePath, onProgress);
    storageUrl = uploadResult.downloadUrl;
  } catch (cloudErr) {
    console.warn('Cloud Storage upload skipped or failed, using local storage fallback:', cloudErr);
  }

  let fileDataUrl: string | undefined = undefined;
  // If file is smaller than 2MB, store base64 as dual backup
  if (file.size <= 2 * 1024 * 1024) {
    try {
      fileDataUrl = await readFileAsDataUrl(file);
    } catch (e) {
      console.warn('Could not read as dataUrl:', e);
    }
  }

  // Store in IndexedDB for offline instant availability
  let fileStored = false;
  try {
    fileStored = await storeFileBlob(id, file);
  } catch (e) {
    console.warn('Could not store file blob in IndexedDB:', e);
  }

  return {
    id,
    name: file.name,
    size: file.size,
    type,
    mime: file.type || undefined,
    fileDataUrl,
    fileStored,
    storageUrl,
    storagePath: storageUrl ? storagePath : undefined,
    uploadedAt: new Date().toISOString()
  };
}

/**
 * Removes an attached file from Cloud Storage if uploaded
 */
export async function removeAttachedFile(file: AttachedFile): Promise<void> {
  if (file.storagePath) {
    try {
      await deleteFileFromStorage(file.storagePath);
    } catch (err) {
      console.warn('Error deleting attached file from Cloud Storage:', err);
    }
  }
}

/**
 * Downloads or views an attached file with Cloud Storage support
 */
export async function downloadAttachedFile(file: AttachedFile, contextTitle?: string): Promise<void> {
  let blob: Blob | null = null;

  // 1. Try to fetch from Firebase Cloud Storage download URL
  if (file.storageUrl) {
    try {
      const response = await fetch(file.storageUrl);
      if (response.ok) {
        blob = await response.blob();
      }
    } catch (e) {
      console.warn('Could not fetch blob from storageUrl, trying alternatives:', e);
    }
  }

  // 2. Try IndexedDB
  if (!blob && file.id) {
    try {
      blob = await retrieveFileBlob(file.id);
    } catch (e) {
      console.warn('Failed to retrieve file from IndexedDB:', e);
    }
  }

  // 3. Try base64 dataUrl
  if (!blob && file.fileDataUrl) {
    try {
      const response = await fetch(file.fileDataUrl);
      if (response.ok) {
        blob = await response.blob();
      }
    } catch (e) {
      console.warn('Failed to fetch blob from dataUrl:', e);
    }
  }

  // If blob obtained, trigger download
  if (blob) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name || 'archivo_adjunto';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    return;
  }

  // If we have a public storage URL but couldn't fetch as blob due to CORS, open direct download
  if (file.storageUrl) {
    const a = document.createElement('a');
    a.href = file.storageUrl;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    a.download = file.name || 'archivo_adjunto';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    return;
  }

  // Generate text document fallback so the download always succeeds gracefully
  const textContent = `DOCENTES EL HOGAR - ARCHIVO ADJUNTO DE ACTIVIDAD\n` +
    `===================================================\n\n` +
    `Nombre del archivo: ${file.name}\n` +
    `Tipo de material: ${file.type}\n` +
    `Tamaño: ${formatFileSize(file.size)}\n` +
    `Fecha de subida: ${file.uploadedAt ? new Date(file.uploadedAt).toLocaleString('es-ES') : new Date().toLocaleDateString('es-ES')}\n` +
    (file.storageUrl ? `Ubicación en Firebase Cloud Storage: ${file.storageUrl}\n` : '') +
    (contextTitle ? `Actividad / Tarea: ${contextTitle}\n` : '') +
    `\nEste documento adjunto fue generado y compartido a través del portal institucional de Docentes El Hogar.`;

  const fallbackBlob = new Blob([textContent], { type: 'text/plain;charset=utf-8;' });
  const url = URL.createObjectURL(fallbackBlob);
  const a = document.createElement('a');
  a.href = url;
  a.download = file.name || 'archivo_adjunto';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
