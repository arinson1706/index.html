import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  ActiveSection,
  AppData,
  User,
  ClassRoom,
  Student,
  Resource,
  LessonPlan,
  Activity,
  ActivityStudentGrade,
  AttachedFile,
  GradeEvaluation,
  CalendarEvent,
  AttendanceStatus,
  ParcialId,
  PeriodsConfig,
  ForumTopic,
  ForumComment
} from './types';
import {
  loadData,
  saveData,
  loadSession,
  saveSession,
  clearSession,
  updateSessionActivity,
  isSessionExpired,
  INACTIVITY_TIMEOUT_MS,
  saveFileBlob,
  getFileBlob,
  deleteFileBlob,
  calculateStudentAverage,
  calculateStudentAttendancePercentage,
  isStudentInClass,
  matchGrade,
  formatDate,
  getTodayDateString,
  getActivePeriod,
  isPeriodClosed,
  normalizeAppData
} from './utils/storage';
import {
  syncAppDataToFirestore,
  fetchAppDataFromFirestore,
  subscribeToFirestoreData,
  uploadFileToStorage,
  deleteFileFromStorage
} from './services/firebase';
import { getAllowedClasses } from './utils/rbac';
import { HOGAR_LOGO, INITIAL_DATA, DEFAULT_PERIODS_CONFIG } from './constants/initialData';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { LoginView } from './components/LoginView';

// Views
import { DashboardView } from './components/views/DashboardView';
import { ClassesView } from './components/views/ClassesView';
import { StudentsView } from './components/views/StudentsView';
import { StudentProfileModal } from './components/views/StudentProfileModal';
import { ResourcesView } from './components/views/ResourcesView';
import { PlanningView } from './components/views/PlanningView';
import { ActivitiesView } from './components/views/ActivitiesView';
import { ForumView } from './components/views/ForumView';
import { GradesView } from './components/views/GradesView';
import { AttendanceView } from './components/views/AttendanceView';
import { ReportsView } from './components/views/ReportsView';
import { CalendarView } from './components/views/CalendarView';
import { AdminView } from './components/views/AdminView';

// Modals
import { StudentAccessModal } from './components/modals/StudentAccessModal';
import { NotificationsModal } from './components/modals/NotificationsModal';
import { ClassModal } from './components/modals/ClassModal';
import { StudentModal } from './components/modals/StudentModal';
import { BulkStudentModal } from './components/modals/BulkStudentModal';
import { ResourceModal } from './components/modals/ResourceModal';
import { PlanModal } from './components/modals/PlanModal';
import { PlanDetailModal } from './components/modals/PlanDetailModal';
import { ActivityModal } from './components/modals/ActivityModal';
import { ForumTopicModal } from './components/modals/ForumTopicModal';
import { EvaluationModal } from './components/modals/EvaluationModal';
import { EventModal } from './components/modals/EventModal';
import { UserModal } from './components/modals/UserModal';
import { PasswordModal } from './components/modals/PasswordModal';
import { DeleteAdminModal } from './components/modals/DeleteAdminModal';
import { PeriodsControlModal } from './components/modals/PeriodsControlModal';
import { DownloadCodeModal } from './components/modals/DownloadCodeModal';

export default function App() {
  // Global persistent data state
  const [data, setData] = useState<AppData>(() => loadData());
  const [currentUser, setCurrentUser] = useState<User | null>(() => loadSession());
  const [activeSection, setActiveSection] = useState<ActiveSection>('dashboard');

  // Inactivity protection state (2 hours timeout)
  const [inactivityNotice, setInactivityNotice] = useState<string | null>(null);
  const lastActivityRef = useRef<number>(Date.now());
  const lastStorageSyncRef = useRef<number>(Date.now());

  // UI state
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Target class / student context for navigation from other views
  const [targetClassFilter, setTargetClassFilter] = useState<string>('');
  const [targetStudentId, setTargetStudentId] = useState<string>('');

  // Modals state
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [periodsControlModalOpen, setPeriodsControlModalOpen] = useState(false);
  const [downloadCodeModalOpen, setDownloadCodeModalOpen] = useState(false);

  const [accessStudentModalOpen, setAccessStudentModalOpen] = useState(false);
  const [accessTargetStudent, setAccessTargetStudent] = useState<Student | null>(null);

  const [classModalOpen, setClassModalOpen] = useState(false);
  const [editingClass, setEditingClass] = useState<ClassRoom | null>(null);
  const [classModalDefaultGrade, setClassModalDefaultGrade] = useState<string>('');

  const [studentModalOpen, setStudentModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [studentModalClassId, setStudentModalClassId] = useState<string>('');
  const [studentModalDefaultGrade, setStudentModalDefaultGrade] = useState<string>('');

  const [bulkStudentOpen, setBulkStudentOpen] = useState(false);
  const [profileStudent, setProfileStudent] = useState<Student | null>(null);

  const [resourceModalOpen, setResourceModalOpen] = useState(false);
  const [editingResource, setEditingResource] = useState<Resource | null>(null);

  const [planModalOpen, setPlanModalOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<LessonPlan | null>(null);
  const [detailPlan, setDetailPlan] = useState<LessonPlan | null>(null);

  const [activityModalOpen, setActivityModalOpen] = useState(false);
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);

  // Forum modal & navigation state
  const [forumTopicModalOpen, setForumTopicModalOpen] = useState(false);
  const [editingForumTopic, setEditingForumTopic] = useState<ForumTopic | null>(null);
  const [forumInitialClassId, setForumInitialClassId] = useState<string>('all');
  const [forumInitialActivityId, setForumInitialActivityId] = useState<string>('');
  const [forumTargetTopicId, setForumTargetTopicId] = useState<string | null>(null);

  const [evaluationModalOpen, setEvaluationModalOpen] = useState(false);
  const [evaluationClassId, setEvaluationClassId] = useState<string>('');

  const [eventModalOpen, setEventModalOpen] = useState(false);

  const [userModalOpen, setUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  const [passwordModalOpen, setPasswordModalOpen] = useState(false);
  const [passwordTargetUser, setPasswordTargetUser] = useState<User | null>(null);

  const [deleteAdminModalOpen, setDeleteAdminModalOpen] = useState(false);
  const [adminTargetToDelete, setAdminTargetToDelete] = useState<User | null>(null);

  // Firebase sync state
  const [isFirebaseSynced, setIsFirebaseSynced] = useState<boolean>(true);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Real-time Firestore sync listener
  useEffect(() => {
    let isMounted = true;

    // First fetch cloud state once
    fetchAppDataFromFirestore().then(remoteData => {
      if (!isMounted) return;
      if (remoteData) {
        const normalized = normalizeAppData(remoteData);
        setData(normalized);
        saveData(normalized);
        setIsFirebaseSynced(true);
      } else {
        // First time initialization: populate Firestore with current state
        syncAppDataToFirestore(data).catch(() => {});
      }
    }).catch(() => {
      setIsFirebaseSynced(false);
    });

    // Subscribe to ongoing updates
    const unsubscribe = subscribeToFirestoreData(
      (incomingData) => {
        if (!isMounted) return;
        const normalized = normalizeAppData(incomingData);
        setData(normalized);
        saveData(normalized);
        setIsFirebaseSynced(true);
      },
      (err) => {
        console.warn('Real-time sync alert:', err);
      }
    );

    return () => {
      isMounted = false;
      unsubscribe();
    };
  }, []);

  // Auto-save data locally and replicate to Firebase Firestore
  const updateData = useCallback((updater: (prev: AppData) => AppData) => {
    setData(prev => {
      const next = updater(prev);
      saveData(next);
      // Replicate to Firebase Firestore asynchronously
      setIsSyncing(true);
      syncAppDataToFirestore(next)
        .then(() => {
          setIsFirebaseSynced(true);
        })
        .catch(err => {
          console.error('Failed to sync to Firebase Firestore:', err);
          setIsFirebaseSynced(false);
        })
        .finally(() => {
          setIsSyncing(false);
        });
      return next;
    });
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  // -------------------------
  // Auth Handlers
  // -------------------------
  const handleRegisterAdmin = (name: string, username: string, pass: string): { success: boolean; message?: string } => {
    const exists = data.users.some(u => u.username.toLowerCase() === username.toLowerCase());
    if (exists) {
      return { success: false, message: `El nombre de usuario "${username}" ya está registrado.` };
    }
    const newAdmin: User = {
      id: `user-admin-${Date.now()}`,
      name,
      username,
      password: pass,
      role: 'admin',
      active: true
    };
    updateData(prev => ({
      ...prev,
      users: [...prev.users, newAdmin]
    }));
    handleLogin(newAdmin);
    return { success: true };
  };

  const handleLogin = (user: User) => {
    saveSession(user);
    setCurrentUser(user);
    setInactivityNotice(null);
    lastActivityRef.current = Date.now();
    lastStorageSyncRef.current = Date.now();
    setActiveSection('dashboard');
    showToast(`¡Bienvenido/a, ${user.name}!`);
  };

  const handleLogout = () => {
    clearSession();
    setCurrentUser(null);
    setInactivityNotice(null);
    setActiveSection('dashboard');
    showToast('Sesión cerrada correctamente. Tus datos siguen guardados.');
  };

  const handleInactivityLogout = useCallback(() => {
    clearSession();
    setCurrentUser(null);
    setActiveSection('dashboard');
    setInactivityNotice(
      'Tu sesión se cerró automáticamente tras 2 horas de inactividad para proteger tus datos y la seguridad institucional.'
    );
    showToast('Sesión cerrada por inactividad (2 horas transcurridas).');
  }, []);

  // Monitorización de inactividad de 2 horas (7,200,000 ms)
  useEffect(() => {
    if (!currentUser) return;

    lastActivityRef.current = Date.now();
    lastStorageSyncRef.current = Date.now();

    const handleUserInteraction = () => {
      const now = Date.now();
      lastActivityRef.current = now;

      // Actualizar almacenamiento throttled a máximo una vez cada 30 segundos
      if (now - lastStorageSyncRef.current > 30000) {
        lastStorageSyncRef.current = now;
        updateSessionActivity();
      }
    };

    const verifyInactivity = () => {
      const now = Date.now();
      const elapsed = now - lastActivityRef.current;
      if (elapsed >= INACTIVITY_TIMEOUT_MS || isSessionExpired()) {
        handleInactivityLogout();
      }
    };

    // Eventos que representan interacción del usuario
    const activityEvents = [
      'mousedown',
      'mousemove',
      'keydown',
      'scroll',
      'touchstart',
      'click',
      'wheel'
    ];

    activityEvents.forEach(evt => {
      window.addEventListener(evt, handleUserInteraction, { passive: true });
    });

    // Verificación periódica cada 15 segundos
    const timerInterval = window.setInterval(verifyInactivity, 15000);

    // Verificación inmediata al reenfocar la ventana o cambiar pestaña
    const handleVisibilityOrFocus = () => {
      if (document.visibilityState === 'visible') {
        verifyInactivity();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityOrFocus);
    window.addEventListener('focus', handleVisibilityOrFocus);

    return () => {
      activityEvents.forEach(evt => {
        window.removeEventListener(evt, handleUserInteraction);
      });
      window.clearInterval(timerInterval);
      document.removeEventListener('visibilitychange', handleVisibilityOrFocus);
      window.removeEventListener('focus', handleVisibilityOrFocus);
    };
  }, [currentUser, handleInactivityLogout]);

  // -------------------------
  // Class CRUD
  // -------------------------
  const handleSaveClass = (classData: Omit<ClassRoom, 'id'> & { id?: string }) => {
    if (classData.id) {
      const updatedClass = { ...classData, id: classData.id } as ClassRoom;
      updateData(prev => {
        const updatedClasses = prev.classes.map(c => (c.id === classData.id ? updatedClass : c));
        // Synchronize students for updated grade/section
        const updatedStudents = prev.students.map(s => {
          const belongs = isStudentInClass(s, updatedClass);
          const currentEnrolled = new Set(s.enrolledClassIds || []);
          if (belongs) {
            currentEnrolled.add(updatedClass.id);
          } else {
            currentEnrolled.delete(updatedClass.id);
          }
          return {
            ...s,
            classId: s.classId || (belongs ? updatedClass.id : ''),
            enrolledClassIds: Array.from(currentEnrolled)
          };
        });
        return {
          ...prev,
          classes: updatedClasses,
          students: updatedStudents
        };
      });
      showToast('Clase actualizada correctamente');
    } else {
      const newClass: ClassRoom = {
        ...classData,
        id: `class-${Date.now()}`
      };
      updateData(prev => {
        // Automatically enroll all existing students of this grade into the new class
        let enrolledCount = 0;
        const updatedStudents = prev.students.map(s => {
          if (isStudentInClass(s, newClass)) {
            enrolledCount++;
            const currentEnrolled = new Set(s.enrolledClassIds || []);
            currentEnrolled.add(newClass.id);
            return {
              ...s,
              classId: s.classId || newClass.id,
              enrolledClassIds: Array.from(currentEnrolled)
            };
          }
          return s;
        });

        return {
          ...prev,
          classes: [...prev.classes, newClass],
          students: updatedStudents
        };
      });
      showToast(
        classData.grade
          ? `Clase asignada al grado ${classData.grade}. Se incluyeron automáticamente los alumnos de este grado.`
          : 'Nueva clase creada con éxito'
      );
    }
  };

  const handleDeleteClass = (id: string) => {
    const classItem = data.classes.find(c => c.id === id);
    if (!confirm(`¿Eliminar la clase "${classItem?.name}"?`)) return;

    updateData(prev => ({
      ...prev,
      classes: prev.classes.filter(c => c.id !== id),
      students: prev.students.map(s => ({
        ...s,
        classId: s.classId === id ? '' : s.classId,
        enrolledClassIds: (s.enrolledClassIds || []).filter(cId => cId !== id)
      })),
      grades: prev.grades.filter(g => g.classId !== id),
      activities: prev.activities.filter(a => a.classId !== id)
    }));
    showToast('Clase eliminada');
  };

  // -------------------------
  // Student CRUD
  // -------------------------
  const handleSaveStudent = (studentData: Omit<Student, 'id'> & { id?: string }) => {
    // Automatically find all classes assigned to this grade
    const matchingClasses = data.classes.filter(c => matchGrade(studentData.grade, c.grade));
    const matchingClassIds = matchingClasses.map(c => c.id);
    const primaryClassId = studentData.classId || matchingClassIds[0] || '';

    if (studentData.id) {
      updateData(prev => ({
        ...prev,
        students: prev.students.map(s =>
          s.id === studentData.id
            ? ({
                ...s,
                ...studentData,
                classId: primaryClassId,
                enrolledClassIds: matchingClassIds
              } as Student)
            : s
        )
      }));
      showToast(
        matchingClassIds.length > 0
          ? `Alumno actualizado e inscrito en las ${matchingClassIds.length} clases del grado ${studentData.grade}`
          : `Alumno actualizado en el grado ${studentData.grade}`
      );
    } else {
      const newStudent: Student = {
        ...studentData,
        id: `stu-${Date.now()}`,
        classId: primaryClassId,
        enrolledClassIds: matchingClassIds
      };
      updateData(prev => ({
        ...prev,
        students: [...prev.students, newStudent]
      }));
      showToast(
        matchingClassIds.length > 0
          ? `¡Alumno registrado! Inscrito automáticamente a todas las clases (${matchingClassIds.length}) del grado ${studentData.grade}.`
          : `¡Alumno registrado en ${studentData.grade}! (Se inscribirá a todas las clases que crees para este grado).`
      );
    }
  };

  const handleBulkImportStudents = (studentsList: Omit<Student, 'id'>[]) => {
    const created: Student[] = studentsList.map((s, idx) => {
      const id = `stu-${Date.now()}-${idx}`;
      const matchingClasses = data.classes.filter(c => matchGrade(s.grade, c.grade));
      const matchingClassIds = matchingClasses.map(c => c.id);
      return {
        ...s,
        id,
        classId: s.classId || matchingClassIds[0] || '',
        enrolledClassIds: matchingClassIds
      };
    });

    updateData(prev => ({
      ...prev,
      students: [...prev.students, ...created]
    }));
    showToast(`Se importaron ${created.length} alumnos e inscritos a todas las clases de su grado.`);
  };

  const handleDeleteStudent = (id: string) => {
    const s = data.students.find(item => item.id === id);
    if (!confirm(`¿Eliminar al alumno "${s?.name}"?`)) return;

    updateData(prev => ({
      ...prev,
      students: prev.students.filter(item => item.id !== id)
    }));
    showToast('Alumno eliminado');
  };

  // -------------------------
  // Resources CRUD & Download
  // -------------------------
  const handleSaveResource = async (
    resData: Omit<Resource, 'id'> & { id?: string; storageUrl?: string; storagePath?: string },
    fileBlob?: Blob
  ) => {
    const resourceId = resData.id || `res-${Date.now()}`;
    let storageUrl = resData.storageUrl;
    let storagePath = resData.storagePath;

    if (fileBlob) {
      // 1. Dual backup in local IndexedDB
      try {
        await saveFileBlob(resourceId, fileBlob);
      } catch (err) {
        console.error('Error saving file blob to IndexedDB:', err);
      }

      // 2. Upload to Firebase Cloud Storage if not already uploaded by modal
      if (!storageUrl) {
        try {
          const cleanName = (resData.name || 'recurso').replace(/[^a-zA-Z0-9._-]/g, '_');
          const path = `resources/${resourceId}/${cleanName}`;
          const uploadRes = await uploadFileToStorage(fileBlob, path);
          storageUrl = uploadRes.downloadUrl;
          storagePath = uploadRes.storagePath;
        } catch (cloudErr) {
          console.warn('Firebase Cloud Storage fallback in handleSaveResource:', cloudErr);
        }
      }
    }

    if (resData.id) {
      updateData(prev => ({
        ...prev,
        resources: prev.resources.map(r =>
          r.id === resData.id ? ({ ...r, ...resData, storageUrl, storagePath } as Resource) : r
        )
      }));
      showToast('Recurso actualizado');
    } else {
      const newResource: Resource = {
        ...resData,
        id: resourceId,
        storageUrl,
        storagePath
      };
      updateData(prev => ({
        ...prev,
        resources: [newResource, ...prev.resources]
      }));
      showToast('Recurso subido con éxito a Firebase Cloud Storage');
    }
  };

  const handleDeleteResource = async (id: string) => {
    const targetResource = data.resources.find(r => r.id === id);
    if (!confirm('¿Eliminar este material educativo?')) return;

    // Remove from Firebase Cloud Storage if path exists
    if (targetResource?.storagePath) {
      try {
        await deleteFileFromStorage(targetResource.storagePath);
      } catch (e) {
        console.warn('Error deleting file from Cloud Storage:', e);
      }
    }

    // Remove local blob
    try {
      await deleteFileBlob(id);
    } catch (e) {
      console.error(e);
    }

    updateData(prev => ({
      ...prev,
      resources: prev.resources.filter(r => r.id !== id)
    }));
    showToast('Recurso eliminado');
  };

  const handleDownloadResource = async (id: string) => {
    const res = data.resources.find(r => r.id === id);
    if (!res) return;

    let blob: Blob | null = null;

    // 1. Try to fetch from Firebase Cloud Storage URL
    if (res.storageUrl) {
      try {
        const resp = await fetch(res.storageUrl);
        if (resp.ok) {
          blob = await resp.blob();
        }
      } catch (e) {
        console.warn('Direct fetch from Cloud Storage failed, trying local store:', e);
      }
    }

    // 2. Try IndexedDB
    if (!blob) {
      try {
        blob = await getFileBlob(id);
      } catch (e) {
        console.error('Error reading blob:', e);
      }
    }

    // 3. Try base64 dataUrl
    if (!blob && res.fileDataUrl) {
      try {
        const resp = await fetch(res.fileDataUrl);
        if (resp.ok) {
          blob = await resp.blob();
        }
      } catch (e) {
        console.warn('Error reading base64 dataUrl:', e);
      }
    }

    // If blob successfully fetched, trigger download
    if (blob) {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = res.name.includes('.') ? res.name : `${res.name}.${res.type.toLowerCase()}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast(`Descargando "${res.name}"...`);
      return;
    }

    // Direct download link if CORS prevented blob fetch
    if (res.storageUrl) {
      const a = document.createElement('a');
      a.href = res.storageUrl;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.download = res.name.includes('.') ? res.name : `${res.name}.${res.type.toLowerCase()}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      showToast(`Descargando desde Cloud Storage: "${res.name}"`);
      return;
    }

    // Fallback: create a mock text document content with metadata
    const textContent = `DOCENTES EL HOGAR - MATERIAL EDUCATIVO\n\nNombre: ${res.name}\nMateria: ${res.subject || 'General'}\nTema: ${res.topic || 'General'}\nUnidad: ${res.unit || '1'}\nFecha: ${res.date}\nTipo: ${res.type}\n\nDocumento pedagógico oficial emitido por la institución.`;
    const fallbackBlob = new Blob([textContent], { type: 'text/plain;charset=utf-8;' });
    const fallbackUrl = URL.createObjectURL(fallbackBlob);
    const a = document.createElement('a');
    a.href = fallbackUrl;
    a.download = res.name.includes('.') ? res.name : `${res.name}.${res.type.toLowerCase()}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(fallbackUrl);
    showToast(`Descargando "${res.name}"...`);
  };

  const handleToggleFavoriteResource = (id: string) => {
    updateData(prev => ({
      ...prev,
      resources: prev.resources.map(r => (r.id === id ? { ...r, favorite: !r.favorite } : r))
    }));
  };

  // -------------------------
  // Planning CRUD
  // -------------------------
  const handleSavePlan = (planData: Omit<LessonPlan, 'id'> & { id?: string }) => {
    if (planData.id) {
      updateData(prev => ({
        ...prev,
        plans: prev.plans.map(p => (p.id === planData.id ? ({ ...p, ...planData } as LessonPlan) : p))
      }));
      showToast('Planificación actualizada');
    } else {
      const newPlan: LessonPlan = {
        ...planData,
        id: `plan-${Date.now()}`
      };
      updateData(prev => ({
        ...prev,
        plans: [newPlan, ...prev.plans]
      }));
      showToast('Planificación creada con éxito');
    }
  };

  const handleDuplicatePlan = (id: string) => {
    const original = data.plans.find(p => p.id === id);
    if (!original) return;

    const copy: LessonPlan = {
      ...original,
      id: `plan-${Date.now()}`,
      title: `${original.title} (Copia)`,
      template: false,
      date: new Date().toISOString().slice(0, 10)
    };

    updateData(prev => ({
      ...prev,
      plans: [copy, ...prev.plans]
    }));
    showToast('Planificación duplicada');
  };

  const handleDeletePlan = (id: string) => {
    if (!confirm('¿Eliminar esta planificación?')) return;
    updateData(prev => ({
      ...prev,
      plans: prev.plans.filter(p => p.id !== id)
    }));
    showToast('Planificación eliminada');
  };

  // -------------------------
  // Activities CRUD
  // -------------------------
  const handleSaveActivity = (actData: Omit<Activity, 'id'> & { id?: string }) => {
    const activeP = getActivePeriod(data.periodsConfig).id;
    const targetParcial = actData.parcial || activeP;

    if (isPeriodClosed(data.periodsConfig, targetParcial)) {
      showToast('No se puede guardar: el parcial seleccionado está cerrado por Coordinación.');
      return;
    }

    if (actData.id) {
      updateData(prev => ({
        ...prev,
        activities: prev.activities.map(a =>
          a.id === actData.id ? ({ ...a, ...actData, parcial: targetParcial } as Activity) : a
        )
      }));
      showToast('Actividad actualizada');
    } else {
      const newAct: Activity = {
        ...actData,
        parcial: targetParcial,
        id: `act-${Date.now()}`
      };
      updateData(prev => ({
        ...prev,
        activities: [newAct, ...prev.activities]
      }));
      showToast('Actividad creada con éxito');
    }
  };

  const handleUpdateActivityStatus = (id: string, status: Activity['status']) => {
    const act = data.activities.find(a => a.id === id);
    if (act && isPeriodClosed(data.periodsConfig, act.parcial || 1)) {
      showToast('No se puede modificar: el parcial de esta actividad está cerrado.');
      return;
    }
    updateData(prev => ({
      ...prev,
      activities: prev.activities.map(a => (a.id === id ? { ...a, status } : a))
    }));
    showToast(`Estado cambiado a: ${status}`);
  };

  const handleDeleteActivity = (id: string) => {
    const act = data.activities.find(a => a.id === id);
    if (act && isPeriodClosed(data.periodsConfig, act.parcial || 1)) {
      showToast('No se puede eliminar: la actividad pertenece a un parcial cerrado por Coordinación.');
      return;
    }
    if (!confirm('¿Eliminar esta actividad escolar?')) return;
    updateData(prev => ({
      ...prev,
      activities: prev.activities.filter(a => a.id !== id)
    }));
    showToast('Actividad eliminada');
  };

  const handleSaveActivityGrades = (
    activityId: string,
    scores: Record<string, number>,
    studentGrades: Record<string, ActivityStudentGrade>
  ) => {
    const act = data.activities.find(a => a.id === activityId);
    if (act && isPeriodClosed(data.periodsConfig, act.parcial || 1)) {
      showToast('No se pueden modificar calificaciones de un parcial cerrado.');
      return;
    }
    updateData(prev => ({
      ...prev,
      activities: prev.activities.map(a => {
        if (a.id !== activityId) return a;
        const totalScored = Object.values(scores).filter(s => s !== undefined && s !== null).length;
        const newStatus: Activity['status'] = totalScored > 0 ? 'Calificada' : a.status;
        return {
          ...a,
          scores,
          studentGrades,
          status: newStatus
        };
      })
    }));
    showToast('¡Calificaciones de la actividad guardadas con éxito!');
  };

  const handleUpdateActivityScore = (activityId: string, studentId: string, score: number) => {
    const act = data.activities.find(a => a.id === activityId);
    if (act && isPeriodClosed(data.periodsConfig, act.parcial || 1)) {
      showToast('No se pueden modificar notas de un parcial cerrado.');
      return;
    }
    updateData(prev => ({
      ...prev,
      activities: prev.activities.map(a => {
        if (a.id !== activityId) return a;
        const currentGrades = a.studentGrades || {};
        const existing = currentGrades[studentId] || {};
        const updatedScores = {
          ...(a.scores || {}),
          [studentId]: score
        };
        const updatedGrade: ActivityStudentGrade = {
          ...existing,
          score,
          status: 'Calificado'
        };
        return {
          ...a,
          scores: updatedScores,
          studentGrades: {
            ...currentGrades,
            [studentId]: updatedGrade
          },
          status: 'Calificada'
        };
      })
    }));
  };

  const handleSubmitHomework = (
    activityId: string,
    studentId: string,
    submissionData: {
      attachments: AttachedFile[];
      studentComment?: string;
    }
  ) => {
    const act = data.activities.find(a => a.id === activityId);
    if (act && isPeriodClosed(data.periodsConfig, act.parcial || 1)) {
      showToast('El parcial correspondiente a esta tarea está cerrado. Ya no se permiten entregas.');
      return;
    }
    updateData(prev => ({
      ...prev,
      activities: prev.activities.map(a => {
        if (a.id !== activityId) return a;
        const currentGrades = a.studentGrades || {};
        const existing = currentGrades[studentId] || {};
        const updatedGrade: ActivityStudentGrade = {
          ...existing,
          status: existing.status === 'Calificado' ? 'Calificado' : 'Entregado',
          attachments: submissionData.attachments,
          studentComment: submissionData.studentComment,
          submittedAt: new Date().toISOString()
        };
        return {
          ...a,
          studentGrades: {
            ...currentGrades,
            [studentId]: updatedGrade
          }
        };
      })
    }));
    showToast('¡Tarea y archivos entregados con éxito!');
  };

  // -------------------------
  // Grades & Evaluations
  // -------------------------
  const handleSaveEvaluation = (evalData: Omit<GradeEvaluation, 'id'>) => {
    const activeP = getActivePeriod(data.periodsConfig).id;
    const targetParcial = evalData.parcial || activeP;

    if (isPeriodClosed(data.periodsConfig, targetParcial)) {
      showToast('No se puede crear evaluación: el parcial está cerrado por Coordinación.');
      return;
    }

    const newEval: GradeEvaluation = {
      ...evalData,
      parcial: targetParcial,
      id: `eval-${Date.now()}`
    };
    updateData(prev => ({
      ...prev,
      grades: [...prev.grades, newEval]
    }));
    showToast('Evaluación creada con éxito');
  };

  const handleDeleteEvaluation = (id: string) => {
    const ev = data.grades.find(g => g.id === id);
    if (ev && isPeriodClosed(data.periodsConfig, ev.parcial || 1)) {
      showToast('No se puede eliminar: la evaluación pertenece a un parcial cerrado por Coordinación.');
      return;
    }
    if (!confirm('¿Eliminar esta evaluación y todas sus notas?')) return;
    updateData(prev => ({
      ...prev,
      grades: prev.grades.filter(g => g.id !== id)
    }));
    showToast('Evaluación eliminada');
  };

  const handleUpdateScore = (evaluationId: string, studentId: string, score: number) => {
    const ev = data.grades.find(g => g.id === evaluationId);
    if (ev && isPeriodClosed(data.periodsConfig, ev.parcial || 1)) {
      showToast('No se pueden modificar calificaciones de un parcial cerrado.');
      return;
    }
    updateData(prev => ({
      ...prev,
      grades: prev.grades.map(g => {
        if (g.id !== evaluationId) return g;
        return {
          ...g,
          scores: {
            ...g.scores,
            [studentId]: score
          }
        };
      })
    }));
  };

  // -------------------------
  // Attendance
  // -------------------------
  const handleSetAttendance = (
    classId: string,
    date: string,
    studentId: string,
    status: AttendanceStatus
  ) => {
    const key = `${date}:${classId}`;
    updateData(prev => ({
      ...prev,
      attendance: {
        ...prev.attendance,
        [key]: {
          ...(prev.attendance[key] || {}),
          [studentId]: status
        }
      }
    }));
  };

  const handleMarkAllPresent = (classId: string, date: string) => {
    const key = `${date}:${classId}`;
    const currentClass = data.classes.find(c => c.id === classId);
    const classStudents = currentClass
      ? data.students.filter(s => isStudentInClass(s, currentClass) && s.status !== 'Inactivo')
      : data.students.filter(s => s.classId === classId);
    const newRecord: Record<string, AttendanceStatus> = {};
    classStudents.forEach(s => {
      newRecord[s.id] = 'P';
    });

    updateData(prev => ({
      ...prev,
      attendance: {
        ...prev.attendance,
        [key]: newRecord
      }
    }));
    showToast('Se marcaron todos los alumnos como "Presente"');
  };

  // -------------------------
  // Calendar Events
  // -------------------------
  const handleSaveEvent = (eventData: Omit<CalendarEvent, 'id'>) => {
    const newEvent: CalendarEvent = {
      ...eventData,
      id: `ev-${Date.now()}`
    };
    updateData(prev => ({
      ...prev,
      events: [...prev.events, newEvent]
    }));
    showToast('Evento añadido a la agenda');
  };

  const handleDeleteEvent = (id: string) => {
    updateData(prev => ({
      ...prev,
      events: prev.events.filter(e => e.id !== id)
    }));
    showToast('Evento eliminado');
  };

  // -------------------------
  // User Management
  // -------------------------
  const handleSaveUser = (userData: Omit<User, 'id'> & { id?: string }) => {
    if (userData.id) {
      updateData(prev => ({
        ...prev,
        users: prev.users.map(u => (u.id === userData.id ? ({ ...u, ...userData } as User) : u))
      }));
      showToast('Usuario actualizado');
    } else {
      const newUser: User = {
        ...userData,
        id: `user-${Date.now()}`
      };
      updateData(prev => ({
        ...prev,
        users: [...prev.users, newUser]
      }));
      showToast('Nuevo usuario creado');
    }
  };

  const handleResetPassword = (userId: string, newPass: string) => {
    updateData(prev => ({
      ...prev,
      users: prev.users.map(u => (u.id === userId ? { ...u, password: newPass } : u))
    }));
    showToast('Contraseña actualizada correctamente');
  };

  const handleToggleUserActive = (userId: string) => {
    updateData(prev => ({
      ...prev,
      users: prev.users.map(u => (u.id === userId ? { ...u, active: !u.active } : u))
    }));
    showToast('Estado del usuario actualizado');
  };

  // -------------------------
  // Student Access (Admin / Teacher hierarchy)
  // -------------------------
  const handleOpenStudentAccess = (student: Student) => {
    setAccessTargetStudent(student);
    setAccessStudentModalOpen(true);
  };

  const handleSaveStudentAccess = (
    studentId: string,
    username: string,
    password: string,
    active: boolean
  ) => {
    const student = data.students.find(s => s.id === studentId);
    if (!student) return;

    const existingUser = student.userId
      ? data.users.find(u => u.id === student.userId)
      : data.users.find(u => u.role === 'student' && u.name.toLowerCase() === student.name.toLowerCase());

    if (existingUser) {
      updateData(prev => ({
        ...prev,
        users: prev.users.map(u =>
          u.id === existingUser.id
            ? { ...u, username, password, active }
            : u
        ),
        students: prev.students.map(s =>
          s.id === studentId ? { ...s, userId: existingUser.id } : s
        )
      }));
      showToast(`Credenciales actualizadas para ${student.name} (@${username})`);
    } else {
      const newUserId = `user-std-${Date.now()}`;
      const newUser: User = {
        id: newUserId,
        name: student.name,
        username,
        password,
        role: 'student',
        active
      };

      updateData(prev => ({
        ...prev,
        users: [...prev.users, newUser],
        students: prev.students.map(s =>
          s.id === studentId ? { ...s, userId: newUserId } : s
        )
      }));
      showToast(`Acceso concedido a ${student.name} (@${username})`);
    }
  };

  const handleDeleteUser = (userId: string) => {
    if (userId === currentUser?.id) {
      showToast('No puedes eliminar tu propia cuenta en sesión activa.');
      return;
    }

    const targetUser = data.users.find(u => u.id === userId);
    if (!targetUser) return;

    // If deleting an administrator, require master key authorization
    if (targetUser.role === 'admin') {
      setAdminTargetToDelete(targetUser);
      setDeleteAdminModalOpen(true);
      return;
    }

    if (!confirm(`¿Eliminar definitivamente al usuario "${targetUser.name}" (@${targetUser.username})?`)) return;

    executeDeleteUser(userId);
  };

  const executeDeleteUser = (userId: string) => {
    updateData(prev => ({
      ...prev,
      users: prev.users.filter(u => u.id !== userId),
      students: prev.students.map(s => (s.userId === userId ? { ...s, userId: undefined } : s))
    }));
    showToast('Usuario eliminado correctamente');
  };

  const handleRestoreBackup = (newData: AppData) => {
    setData(newData);
    saveData(newData);
    showToast('¡Copia de seguridad restaurada correctamente!');
  };

  const handleEmptyDatabase = () => {
    const adminUsers = data.users.filter(u => u.role === 'admin');
    const finalUsers = adminUsers.length > 0 ? adminUsers : INITIAL_DATA.users;
    const emptyData: AppData = {
      users: finalUsers,
      classes: [],
      students: [],
      resources: [],
      plans: [],
      activities: [],
      grades: [],
      attendance: {},
      events: []
    };
    updateData(() => emptyData);
    showToast('Base de datos vaciada con éxito');
  };

  // -------------------------
  // Academic Periods Management (Coordinación)
  // -------------------------
  const handleStartPeriod = (parcialId: ParcialId) => {
    const today = getTodayDateString();
    updateData(prev => {
      const currentConfig = prev.periodsConfig || DEFAULT_PERIODS_CONFIG;
      const updatedPeriods = currentConfig.periods.map(p => {
        if (p.id === parcialId) {
          return {
            ...p,
            status: 'active' as const,
            startDate: p.startDate || today,
            endDate: undefined,
            closedAt: undefined,
            closedBy: undefined
          };
        }
        // If another period was active, automatically mark it as closed
        if (p.status === 'active') {
          return {
            ...p,
            status: 'closed' as const,
            endDate: p.endDate || today,
            closedAt: today,
            closedBy: currentUser?.name || 'Coordinación'
          };
        }
        return p;
      });

      return {
        ...prev,
        periodsConfig: {
          ...currentConfig,
          activeParcial: parcialId,
          periods: updatedPeriods
        }
      };
    });
    showToast(`¡${parcialId}º Parcial iniciado con éxito! El contenido nuevo pertenecerá a este parcial.`);
  };

  const handleClosePeriod = (parcialId: ParcialId) => {
    const today = getTodayDateString();
    updateData(prev => {
      const currentConfig = prev.periodsConfig || DEFAULT_PERIODS_CONFIG;
      const updatedPeriods = currentConfig.periods.map(p => {
        if (p.id === parcialId) {
          return {
            ...p,
            status: 'closed' as const,
            endDate: today,
            closedAt: today,
            closedBy: currentUser?.name || 'Coordinación'
          };
        }
        return p;
      });

      return {
        ...prev,
        periodsConfig: {
          ...currentConfig,
          periods: updatedPeriods
        }
      };
    });
    showToast(`El ${parcialId}º Parcial ha sido cerrado por Coordinación. Modo solo lectura activado.`);
  };

  const handleReopenPeriod = (parcialId: ParcialId) => {
    updateData(prev => {
      const currentConfig = prev.periodsConfig || DEFAULT_PERIODS_CONFIG;
      const updatedPeriods = currentConfig.periods.map(p => {
        if (p.id === parcialId) {
          return {
            ...p,
            status: 'active' as const,
            closedAt: undefined,
            closedBy: undefined
          };
        }
        return p;
      });

      return {
        ...prev,
        periodsConfig: {
          ...currentConfig,
          activeParcial: parcialId,
          periods: updatedPeriods
        }
      };
    });
    showToast(`El ${parcialId}º Parcial ha sido reabierto para modificaciones.`);
  };

  // -------------------------
  // Report Card Printing
  // -------------------------
  const handlePrintStudentReport = (student: Student, parcial?: ParcialId | 'all') => {
    const enrolledClasses = data.classes.filter(c => isStudentInClass(student, c));
    const classIds = new Set(enrolledClasses.map(c => c.id));
    const allStudentGrades = data.grades.filter(g => {
      const match = classIds.has(g.classId) || g.classId === student.classId;
      if (!match) return false;
      if (!parcial || parcial === 'all') return true;
      return (g.parcial || 1) === parcial;
    });
    const allStudentActivities = data.activities.filter(a => {
      const match = classIds.has(a.classId) || a.classId === student.classId;
      if (!match) return false;
      if (!parcial || parcial === 'all') return true;
      return (a.parcial || 1) === parcial;
    });

    const activeParcialFilter = !parcial || parcial === 'all' ? undefined : parcial;

    const classAverages = enrolledClasses.map(c =>
      calculateStudentAverage(student.id, c.id, data.grades, data.activities, activeParcialFilter)
    );
    const avg = classAverages.length > 0
      ? Math.round(classAverages.reduce((a, b) => a + b, 0) / classAverages.length)
      : calculateStudentAverage(student.id, student.classId, data.grades, data.activities, activeParcialFilter);

    const classAtts = enrolledClasses.map(c => calculateStudentAttendancePercentage(student.id, c.id, data.attendance));
    const att = classAtts.length > 0
      ? Math.round(classAtts.reduce((a, b) => a + b, 0) / classAtts.length)
      : calculateStudentAttendancePercentage(student.id, student.classId, data.attendance);

    const periodLabel = !parcial || parcial === 'all'
      ? 'Consolidado Anual'
      : `${parcial}º Parcial`;

    const printWin = window.open('', '_blank');
    if (!printWin) {
      window.print();
      return;
    }

    const evalRows = allStudentGrades.map(g => {
      const evalClass = data.classes.find(c => c.id === g.classId);
      const score = Number(g.scores?.[student.id] ?? 0);
      return `
        <tr>
          <td style="padding: 8px; border-bottom: 1px solid #dfe6df; font-weight: bold;">
            <span style="display: inline-block; background: #eef2ee; color: #465249; font-size: 10px; padding: 2px 6px; border-radius: 4px; margin-right: 6px;">Evaluación</span>
            ${g.title}
            ${evalClass ? `<span style="font-size: 11px; color: #2f8b3c; margin-left: 6px;">[${evalClass.name}]</span>` : ''}
          </td>
          <td style="padding: 8px; border-bottom: 1px solid #dfe6df;">${g.type}</td>
          <td style="padding: 8px; border-bottom: 1px solid #dfe6df;">${g.value}%</td>
          <td style="padding: 8px; border-bottom: 1px solid #dfe6df; font-weight: bold; color: #236a2d;">${score}</td>
          <td style="padding: 8px; border-bottom: 1px solid #dfe6df; text-align: right;">0 - ${g.scale}</td>
        </tr>
      `;
    });

    const actRows = allStudentActivities.map(a => {
      const actClass = data.classes.find(c => c.id === a.classId);
      const score = Number(a.scores?.[student.id] ?? a.studentGrades?.[student.id]?.score ?? 0);
      return `
        <tr>
          <td style="padding: 8px; border-bottom: 1px solid #dfe6df; font-weight: bold;">
            <span style="display: inline-block; background: #eaf6ec; color: #236a2d; font-size: 10px; padding: 2px 6px; border-radius: 4px; margin-right: 6px;">Actividad</span>
            ${a.title}
            ${actClass ? `<span style="font-size: 11px; color: #2f8b3c; margin-left: 6px;">[${actClass.name}]</span>` : ''}
          </td>
          <td style="padding: 8px; border-bottom: 1px solid #dfe6df;">Actividad / Tarea</td>
          <td style="padding: 8px; border-bottom: 1px solid #dfe6df;">${a.value} pts</td>
          <td style="padding: 8px; border-bottom: 1px solid #dfe6df; font-weight: bold; color: #236a2d;">${score}</td>
          <td style="padding: 8px; border-bottom: 1px solid #dfe6df; text-align: right;">0 - ${a.value}</td>
        </tr>
      `;
    });

    const rowsHtml = [...evalRows, ...actRows].join('');

    printWin.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Boleta de Calificaciones (${periodLabel}) - ${student.name}</title>
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 40px; color: #26302b; }
            .header { display: flex; align-items: center; border-bottom: 4px solid #c6292e; padding-bottom: 15px; margin-bottom: 25px; }
            .logo { height: 65px; margin-right: 20px; }
            h1 { font-size: 20px; margin: 0; color: #26302b; }
            h2 { font-size: 13px; margin: 5px 0 0 0; color: #546057; }
            .student-card { background: #f7f8f6; padding: 15px; border-radius: 8px; margin-bottom: 25px; display: grid; grid-template-columns: 2fr 1fr; gap: 10px; font-size: 13px; }
            .metrics { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 25px; text-align: center; }
            .metric-box { border: 1px solid #dfe6df; border-radius: 8px; padding: 12px; }
            .metric-val { font-size: 22px; font-weight: 900; color: #236a2d; margin-top: 4px; }
            table { width: 100%; border-collapse: collapse; font-size: 13px; margin-bottom: 25px; }
            th { background: #f7f8f6; padding: 10px; text-align: left; font-size: 12px; text-transform: uppercase; border-bottom: 2px solid #cad4cb; }
            .notes { background: #f7f8f6; padding: 15px; border-radius: 8px; font-size: 12px; line-height: 1.5; margin-bottom: 40px; }
            .signatures { display: grid; grid-template-columns: 1fr 1fr; gap: 60px; margin-top: 50px; text-align: center; font-size: 12px; color: #546057; }
            .sig-line { border-top: 1px solid #cad4cb; padding-top: 8px; }
          </style>
        </head>
        <body>
          <div class="header">
            <img src="${HOGAR_LOGO}" class="logo" />
            <div>
              <h1>DOCENTES EL HOGAR</h1>
              <h2>Hogar de Amor y Esperanza · Boletín Oficial de Progreso Académico · ${periodLabel}</h2>
            </div>
          </div>

          <div class="student-card">
            <div>
              <strong style="font-size: 15px;">${student.name}</strong><br/>
              <span>Grado: ${student.grade || '—'} · Sección: ${student.section || '—'} · Materias inscritas: ${enrolledClasses.length}</span>
            </div>
            <div style="text-align: right;">
              <span>Código: <strong>${student.code || 'S/C'}</strong></span><br/>
              <span>Fecha: ${new Date().toLocaleDateString('es-ES')}</span>
            </div>
          </div>

          <div class="metrics">
            <div class="metric-box">
              <div style="font-size: 11px; color: #6d766f; font-weight: bold;">PROMEDIO FINAL</div>
              <div class="metric-val">${avg}%</div>
            </div>
            <div class="metric-box">
              <div style="font-size: 11px; color: #6d766f; font-weight: bold;">ASISTENCIA</div>
              <div class="metric-val" style="color: #26302b;">${att}%</div>
            </div>
            <div class="metric-box">
              <div style="font-size: 11px; color: #6d766f; font-weight: bold;">ESTADO</div>
              <div class="metric-val" style="color: #c6292e; font-size: 18px;">${student.status}</div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>Evaluación</th>
                <th>Tipo</th>
                <th>Ponderación</th>
                <th>Nota</th>
                <th style="text-align: right;">Escala</th>
              </tr>
            </thead>
            <tbody>
              ${rowsHtml || '<tr><td colspan="5" style="padding: 15px; text-align: center; color: #6d766f;">No hay evaluaciones registradas</td></tr>'}
            </tbody>
          </table>

          <div class="notes">
            <strong>Observaciones del docente:</strong><br/>
            ${student.notes || 'El estudiante muestra un desempeño satisfactorio en las actividades del período escolar.'}
          </div>

          <div class="signatures">
            <div class="sig-line">Lic. Titular de Asignatura</div>
            <div class="sig-line">Dirección Académica</div>
          </div>
        </body>
      </html>
    `);

    printWin.document.close();
    printWin.focus();
    setTimeout(() => {
      printWin.print();
    }, 500);
  };

  // -------------------------
  // Forum Handlers
  // -------------------------
  const handleSaveForumTopic = (topicData: Partial<ForumTopic>) => {
    if (!currentUser) return;
    updateData(prev => {
      const currentTopics = prev.forumTopics || [];
      if (topicData.id) {
        const updated = currentTopics.map(t =>
          t.id === topicData.id
            ? ({
                ...t,
                ...topicData,
                updatedAt: new Date().toISOString()
              } as ForumTopic)
            : t
        );
        return { ...prev, forumTopics: updated };
      } else {
        const newTopic: ForumTopic = {
          id: `topic-${Date.now()}`,
          title: topicData.title || '',
          description: topicData.description || '',
          classId: topicData.classId || 'all',
          activityId: topicData.activityId || undefined,
          authorId: currentUser.id,
          authorName: currentUser.name,
          authorRole: currentUser.role as 'admin' | 'teacher',
          createdAt: new Date().toISOString(),
          status: topicData.status || 'open',
          category: topicData.category || 'debate',
          parcial: topicData.parcial,
          pinned: topicData.pinned || false,
          attachments: topicData.attachments || []
        };
        return {
          ...prev,
          forumTopics: [newTopic, ...currentTopics]
        };
      }
    });
    showToast('¡Actividad en el foro guardada con éxito!');
  };

  const handleDeleteForumTopic = (topicId: string) => {
    updateData(prev => {
      const currentTopics = prev.forumTopics || [];
      const currentComments = prev.forumComments || [];
      return {
        ...prev,
        forumTopics: currentTopics.filter(t => t.id !== topicId),
        forumComments: currentComments.filter(c => c.topicId !== topicId)
      };
    });
    showToast('Tema y respuestas eliminadas del foro.');
  };

  const handleToggleForumTopicStatus = (topicId: string) => {
    let nextStatus = 'open';
    updateData(prev => {
      const currentTopics = prev.forumTopics || [];
      const updated = currentTopics.map(t => {
        if (t.id === topicId) {
          nextStatus = t.status === 'open' ? 'closed' : 'open';
          return { ...t, status: nextStatus as 'open' | 'closed' };
        }
        return t;
      });
      return { ...prev, forumTopics: updated };
    });
    showToast(nextStatus === 'open' ? 'Foro reabierto para opiniones de los alumnos' : 'Foro cerrado para nuevas opiniones');
  };

  const handleToggleForumTopicPin = (topicId: string) => {
    updateData(prev => {
      const currentTopics = prev.forumTopics || [];
      const updated = currentTopics.map(t => {
        if (t.id === topicId) {
          return { ...t, pinned: !t.pinned };
        }
        return t;
      });
      return { ...prev, forumTopics: updated };
    });
  };

  const handleAddForumComment = (commentData: Omit<ForumComment, 'id' | 'createdAt'>) => {
    const newComment: ForumComment = {
      ...commentData,
      id: `comm-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    updateData(prev => {
      const currentComments = prev.forumComments || [];
      return {
        ...prev,
        forumComments: [...currentComments, newComment]
      };
    });
    showToast('¡Tu opinión ha sido publicada y ya es visible para todos!');
  };

  const handleDeleteForumComment = (commentId: string) => {
    updateData(prev => {
      const currentComments = prev.forumComments || [];
      const filtered = currentComments.filter(c => c.id !== commentId && c.parentId !== commentId);
      return {
        ...prev,
        forumComments: filtered
      };
    });
    showToast('Comentario eliminado.');
  };

  const handleToggleLikeForumComment = (commentId: string) => {
    if (!currentUser) return;
    updateData(prev => {
      const currentComments = prev.forumComments || [];
      const updated = currentComments.map(c => {
        if (c.id === commentId) {
          const currentLikes = c.likes || [];
          const hasLiked = currentLikes.includes(currentUser.id);
          const nextLikes = hasLiked
            ? currentLikes.filter(uid => uid !== currentUser.id)
            : [...currentLikes, currentUser.id];
          return { ...c, likes: nextLikes };
        }
        return c;
      });
      return { ...prev, forumComments: updated };
    });
  };

  const handleToggleHighlightForumComment = (commentId: string) => {
    let isNowHighlighted = false;
    updateData(prev => {
      const currentComments = prev.forumComments || [];
      const updated = currentComments.map(c => {
        if (c.id === commentId) {
          isNowHighlighted = !c.highlighted;
          return { ...c, highlighted: isNowHighlighted };
        }
        return c;
      });
      return { ...prev, forumComments: updated };
    });
    showToast(isNowHighlighted ? 'Respuesta destacada por el docente ⭐' : 'Destacado removido');
  };

  const handleOpenForumForActivity = (activityId: string, classId: string) => {
    const existingTopic = (data.forumTopics || []).find(t => t.activityId === activityId);
    if (existingTopic) {
      setForumTargetTopicId(existingTopic.id);
      setActiveSection('forum');
    } else {
      if (currentUser?.role === 'admin' || currentUser?.role === 'teacher') {
        setForumInitialClassId(classId || 'all');
        setForumInitialActivityId(activityId);
        setEditingForumTopic(null);
        setForumTopicModalOpen(true);
      } else {
        setTargetClassFilter(classId);
        setActiveSection('forum');
        showToast('Aún no se ha iniciado un debate en el foro para esta tarea.');
      }
    }
  };

  // If no user is logged in, show the login screen
  if (!currentUser) {
    return (
      <>
        {toastMessage && (
          <div className="fixed bottom-5 right-5 z-50 rounded-2xl border border-[#2f8b3c] bg-[#236a2d] px-5 py-3 text-xs font-bold text-white shadow-xl animate-fade-in">
            {toastMessage}
          </div>
        )}
        <LoginView
          users={data.users}
          onLogin={handleLogin}
          onRegisterAdmin={handleRegisterAdmin}
          inactivityMessage={inactivityNotice}
        />
      </>
    );
  }

  // Active section view resolver
  const renderActiveView = () => {
    switch (activeSection) {
      case 'dashboard':
        return (
          <DashboardView
            data={data}
            currentUser={currentUser}
            onNavigate={setActiveSection}
            onOpenAddClass={() => {
              setEditingClass(null);
              setClassModalOpen(true);
            }}
            onOpenAddStudent={() => {
              setEditingStudent(null);
              setStudentModalClassId('');
              setStudentModalOpen(true);
            }}
            onOpenAddResource={() => {
              setEditingResource(null);
              setResourceModalOpen(true);
            }}
            onOpenAddPlan={() => {
              setEditingPlan(null);
              setPlanModalOpen(true);
            }}
            onOpenAddActivity={() => {
              setEditingActivity(null);
              setActivityModalOpen(true);
            }}
            onDownloadResource={handleDownloadResource}
            onToggleFavoriteResource={handleToggleFavoriteResource}
          />
        );

      case 'classes':
        return (
          <ClassesView
            data={data}
            currentUser={currentUser}
            onAddClass={(defaultGrade?: string) => {
              setEditingClass(null);
              setClassModalDefaultGrade(defaultGrade || '');
              setClassModalOpen(true);
            }}
            onEditClass={cls => {
              setEditingClass(cls);
              setClassModalOpen(true);
            }}
            onDeleteClass={handleDeleteClass}
            onViewClassStudents={classId => {
              setTargetClassFilter(classId);
              setActiveSection('students');
            }}
            onViewClassGrades={classId => {
              setTargetClassFilter(classId);
              setActiveSection('grades');
            }}
            onViewClassActivities={classId => {
              setTargetClassFilter(classId);
              setActiveSection('activities');
            }}
            onAddStudentToClass={(classId, defaultGrade) => {
              setEditingStudent(null);
              setStudentModalClassId(classId || '');
              setStudentModalDefaultGrade(defaultGrade || '');
              setStudentModalOpen(true);
            }}
          />
        );

      case 'students':
        return (
          <StudentsView
            data={data}
            currentUser={currentUser}
            initialClassFilter={targetClassFilter}
            onAddStudent={() => {
              setEditingStudent(null);
              setStudentModalClassId(targetClassFilter);
              const targetCls = data.classes.find(c => c.id === targetClassFilter);
              setStudentModalDefaultGrade(targetCls?.grade || '');
              setStudentModalOpen(true);
            }}
            onOpenBulkImport={() => setBulkStudentOpen(true)}
            onViewStudentProfile={st => setProfileStudent(st)}
            onEditStudent={st => {
              setEditingStudent(st);
              setStudentModalOpen(true);
            }}
            onDeleteStudent={handleDeleteStudent}
            onManageAccess={handleOpenStudentAccess}
          />
        );

      case 'resources':
        return (
          <ResourcesView
            data={data}
            currentUser={currentUser}
            onAddResource={() => {
              setEditingResource(null);
              setResourceModalOpen(true);
            }}
            onEditResource={r => {
              setEditingResource(r);
              setResourceModalOpen(true);
            }}
            onDeleteResource={handleDeleteResource}
            onDownloadResource={handleDownloadResource}
            onToggleFavorite={handleToggleFavoriteResource}
          />
        );

      case 'planning':
        return (
          <PlanningView
            data={data}
            currentUser={currentUser}
            onAddPlan={() => {
              setEditingPlan(null);
              setPlanModalOpen(true);
            }}
            onEditPlan={p => {
              setEditingPlan(p);
              setPlanModalOpen(true);
            }}
            onDuplicatePlan={handleDuplicatePlan}
            onDeletePlan={handleDeletePlan}
            onViewPlanDetail={p => setDetailPlan(p)}
          />
        );

      case 'activities':
        return (
          <ActivitiesView
            data={data}
            currentUser={currentUser}
            periodsConfig={data.periodsConfig}
            initialClassId={targetClassFilter}
            onAddActivity={() => {
              setEditingActivity(null);
              setActivityModalOpen(true);
            }}
            onEditActivity={act => {
              setEditingActivity(act);
              setActivityModalOpen(true);
            }}
            onDeleteActivity={handleDeleteActivity}
            onUpdateStatus={handleUpdateActivityStatus}
            onSaveActivityGrades={handleSaveActivityGrades}
            onSubmitHomework={handleSubmitHomework}
            onGoToGrades={classId => {
              setTargetClassFilter(classId);
              setActiveSection('grades');
            }}
            onOpenForumForActivity={handleOpenForumForActivity}
          />
        );

      case 'forum':
        return (
          <ForumView
            data={data}
            currentUser={currentUser}
            periodsConfig={data.periodsConfig}
            initialTopicId={forumTargetTopicId || undefined}
            initialClassId={targetClassFilter || undefined}
            onOpenCreateTopic={(classId, activityId) => {
              setEditingForumTopic(null);
              setForumInitialClassId(classId || 'all');
              setForumInitialActivityId(activityId || '');
              setForumTopicModalOpen(true);
            }}
            onEditTopic={topic => {
              setEditingForumTopic(topic);
              setForumInitialClassId(topic.classId || 'all');
              setForumInitialActivityId(topic.activityId || '');
              setForumTopicModalOpen(true);
            }}
            onDeleteTopic={handleDeleteForumTopic}
            onToggleTopicStatus={handleToggleForumTopicStatus}
            onToggleTopicPin={handleToggleForumTopicPin}
            onAddComment={handleAddForumComment}
            onDeleteComment={handleDeleteForumComment}
            onToggleLikeComment={handleToggleLikeForumComment}
            onToggleHighlightComment={handleToggleHighlightForumComment}
            onNavigateToActivity={actId => {
              const act = data.activities.find(a => a.id === actId);
              if (act) {
                setTargetClassFilter(act.classId);
              }
              setActiveSection('activities');
            }}
          />
        );

      case 'grades':
        return (
          <GradesView
            data={data}
            currentUser={currentUser}
            initialClassId={targetClassFilter}
            onAddEvaluation={clsId => {
              setEvaluationClassId(clsId);
              setEvaluationModalOpen(true);
            }}
            onDeleteEvaluation={handleDeleteEvaluation}
            onUpdateScore={handleUpdateScore}
            onUpdateActivityScore={handleUpdateActivityScore}
            onDeleteActivity={handleDeleteActivity}
            onAddActivity={clsId => {
              setEditingActivity(null);
              if (clsId) setTargetClassFilter(clsId);
              setActivityModalOpen(true);
            }}
            onAddClass={() => {
              setEditingClass(null);
              setClassModalOpen(true);
            }}
            onAddStudent={clsId => {
              setEditingStudent(null);
              setStudentModalClassId(clsId);
              const targetCls = data.classes.find(c => c.id === clsId);
              setStudentModalDefaultGrade(targetCls?.grade || '');
              setStudentModalOpen(true);
            }}
          />
        );

      case 'attendance':
        return (
          <AttendanceView
            data={data}
            currentUser={currentUser}
            initialClassId={targetClassFilter}
            onSetAttendance={handleSetAttendance}
            onMarkAllPresent={handleMarkAllPresent}
            onSaveToast={() => showToast('¡Asistencia guardada en el sistema!')}
          />
        );

      case 'reports':
        return (
          <ReportsView
            data={data}
            currentUser={currentUser}
            periodsConfig={data.periodsConfig}
            initialStudentId={targetStudentId}
            onPrintStudentReport={handlePrintStudentReport}
          />
        );

      case 'calendar':
        return (
          <CalendarView
            data={data}
            currentUser={currentUser}
            onAddEvent={() => setEventModalOpen(true)}
            onDeleteEvent={handleDeleteEvent}
          />
        );

      case 'admin':
        return (
          <AdminView
            data={data}
            currentUser={currentUser}
            periodsConfig={data.periodsConfig}
            onAddUser={() => {
              setEditingUser(null);
              setUserModalOpen(true);
            }}
            onEditUser={u => {
              setEditingUser(u);
              setUserModalOpen(true);
            }}
            onResetPassword={u => {
              setPasswordTargetUser(u);
              setPasswordModalOpen(true);
            }}
            onToggleUserActive={handleToggleUserActive}
            onDeleteUser={handleDeleteUser}
            onRestoreBackup={handleRestoreBackup}
            onEmptyDatabase={handleEmptyDatabase}
            onStartPeriod={handleStartPeriod}
            onClosePeriod={handleClosePeriod}
            onReopenPeriod={handleReopenPeriod}
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen w-full overflow-hidden bg-[#f4f7f4] text-[#26302b]">
      {/* Toast message alert */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 rounded-2xl border border-[#2f8b3c] bg-[#236a2d] px-5 py-3 text-xs font-bold text-white shadow-xl animate-fade-in">
          {toastMessage}
        </div>
      )}

      {/* Responsive Sidebar */}
      <Sidebar
        currentUser={currentUser}
        currentSection={activeSection}
        isOpenMobile={sidebarOpen}
        onSelectSection={sec => {
          setActiveSection(sec);
          setSidebarOpen(false);
        }}
        onCloseMobile={() => setSidebarOpen(false)}
        onLogout={handleLogout}
      />

      {/* Main Content Area */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Top Navbar */}
        <Navbar
          currentUser={currentUser}
          currentSection={activeSection}
          notificationCount={
            data.activities.filter(a => a.status === 'Pendiente').length + data.events.length
          }
          periodsConfig={data.periodsConfig}
          onOpenPeriodsControl={() => setPeriodsControlModalOpen(true)}
          onOpenDownloadCode={() => setDownloadCodeModalOpen(true)}
          isFirebaseSynced={isFirebaseSynced}
          isSyncing={isSyncing}
          onLogout={handleLogout}
          onOpenNotifications={() => setIsNotificationsOpen(true)}
          onOpenMobileMenu={() => setSidebarOpen(prev => !prev)}
        />

        {/* Scrollable View Viewport */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">{renderActiveView()}</main>
      </div>

      {/* Modals */}
      {isNotificationsOpen && (
        <NotificationsModal
          data={data}
          onClose={() => setIsNotificationsOpen(false)}
          onNavigate={setActiveSection}
        />
      )}

      <StudentAccessModal
        isOpen={accessStudentModalOpen}
        student={accessTargetStudent}
        existingUser={
          accessTargetStudent
            ? data.users.find(
                u =>
                  u.id === accessTargetStudent.userId ||
                  (u.role === 'student' &&
                    u.name.toLowerCase() === accessTargetStudent.name.toLowerCase())
              ) || null
            : null
        }
        allUsers={data.users}
        onClose={() => {
          setAccessStudentModalOpen(false);
          setAccessTargetStudent(null);
        }}
        onSaveAccess={handleSaveStudentAccess}
      />

      <ClassModal
        isOpen={classModalOpen}
        classItem={editingClass}
        teachers={data.users}
        students={data.students}
        defaultGrade={classModalDefaultGrade}
        onClose={() => {
          setClassModalOpen(false);
          setEditingClass(null);
          setClassModalDefaultGrade('');
        }}
        onSave={handleSaveClass}
      />

      <StudentModal
        isOpen={studentModalOpen}
        student={editingStudent}
        classes={data.classes}
        defaultClassId={studentModalClassId}
        defaultGrade={studentModalDefaultGrade}
        currentUser={currentUser}
        onClose={() => {
          setStudentModalOpen(false);
          setEditingStudent(null);
          setStudentModalDefaultGrade('');
        }}
        onSave={handleSaveStudent}
      />

      <BulkStudentModal
        isOpen={bulkStudentOpen}
        classes={data.classes}
        onClose={() => setBulkStudentOpen(false)}
        onImport={handleBulkImportStudents}
      />

      {profileStudent && (
        <StudentProfileModal
          student={profileStudent}
          data={data}
          onClose={() => setProfileStudent(null)}
          onEdit={st => {
            setProfileStudent(null);
            setEditingStudent(st);
            setStudentModalOpen(true);
          }}
          onPrintReport={st => handlePrintStudentReport(st)}
        />
      )}

      <ResourceModal
        isOpen={resourceModalOpen}
        resource={editingResource}
        classes={data.classes}
        currentUser={currentUser}
        onClose={() => {
          setResourceModalOpen(false);
          setEditingResource(null);
        }}
        onSave={handleSaveResource}
      />

      <PlanModal
        isOpen={planModalOpen}
        plan={editingPlan}
        classes={getAllowedClasses(data.classes, currentUser, data.students)}
        onClose={() => {
          setPlanModalOpen(false);
          setEditingPlan(null);
        }}
        onSave={handleSavePlan}
      />

      {detailPlan && (
        <PlanDetailModal
          plan={detailPlan}
          classes={data.classes}
          onClose={() => setDetailPlan(null)}
          onEdit={p => {
            setDetailPlan(null);
            setEditingPlan(p);
            setPlanModalOpen(true);
          }}
          onDuplicate={pId => {
            handleDuplicatePlan(pId);
            setDetailPlan(null);
          }}
        />
      )}

      <ActivityModal
        isOpen={activityModalOpen}
        activity={editingActivity}
        classes={getAllowedClasses(data.classes, currentUser, data.students)}
        periodsConfig={data.periodsConfig}
        onClose={() => {
          setActivityModalOpen(false);
          setEditingActivity(null);
        }}
        onSave={handleSaveActivity}
      />

      {currentUser && (currentUser.role === 'admin' || currentUser.role === 'teacher') && (
        <ForumTopicModal
          isOpen={forumTopicModalOpen}
          topic={editingForumTopic}
          classes={getAllowedClasses(data.classes, currentUser, data.students)}
          activities={data.activities}
          currentUser={currentUser}
          periodsConfig={data.periodsConfig}
          initialClassId={forumInitialClassId}
          initialActivityId={forumInitialActivityId}
          onClose={() => {
            setForumTopicModalOpen(false);
            setEditingForumTopic(null);
            setForumInitialClassId('all');
            setForumInitialActivityId('');
          }}
          onSave={handleSaveForumTopic}
        />
      )}

      <EvaluationModal
        isOpen={evaluationModalOpen}
        classes={data.classes}
        defaultClassId={evaluationClassId}
        periodsConfig={data.periodsConfig}
        onClose={() => setEvaluationModalOpen(false)}
        onSave={handleSaveEvaluation}
      />

      <EventModal
        isOpen={eventModalOpen}
        classes={data.classes}
        onClose={() => setEventModalOpen(false)}
        onSave={handleSaveEvent}
      />

      <UserModal
        isOpen={userModalOpen}
        user={editingUser}
        onClose={() => {
          setUserModalOpen(false);
          setEditingUser(null);
        }}
        onSave={handleSaveUser}
      />

      <PasswordModal
        isOpen={passwordModalOpen}
        user={passwordTargetUser}
        onClose={() => {
          setPasswordModalOpen(false);
          setPasswordTargetUser(null);
        }}
        onSave={handleResetPassword}
      />

      <DeleteAdminModal
        isOpen={deleteAdminModalOpen}
        user={adminTargetToDelete}
        onClose={() => {
          setDeleteAdminModalOpen(false);
          setAdminTargetToDelete(null);
        }}
        onConfirm={userId => {
          executeDeleteUser(userId);
          setDeleteAdminModalOpen(false);
          setAdminTargetToDelete(null);
        }}
      />

      {currentUser?.role === 'admin' && (
        <PeriodsControlModal
          isOpen={periodsControlModalOpen}
          periodsConfig={data.periodsConfig || DEFAULT_PERIODS_CONFIG}
          data={data}
          currentUser={currentUser}
          onClose={() => setPeriodsControlModalOpen(false)}
          onStartPeriod={handleStartPeriod}
          onClosePeriod={handleClosePeriod}
          onReopenPeriod={handleReopenPeriod}
        />
      )}

      <DownloadCodeModal
        isOpen={downloadCodeModalOpen}
        onClose={() => setDownloadCodeModalOpen(false)}
        data={data}
        periodsConfig={data.periodsConfig}
      />
    </div>
  );
}
