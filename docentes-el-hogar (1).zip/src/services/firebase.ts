import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { initializeFirestore, getFirestore, Firestore, doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import {
  getStorage,
  FirebaseStorage,
  ref,
  uploadBytes,
  uploadBytesResumable,
  getDownloadURL,
  deleteObject
} from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';
import { AppData } from '../types';

let app: FirebaseApp;
if (!getApps().length) {
  app = initializeApp(firebaseConfig);
} else {
  app = getApp();
}

const firestoreDbId =
  firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId !== '(default)'
    ? firebaseConfig.firestoreDatabaseId
    : undefined;

let firestoreInstance: Firestore;
try {
  firestoreInstance = initializeFirestore(app, {
    ignoreUndefinedProperties: true
  }, firestoreDbId);
} catch {
  firestoreInstance = firestoreDbId ? getFirestore(app, firestoreDbId) : getFirestore(app);
}

export const db: Firestore = firestoreInstance;

// Initialize Firebase Cloud Storage
const storageBucketUrl = firebaseConfig.storageBucket
  ? (firebaseConfig.storageBucket.startsWith('gs://')
      ? firebaseConfig.storageBucket
      : `gs://${firebaseConfig.storageBucket}`)
  : undefined;

let storageInstance: FirebaseStorage;
try {
  storageInstance = storageBucketUrl ? getStorage(app, storageBucketUrl) : getStorage(app);
} catch (err) {
  console.warn('Fallback initializing default storage:', err);
  storageInstance = getStorage(app);
}

export const storage: FirebaseStorage = storageInstance;

export const SYSTEM_DATA_DOC = 'main_school_data';

/**
 * Returns the configured Cloud Storage bucket name
 */
export function getStorageBucketName(): string {
  return firebaseConfig.storageBucket || 'trim-beach-0mn89.firebasestorage.app';
}

/**
 * Verifies if Cloud Storage configuration exists
 */
export function isCloudStorageConfigured(): boolean {
  return Boolean(firebaseConfig.storageBucket);
}

/**
 * Uploads a file or blob directly to Firebase Cloud Storage.
 * Supports progress tracking callback for user interface feedback.
 */
export async function uploadFileToStorage(
  file: File | Blob,
  path: string,
  onProgress?: (percent: number) => void
): Promise<{ downloadUrl: string; storagePath: string }> {
  try {
    const fileRef = ref(storage, path);

    if (onProgress && typeof (file as any).size === 'number' && (file as any).size > 0) {
      return await new Promise<{ downloadUrl: string; storagePath: string }>((resolve, reject) => {
        const uploadTask = uploadBytesResumable(fileRef, file);

        uploadTask.on(
          'state_changed',
          (snapshot) => {
            if (snapshot.totalBytes > 0) {
              const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
              onProgress(Math.round(progress));
            }
          },
          (error) => {
            console.error('Error during upload to Cloud Storage:', error);
            reject(error);
          },
          async () => {
            try {
              const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);
              resolve({ downloadUrl, storagePath: path });
            } catch (err) {
              reject(err);
            }
          }
        );
      });
    } else {
      const snapshot = await uploadBytes(fileRef, file);
      const downloadUrl = await getDownloadURL(snapshot.ref);
      return { downloadUrl, storagePath: path };
    }
  } catch (error) {
    console.error(`Failed to upload file to Cloud Storage at path "${path}":`, error);
    throw error;
  }
}

/**
 * Deletes a file from Firebase Cloud Storage by its path
 */
export async function deleteFileFromStorage(storagePath: string): Promise<boolean> {
  if (!storagePath) return false;
  try {
    const fileRef = ref(storage, storagePath);
    await deleteObject(fileRef);
    return true;
  } catch (error) {
    console.warn(`Could not delete file from Cloud Storage (${storagePath}):`, error);
    return false;
  }
}

/**
 * Tests connection and permissions to Firebase Cloud Storage
 */
export async function testStorageConnection(): Promise<{ success: boolean; bucket: string; message: string }> {
  const bucket = getStorageBucketName();
  try {
    const testPath = `health_checks/test_${Date.now()}.txt`;
    const testBlob = new Blob([`Health check test from Docentes El Hogar at ${new Date().toISOString()}`], {
      type: 'text/plain;charset=utf-8'
    });
    const testRef = ref(storage, testPath);
    await uploadBytes(testRef, testBlob);
    const downloadUrl = await getDownloadURL(testRef);

    // Clean up test file immediately
    deleteObject(testRef).catch(() => {});

    return {
      success: true,
      bucket,
      message: `Conexión a Firebase Cloud Storage establecida con éxito en el bucket "${bucket}". URL de prueba verificada.`
    };
  } catch (err: any) {
    console.warn('Cloud Storage connection test warning/error:', err);
    return {
      success: false,
      bucket,
      message: err?.message || 'Error al conectar con Cloud Storage. Revisa las reglas o la conexión.'
    };
  }
}

/**
 * Upload entire app data to Firestore
 */
export async function syncAppDataToFirestore(data: AppData): Promise<void> {
  try {
    const docRef = doc(db, 'system_data', SYSTEM_DATA_DOC);
    // Sanitize data to strip any undefined values and preserve valid JSON types
    const sanitized = JSON.parse(JSON.stringify(data));
    await setDoc(docRef, {
      ...sanitized,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (error) {
    console.error('Error synchronizing data to Firebase Firestore:', error);
    throw error;
  }
}

/**
 * Fetch latest app data from Firestore once
 */
export async function fetchAppDataFromFirestore(): Promise<AppData | null> {
  try {
    const docRef = doc(db, 'system_data', SYSTEM_DATA_DOC);
    const snapshot = await getDoc(docRef);
    if (snapshot.exists()) {
      return snapshot.data() as AppData;
    }
    return null;
  } catch (error) {
    console.warn('Could not fetch from Firestore, will use local storage:', error);
    return null;
  }
}

/**
 * Subscribe to real-time updates from Firestore
 */
export function subscribeToFirestoreData(
  onData: (data: AppData) => void,
  onError?: (err: Error) => void
): () => void {
  const docRef = doc(db, 'system_data', SYSTEM_DATA_DOC);
  return onSnapshot(
    docRef,
    { includeMetadataChanges: true },
    (snapshot) => {
      // Avoid circular feedback loop from local writes
      if (snapshot.metadata.hasPendingWrites) {
        return;
      }
      if (snapshot.exists()) {
        const cloudData = snapshot.data() as AppData;
        onData(cloudData);
      }
    },
    (err) => {
      console.warn('Firestore subscription warning/error:', err);
      onError?.(err);
    }
  );
}

export { app };
