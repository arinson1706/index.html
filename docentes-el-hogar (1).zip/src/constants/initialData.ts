import { AppData, AcademicPeriod, PeriodsConfig } from '../types';

export const HOGAR_LOGO = '/logo.png';
export const ADMIN_MASTER_KEY = 'HAYE';

export const DEFAULT_PERIODS: AcademicPeriod[] = [
  {
    id: 1,
    name: '1er Parcial',
    status: 'active',
    startDate: '2026-02-01'
  },
  {
    id: 2,
    name: '2do Parcial',
    status: 'upcoming',
    startDate: '2026-04-15'
  },
  {
    id: 3,
    name: '3er Parcial',
    status: 'upcoming',
    startDate: '2026-07-01'
  },
  {
    id: 4,
    name: '4to Parcial',
    status: 'upcoming',
    startDate: '2026-09-15'
  }
];

export const DEFAULT_PERIODS_CONFIG: PeriodsConfig = {
  activeParcial: 1,
  periods: DEFAULT_PERIODS
};

export const STANDARD_GRADES = [
  { value: '1ro', label: '1ro Primaria' },
  { value: '2do', label: '2do Primaria' },
  { value: '3ro', label: '3ro Primaria' },
  { value: '4to', label: '4to Primaria' },
  { value: '5to', label: '5to Primaria' },
  { value: '6to', label: '6to Primaria' },
  { value: '7mo', label: '7mo Básica' },
  { value: '8vo', label: '8vo Básica' },
  { value: '9no', label: '9no Básica' },
  { value: '10mo', label: '10mo Básica' },
  { value: '11mo', label: '11mo Diversificado' }
];

export const COMMON_SUBJECTS = [
  'Matemáticas',
  'Lengua Española',
  'Ciencias Naturales',
  'Estudios Sociales',
  'Inglés',
  'Educación Física',
  'Educación Artística',
  'Informática',
  'Formación Humana'
];

export const INITIAL_DATA: AppData = {
  users: [
    {
      id: 'u-admin',
      name: 'Dirección Académica',
      username: 'admin',
      password: '123',
      role: 'admin',
      active: true,
      email: 'direccion@elhogar.edu'
    }
  ],
  classes: [],
  students: [],
  resources: [],
  plans: [],
  activities: [],
  forumTopics: [
    {
      id: 'topic-init-1',
      title: 'Debate: El impacto de la lectura diaria en nuestro aprendizaje escolar',
      description: 'Queridos estudiantes y docentes de la Escuela Hogar de Amor y Esperanza:\n\nLos invitamos a reflexionar sobre cómo el hábito de leer al menos 20 minutos al día influye en su vocabulario, pensamiento crítico y rendimiento escolar.\n\n¿Qué libro, cuento o lectura te ha gustado más este año? Comparte tu opinión para que todos tus compañeros y maestros podamos leer tus reflexiones.',
      classId: 'all',
      authorId: 'u-admin',
      authorName: 'Dirección Académica',
      authorRole: 'admin',
      createdAt: '2026-09-20T08:30:00.000Z',
      status: 'open',
      parcial: 1,
      pinned: true,
      category: 'debate',
      tags: ['Lectura', 'Valores', 'Debate']
    },
    {
      id: 'topic-init-2',
      title: 'Foro de Discusión: Estrategias de estudio y consultas sobre tareas',
      description: 'Espacio abierto para resolver dudas sobre las tareas del 1er Parcial y compartir técnicas de estudio efectivas.\n\n¿Cómo organizas tu tiempo para hacer tareas? Si tienes dudas sobre alguna actividad escolar, compártela aquí para que los docentes y compañeros te ayuden.',
      classId: 'all',
      authorId: 'u-admin',
      authorName: 'Dirección Académica',
      authorRole: 'admin',
      createdAt: '2026-09-22T10:00:00.000Z',
      status: 'open',
      parcial: 1,
      pinned: false,
      category: 'pregunta',
      tags: ['Estrategias', 'Tareas', '1er Parcial']
    }
  ],
  forumComments: [
    {
      id: 'comm-init-1',
      topicId: 'topic-init-1',
      authorId: 'u-admin',
      authorName: 'Dirección Académica',
      authorRole: 'admin',
      content: '¡Bienvenidos todos los estudiantes al nuevo Foro Escolar! Recuerden que pueden escribir con total libertad, amabilidad y respeto mutuo. Este espacio es para escucharnos y aprender juntos.',
      createdAt: '2026-09-20T09:00:00.000Z',
      isTeacherFeedback: true,
      highlighted: true,
      likes: []
    }
  ],
  grades: [],
  attendance: {},
  events: [],
  periodsConfig: DEFAULT_PERIODS_CONFIG
};

