export type UserRole = 'admin' | 'teacher' | 'student';

export type ParcialId = 1 | 2 | 3 | 4;

export interface AcademicPeriod {
  id: ParcialId;
  name: string; // e.g. '1er Parcial', '2do Parcial', '3er Parcial', '4to Parcial'
  status: 'active' | 'closed' | 'upcoming';
  startDate?: string;
  endDate?: string;
  closedDate?: string;
  closedBy?: string;
}

export interface PeriodsConfig {
  activeParcial: ParcialId;
  periods: AcademicPeriod[];
}

export interface User {
  id: string;
  name: string;
  username: string;
  password?: string;
  role: UserRole;
  active: boolean;
  email?: string;
  avatar?: string;
}

export interface ClassRoom {
  id: string;
  name: string;
  grade: string;
  section: string;
  year: string;
  subject: string;
  teacherId?: string;
}

export interface Student {
  id: string;
  userId?: string;
  name: string;
  code: string;
  classId: string;
  enrolledClassIds?: string[];
  grade: string;
  section: string;
  birth?: string;
  guardianName?: string;
  guardianPhone?: string;
  contact?: string;
  status: 'Activo' | 'Inactivo';
  notes?: string;
}

export interface Resource {
  id: string;
  name: string;
  type: string;
  grade: string;
  classId: string;
  subject: string;
  unit: string;
  topic: string;
  favorite: boolean;
  date: string;
  size: number;
  mime?: string;
  fileStored?: boolean;
  fileDataUrl?: string;
  storageUrl?: string;
  storagePath?: string;
  uploadedByRole?: 'admin' | 'teacher';
  uploadedByName?: string;
}

export interface LessonPlan {
  id: string;
  title: string;
  year: string;
  classId?: string; // Clase que se está planificando
  date: string; // Fecha de la clase

  // Formato oficial Escuela Hogar de Amor y Esperanza
  subject: string; // Espacio Curricular
  topic: string; // Tema
  level?: string; // Nivel (Educación Básica, Primaria, etc.)
  grade: string; // Grado
  expectations?: string; // Expectativas de Logro
  standard?: string; // Estándar
  conceptualContent?: string; // 1. Contenido Conceptual
  attitudinalContent?: string; // 2. Contenido Actitudinal
  methodology?: string; // 2. Metodología
  teachingStrategies?: string; // 3. Estrategias de Enseñanza
  resources: string; // 4. Recursos
  knowledgeReactivation?: string; // 5. Reactivación de los conocimientos
  knowledgeApplication?: string; // 6. Aplicación de los Conocimientos
  knowledgeOrganization?: string; // 7. Organización del Conocimiento
  evaluationStrategies?: string; // 8. Estrategias de Evaluación

  // Campos adicionales / retrocompatibilidad
  unit?: string;
  competency?: string;
  objective?: string;
  content?: string;
  activities?: string;
  strategies?: string;
  evaluation?: string;
  template?: boolean;
  teacherId?: string;
  isCoordination?: boolean;
  parcial?: ParcialId;
  attachments?: AttachedFile[];
}

export interface AttachedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  mime?: string;
  fileDataUrl?: string;
  fileStored?: boolean;
  storageUrl?: string;
  storagePath?: string;
  uploadedAt?: string;
}

export interface ActivityStudentGrade {
  score?: number;
  status: 'Entregado' | 'Pendiente' | 'No Entregado' | 'Calificado';
  feedback?: string;
  gradedAt?: string;
  attachments?: AttachedFile[];
  submittedAt?: string;
  studentComment?: string;
}

export interface Activity {
  id: string;
  title: string;
  description: string;
  classId: string;
  date: string;
  deadline: string;
  value: number;
  status: 'Pendiente' | 'Entregada' | 'Calificada';
  teacherId?: string;
  parcial?: ParcialId;
  scores?: Record<string, number>;
  studentGrades?: Record<string, ActivityStudentGrade>;
  attachments?: AttachedFile[];
}

export interface GradeEvaluation {
  id: string;
  classId: string;
  title: string;
  type: string;
  value: number;
  scale: 10 | 100;
  scores: Record<string, number>;
  date?: string;
  parcial?: ParcialId;
}

export type AttendanceStatus = 'P' | 'A' | 'T' | 'J';

// Key is "YYYY-MM-DD:classId" -> { studentId: AttendanceStatus }
export type AttendanceRecord = Record<string, Record<string, AttendanceStatus>>;

export interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  type: 'Actividad' | 'Evaluación' | 'Reunión' | 'Proyecto' | 'Importante';
  classId?: string;
}

export interface ForumComment {
  id: string;
  topicId: string;
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  authorAvatar?: string;
  studentGrade?: string;
  content: string;
  createdAt: string;
  parentId?: string;
  isTeacherFeedback?: boolean;
  highlighted?: boolean;
  likes?: string[];
  attachments?: AttachedFile[];
}

export interface ForumTopic {
  id: string;
  title: string;
  description: string;
  classId: string; // Specific classId or 'all' for school-wide debate
  activityId?: string; // Optional: linked homework/task
  authorId: string;
  authorName: string;
  authorRole: 'admin' | 'teacher'; // Enforced: teacher or administration creates the topic
  createdAt: string;
  updatedAt?: string;
  status: 'open' | 'closed';
  parcial?: ParcialId;
  pinned?: boolean;
  category?: 'debate' | 'tarea' | 'pregunta' | 'lectura' | 'proyecto' | 'general';
  tags?: string[];
  attachments?: AttachedFile[];
}

export interface AppData {
  users: User[];
  classes: ClassRoom[];
  students: Student[];
  resources: Resource[];
  plans: LessonPlan[];
  activities: Activity[];
  forumTopics?: ForumTopic[];
  forumComments?: ForumComment[];
  grades: GradeEvaluation[];
  attendance: AttendanceRecord;
  events: CalendarEvent[];
  periodsConfig?: PeriodsConfig;
}

export type ActiveSection =
  | 'dashboard'
  | 'classes'
  | 'students'
  | 'resources'
  | 'planning'
  | 'activities'
  | 'forum'
  | 'grades'
  | 'attendance'
  | 'reports'
  | 'calendar'
  | 'admin';
